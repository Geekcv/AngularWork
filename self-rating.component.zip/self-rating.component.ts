import { Component, ElementRef, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { FormPreviewComponent } from '../../formBuilder/components/form-preview/form-preview.component';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { CommonModule, NgClass } from '@angular/common';

interface Message {
  text: string;
  sender: 'user' | 'bot';
  time: string;
}

interface Chat {
  title: string;
  messages: Message[];
}


@Component({
  selector: 'app-self-rating',
  imports: [MatDividerModule,  MatInputModule,MatSelectModule,FormsModule,
    MatButtonModule,FormPreviewComponent,
    NgClass,CommonModule, FormsModule
  ],
  templateUrl: './self-rating.component.html',
  styleUrl: './self-rating.component.scss'

})
export class SelfRatingComponent {
  
  @ViewChild('chatWindow') chatWindow!: ElementRef;

  chatHistory: Chat[] = [
    { title: 'Chat 1', messages: [] },
    { title: 'Chat 2', messages: [] }
  ];
  activeChat: Chat | null = this.chatHistory[0];
  messages: Message[] = [];
  userMessage: string = '';

  ngAfterViewChecked() {
    this.scrollToBottom();
  }

  sendMessage() {
    if (!this.userMessage.trim() || !this.activeChat) return;

    const newMessage: Message = {
      text: this.userMessage,
      sender: 'user',
      time: this.getCurrentTime()
    };

    this.activeChat.messages.push(newMessage);
    this.messages = [...this.activeChat.messages];

    const userInput = this.userMessage;
    this.userMessage = '';

    setTimeout(() => {
      const botReply: Message = {
        text: `Bot reply for: "${userInput}"`,
        sender: 'bot',
        time: this.getCurrentTime()
      };
      this.activeChat?.messages.push(botReply);
      this.messages = [...this.activeChat.messages];
    }, 1000);
  }

  openChat(chat: Chat) {
    this.activeChat = chat;
    this.messages = [...chat.messages];
  }

  scrollToBottom() {
    try {
      this.chatWindow.nativeElement.scrollTop = this.chatWindow.nativeElement.scrollHeight;
    } catch (err) {}
  }

  getCurrentTime(): string {
    const now = new Date();
    return now.getHours() + ':' + now.getMinutes().toString().padStart(2, '0');
  }

}
