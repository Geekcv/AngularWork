import { Routes } from '@angular/router';
import { SelfRatingComponent } from 'app/modules/admin/patientSide/self-rating/self-rating.component';

export default [
    {
        path: '',
        component: SelfRatingComponent,
    },
] as Routes;


// const express = require("express");
// const bodyParser = require("body-parser");
// const cors = require("cors");
// const { Pool } = require("pg");
// const axios = require("axios");

// const app = express();
// app.use(cors());
// app.use(bodyParser.json());

// // PostgreSQL connection
// const pool = new Pool({
//   user: "postgres",
//   host: "localhost",
//   database: "chatdb",
//   password: "yourpassword",
//   port: 5432,
// });

// // Create chats table
// (async () => {
//   await pool.query(`
//     CREATE TABLE IF NOT EXISTS chats (
//       id SERIAL PRIMARY KEY,
//       patient_id INT NOT NULL,
//       sender VARCHAR(10) NOT NULL,
//       message TEXT NOT NULL,
//       created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
//     )
//   `);
// })();

// // Save + forward user message
// app.post("/send_message", async (req, res) => {
//   const { patient_id, message } = req.body;

//   try {
//     // Save user message
//     await pool.query(
//       "INSERT INTO chats (patient_id, sender, message) VALUES ($1, $2, $3)",
//       [patient_id, "user", message]
//     );

//     // Call Python AI backend
//     const aiRes = await axios.post("http://127.0.0.1:5000/ai_reply", {
//       message: message,
//     });

//     const botReply = aiRes.data.reply;

//     // Save bot reply
//     await pool.query(
//       "INSERT INTO chats (patient_id, sender, message) VALUES ($1, $2, $3)",
//       [patient_id, "bot", botReply]
//     );

//     res.json({ reply: botReply });
//   } catch (err) {
//     console.error(err);
//     res.status(500).json({ error: "Error handling message" });
//   }
// });

// // Get patient chats
// app.get("/get_chats/:patient_id", async (req, res) => {
//   const { patient_id } = req.params;

//   try {
//     const result = await pool.query(
//       "SELECT sender, message, created_at FROM chats WHERE patient_id=$1 ORDER BY created_at",
//       [patient_id]
//     );
//     res.json({ chats: result.rows });
//   } catch (err) {
//     console.error(err);
//     res.status(500).json({ error: "Error fetching chats" });
//   }
// });

// app.listen(3000, () => console.log("Node server running on http://localhost:3000"));


// from flask import Flask, request, jsonify

// app = Flask(__name__)

// @app.route("/ai_reply", methods=["POST"])
// def ai_reply():
//     data = request.json
//     user_message = data.get("message", "")

//     # Your AI logic goes here (dummy response for now)
//     reply = f"AI thinks about: {user_message}"

//     return jsonify({"reply": reply})

// if __name__ == "__main__":
//     app.run(port=5000, debug=True)
