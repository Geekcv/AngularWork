// /* eslint-disable */
// import { FuseNavigationItem } from '@fuse/components/navigation';

// export const defaultNavigation: FuseNavigationItem[] = [
//     // {
//     //     id   : 'example',
//     //     title: 'Example15',
//     //     type : 'basic',
//     //     icon : 'heroicons_outline:chart-pie',
//     //     link : '/example'
//     // },
//     // {
//     //     id   : 'test',
//     //     title: 'test',
//     //     type : 'basic',
//     //     icon : 'feather:alert-octagon',
//     //     link : '/test'
//     // },
//     {
//         id   : 'dashboard',
//         title: 'Dashboard',
//         type : 'basic',
//         icon : 'mat_solid:dashboard',
//         link : '/dashboard',
//     },
//     {
//         id   : 'Viewresearchers',
//         title: 'View Researchers',
//         type : 'basic',
//         icon : 'heroicons_outline:viewfinder-circle',
//         link : '/Viewresearchers'
//     },
//     {
//         id   : 'Addresearchers',
//         title: 'Add Researchers',
//         type : 'basic',
//         icon : 'heroicons_outline:adjustments-vertical',
//         link : '/Addresearchers'
//     },
//     {
//         id   : 'Viewpatients',
//         title: 'View Patients',
//         type : 'basic',
//         icon : 'feather:command',
//         link : '/Viewpatients'
//     },
//     {
//         id   : 'Addpatients',
//         title: 'Add Patients',
//         type : 'basic',
//         icon : 'heroicons_solid:arrow-up-on-square-stack',
//         link : '/Addpatients'
//     },
//     {
//         id   : 'Account',
//         title: 'Account',
//         type : 'basic',
//         icon : 'feather:settings',
//         link : '/account'
//     },
// ];
// export const compactNavigation: FuseNavigationItem[] = [
//     {
//         id   : 'example',
//         title: 'Example',
//         type : 'basic',
//         icon : 'heroicons_outline:chart-pie',
//         link : '/example'
//     }
// ];
// export const futuristicNavigation: FuseNavigationItem[] = [
//     {
//         id   : 'example',
//         title: 'Example',
//         type : 'basic',
//         icon : 'heroicons_outline:chart-pie',
//         link : '/example'
//     }
// ];
// export const horizontalNavigation: FuseNavigationItem[] = [
//     {
//         id   : 'example',
//         title: 'Example',
//         type : 'basic',
//         icon : 'heroicons_outline:chart-pie',
//         link : '/example1'
//     }
// ];


/* eslint-disable */
import { FuseNavigationItem } from '@fuse/components/navigation';

export const defaultNavigation = (role: any): FuseNavigationItem[] => {
    const navigation: FuseNavigationItem[] = [];

    if (role === 0) { // Super Admin - Full Access
        navigation.push(
            {
                id: 'dashboard',
                title: 'Dashboard',
                type: 'basic',
                icon: 'mat_solid:dashboard',
                link: '/dashboard',
            },
            {
                id: 'Viewresearchers',
                title: 'View Researchers',
                type: 'basic',
                icon: 'heroicons_outline:viewfinder-circle',
                link: '/Viewresearchers'
            },
            {
                id: 'Addresearchers',
                title: 'Add Researchers',
                type: 'basic',
                icon: 'heroicons_outline:adjustments-vertical',
                link: '/Addresearchers'
            },
            {
                id: 'Viewpatients',
                title: 'View Patients',
                type: 'basic',
                icon: 'feather:command',
                link: '/viewpatients'
            },
            {
                id: 'Addpatients',
                title: 'Add Patients',
                type: 'basic',
                icon: 'heroicons_solid:arrow-up-on-square-stack',
                link: '/addpatients'
            },
            
            // {
            //     id: 'Account',
            //     title: 'Account',
            //     type: 'basic',
            //     icon: 'feather:settings',
            //     link: '/account'
            // },
            {
                id:'settings',
                title:'Settings',
                type:'basic',
                icon:'feather:settings',
                link:'settings'
             },
             {
                id:'formsdesign',
                title:'Forms Design',
                type:'basic',
                icon:'heroicons_outline:code-bracket-square',
                link:'formsdesign'
             },
            //  {
            //     id:'formpreview',
            //     title:'Form Preview',
            //     type:'basic',
            //     icon:'heroicons_outline:viewfinder-circle',
            //     link:'formpreview'
            //  },
             {
                id:'Response',
                title:'Response',
                type:'basic',
                icon:'heroicons_outline:presentation-chart-line',
                link:'response'
             },
             {
               id:'request',
               title:'Request',
               type:'basic',
               icon:'heroicons_outline:arrow-trending-up',
               link:'rquestSignUpdoctor'
            },     
        );
    } else if (role === 1) { // Admin - Limited Access
        navigation.push(
            {
                id: 'dashboard',
                title: 'Dashboard',
                type: 'basic',
                icon: 'mat_solid:dashboard',
                link: '/dashboard',
            },
            {
                id: 'Viewpatients',
                title: 'View Patients',
                type: 'basic',
                icon: 'heroicons_outline:user',
                link: '/Viewpatients'
            },
            // {
            //     id: 'Addpatients',
            //     title: 'Add Patients',
            //     type: 'basic',
            //     icon: 'heroicons_outline:user-plus',
            //     link: '/Addpatients'
            // },
            {
                id: 'appointment',
                title: 'Appointment',
                type: 'basic',
                icon: 'mat_solid:add_alarm',
                link: '/appointment'
            },
            {
                id: 'audionotes',
                title: 'Audio Notes',
                type: 'basic',
                icon: 'mat_outline:audiotrack',
                link: '/audionotestable'
            },
            {
                id: 'videonotes',
                title: 'Video Notes',
                type: 'basic',
                icon: 'heroicons_outline:video-camera',
                link: '/videonotestable'
            },
            {
                id: 'telesessions',
                title: 'Tele Sessions',
                type: 'basic',
                icon: 'mat_solid:voice_chat',
                link: '/telesessionstable'
            },
            {
                id: 'opdsessions',
                title: 'Opd Sessions',
                type: 'basic',
                icon: 'mat_solid:medication',
                link: '/opdsessionstable'
            },
            // {
            //     id: 'test',
            //     title: 'test view patient',
            //     type: 'basic',
            //     icon: 'heroicons_outline:cloud',
            //     link: '/test'
            // },
            {
               id:'settings',
               title:'Settings',
               type:'basic',
               icon:'feather:settings',
               link:'settings'
            },
            {
               id:'request',
               title:'Request',
               type:'basic',
               icon:'heroicons_outline:arrow-trending-up',
               link:'rquestSignUpPatients'
            },
            // {
            //     id: 'Account',
            //     title: 'Account',
            //     type: 'basic',
            //     icon: 'feather:settings',
            //     link: '/account'
            // },
            // {
            //     id: 'patientpanel',
            //     title: 'patientpanel',
            //     type: 'basic',
            //     icon: 'feather:settings',
            //     link: '/patientpanel'
            // },       
            // {
            //     id:'formpreview',
            //     title:'Form',
            //     type:'basic',
            //     icon:'heroicons_outline:viewfinder-circle',
            //     link:'formpreview'
            //  },
            
        );
    } else if (role === 2) { // User - Minimum Access
        navigation.push(
            {
                id: 'dashboard',
                title: 'Dashboard',
                type: 'basic',
                icon: 'mat_solid:dashboard',
                link: '/dashboard',
            },
            {
                id: 'selfrating',
                title: 'Self Rating',
                type: 'basic',
                icon: 'mat_outline:generating_tokens',
                link: '/selfrating'
            },           
            {
                id: 'myappointment',
                title: 'My Appointment',
                type: 'basic',
                icon: 'heroicons_outline:bolt',
                link: '/myappointment'
            },
            {
                id: 'audionotes',
                title: 'Audio Notes',
                type: 'basic',
                icon: 'mat_outline:audiotrack',
                link: '/audionotes'
            },
            {
                id: 'videonotes',
                title: 'Video Notes',
                type: 'basic',
                icon: 'heroicons_outline:video-camera',
                link: '/videonotes'
            },
            {
                id: 'telesessions',
                title: 'Tele Sessions',
                type: 'basic',
                icon: 'feather:droplet',
                link: '/telesessions'
            },
            {
                id: 'opdsessions',
                title: 'Opd Sessions',
                type: 'basic',
                icon: 'feather:layers',
                link: '/opdsessions'
            },
            // {
            //     id: 'uploadmedia',
            //     title: 'Upload Media',
            //     type: 'basic',
            //     icon: 'heroicons_outline:cloud',
            //     link: '/uploadmedia'
            // },
            // {
            //     id: 'appointment',
            //     title: 'Appointment',
            //     type: 'basic',
            //     icon: 'heroicons_outline:bolt',
            //     link: '/appointmentpatient'
            // },           
            {
                id:'settings',
                title:'Settings',
                type:'basic',
                icon:'feather:settings',
                link:'settings'
             },
            //  {
            //     id:'formpreview',
            //     title:'Form',
            //     type:'basic',
            //     icon:'heroicons_outline:viewfinder-circle',
            //     link:'formpreview'
            //  },

            
        );
    }

    return navigation;
};
