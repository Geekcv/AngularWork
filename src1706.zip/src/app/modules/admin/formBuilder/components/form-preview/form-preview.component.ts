import { CommonModule, NgClass, NgFor, NgIf, NgStyle, NgSwitch, NgSwitchCase } from '@angular/common';
import { Component, input, Input } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

interface FormElement {
  key: any;
  type: string;
  label: string;
  placeholder?: string;
  fontSize?: string;
  fontColor?: string;
  fontFamily?: string;
  fontWeight?: string;
  borderStyle?: string;
  padding?: string;
  bgColor?: string;
  invalid?: boolean; // Added to indicate validation state
  borderWidth?: string;
  margin?: string;
  width?: string;
  height?: string;
  bordercolor?: string;
  radius?: string;
  opacity?: string;
  rows?: any;
  cols?: any
  checked?: any
  min?: any
  max?: any
  options?: { label: string; value: string; }[]; // Array for radio options
  searchText?:any;
  filteredOptions?:any;
  optionsdropdown?: Array<{ label: string, value: string }>;// Dropdown options,
  emailTouched?:any;


}

@Component({
  selector: 'app-form-preview',
  imports: [NgFor, NgSwitchCase, NgSwitch, NgStyle,NgClass,CommonModule,FormsModule,
 MatFormFieldModule,MatSelectModule,MatInputModule,MatCheckboxModule,NgIf,NgClass
  ],

  templateUrl: './form-preview.component.html',
  styleUrl: './form-preview.component.scss'
})
export class FormPreviewComponent {

  @Input() formItems: FormElement[];
  @Input() forms_row_id:string;
  @Input() currentUrlPath:string;
  @Input()  media_data:any;
  formData: any = {};


  searchText:any;


  constructor(
        private Apicontroller: ApicontrollerService
    
  ){

  }

  // Search logic for multi select dropdown 
filterNativeCheckboxOptions(item: any) {
  const search = item.searchText?.toLowerCase() || '';
  item.filteredOptions = item.options.filter((opt: any) =>
    opt.label.toLowerCase().includes(search)
  );
}

// Handle checkbox change for multi select dropdown 
onCheckboxChange(item: any, value: string, event: any) {
  if (!this.formData[item.label]) {
    this.formData[item.label] = [];
  }

  if (event.target.checked) {
    this.formData[item.label].push(value);
  } else {
    this.formData[item.label] = this.formData[item.label].filter(
      (v: string) => v !== value
    );
  }
}

  // Search logic for single select dropdown 

  filterNativeDropdown(item: any) {
    console.log("serching inside dropdown ",item)
    const search = item.searchText?.toLowerCase() || '';
    console.log("search",search)
    item.filteredOptions = item.options.filter((opt: any) =>
      opt.label.toLowerCase().includes(search)
    );
  }


  // checkboxGrop 

onCheckboxGroupChange(event: any, key: string) {
    if (!this.formData[key]) {
        this.formData[key] = [];
    }

    const value = event.target.value;
    if (event.target.checked) {
        this.formData[key].push(value);
    } else {
        this.formData[key] = this.formData[key].filter((v: any) => v !== value);
    }
}


// file uplaod 

onFileChange(event: any, key: string) {
    const file = event.target.files[0];
    this.formData[key] = file;
}

resetForm() {
  // Clear form data
  this.formData = {};

  // Clear touched flags
  this.formTouched = {};

  // Reset search fields and filtered options if applicable
  this.formItems?.forEach(item => {
    if (item.type === 'dropdown' || item.type === 'multiselect') {
      item.searchText = '';
      item.filteredOptions = item.options || [];
    }

    // Reset checked status for checkboxes
    if (item.type === 'checkbox' || item.type === 'checkbox-group') {
      item.checked = false;
    }

    // Clear file inputs
    if (item.type === 'file') {
      // This assumes you're binding input with [(ngModel)]="formData[item.key]"
      this.formData[item.key] = null;
    }
  });

  console.log("Form reset completed");
}


// submit 
async submitForm() {
    console.log('Submitted Form:', this.formData);
    console.log("current form row_id ",this.forms_row_id)
    var formsubdata;
    var tablename;
    var others_data;

    var data =[
      formsubdata = this.formData,
      tablename = this.forms_row_id,
      others_data = this.media_data
    ]

    console.log("data-------->",data)

    const resp = await this.Apicontroller.SaveForms(data);
    this.resetForm();

    // console.log("resp:-",resp)
    // console.log("form data:-",this.formData)
    // this.formData = null
    // this.formItems = null

    // window.location.reload();
  
}


// general style 
yourStyle(item: any) {
  return {
      'font-size': item.fontSize,
      color: item.fontColor,
      'font-family': item.fontFamily,
      'font-weight': item.fontWeight,
      'border-style': item.borderStyle,
      padding: item.padding,
      'background-color': item.bgColor,
      'border-width': item.borderWidth,
      margin: item.margin,
      height: item.height,
      width: item.width,
      'border-color': item.bordercolor,
      'border-radius': item.radius,
      required:item.required
  };
}




// blockSpace(event: KeyboardEvent) {
//   if (event.key === ' ') {
//     event.preventDefault(); // Block spacebar
//   }
// }

markTouched(key: string) {
  this.formTouched[key] = true;
}

isInvalidEmail(item: any): boolean {
  const value = this.formData[item.key];
  console.log("email value",value)
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  // console.log("!this.formTouched[item.key]",!this.formTouched[item.key])

  if (!this.formTouched[item.key]) return false;

  // console.log("item.required && (!value || !emailRegex.test(value))",item.required && (!value || !emailRegex.test(value)))
  return item.required && (!value || !emailRegex.test(value));

}

isRequired(item:any):boolean{
  const value = this.formData[item.key];
  if(item.required && !value){
    return true
  }
}

formTouched: { [key: string]: boolean } = {};

}