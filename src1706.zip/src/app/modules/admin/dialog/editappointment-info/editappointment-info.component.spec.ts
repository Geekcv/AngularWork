import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditappointmentInfoComponent } from './editappointment-info.component';

describe('EditappointmentInfoComponent', () => {
  let component: EditappointmentInfoComponent;
  let fixture: ComponentFixture<EditappointmentInfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EditappointmentInfoComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EditappointmentInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
