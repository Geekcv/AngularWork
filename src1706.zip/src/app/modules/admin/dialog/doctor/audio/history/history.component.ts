import { Component, Inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { FormPreviewComponent } from 'app/modules/admin/formBuilder/components/form-preview/form-preview.component';
import { config } from '../../../../../../../../config';

interface FormElement {
  type: string;
  label: string;
  placeholder?: string;
  rows?: any;
  cols?: any
  min?: any
  max?: any
  optionsdropdown?: Array<{ label: string, value: string }>;// Dropdown options,
  optionsradio?: Array<{ label: string, value: string }>;
  optionscheckbox?: Array<{ label: string, value: string }>
  layout?: 'vertical' | 'horizontal';
  required?: boolean;
  address?:any[];
  accept?:string;
  key?:any;
  searchText?:any;
  filteredOptions?:any;
    


}

interface FormsSchemaData {
  // forms_row_id:any;
  form_link: any;
}

interface formdata{
  form_data:any
}


@Component({
  selector: 'app-history',
  imports: [MatDialogModule,MatButtonModule,    FormPreviewComponent],
  templateUrl: './history.component.html',
  styleUrl: './history.component.scss'
})
export class HistoryComponent {

  formItems: FormElement[] = [];
  formsdata: FormsSchemaData[];


  tablename:string;

  config: string = config.apiBaseURL;

 media_data:any;

  
  constructor(
        @Inject(MAT_DIALOG_DATA) public data: {medialink: string,mediadata:string},
            private dialogRef: MatDialogRef<HistoryComponent>, // Inject MatDialogRef   ,
    private Apicontroller: ApicontrollerService

        
    ){
      this.loadForm()
      this.showforms()
     this.media_data = data.mediadata
    }
  
    exitbtn(){
  
      this.dialogRef.close();
  
    }


    async loadForm() {

      const resp = await this.Apicontroller.loadallForms();
      this.formsdata = resp as FormsSchemaData[]; // Type assert to Doctor[]
      // this.forms_row_id = resp as FormsSchemaData[]; // Type assert to Doctor[]
  
      console.log("resp---", resp)
  //    console.log("formslinks ---", this.forms_row_id)
  
    }
  
  



    // async showforms(tablename: any) {
    //   console.log("tablename - ", tablename)
  
    //   this.tablename = tablename
    //   // this.idx = this.idx +1;
    
    //   const resp = await this.Apicontroller.loadForms(tablename);
    //   console.log("resp", resp[0].form_data)
    //   this.formItems = resp[0].form_data;
    // }

    async showforms(){
      console.log('show forms data');

      const resp = await this.Apicontroller.loadForms('Historyforms');
      console.log("resp", resp[0].form_data)
      this.formItems = resp[0].form_data;

    }
}
