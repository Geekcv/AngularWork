import { Component, Inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { config } from '../../../../../../../../config';
import { FormPreviewComponent } from 'app/modules/admin/formBuilder/components/form-preview/form-preview.component';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

interface FormElement {
  type: string;
  label: string;
  placeholder?: string;
  rows?: any;
  cols?: any
  min?: any
  max?: any
  optionsdropdown?: Array<{ label: string, value: string }>;// Dropdown options,
  optionsradio?: Array<{ label: string, value: string }>;
  optionscheckbox?: Array<{ label: string, value: string }>
  layout?: 'vertical' | 'horizontal';
  required?: boolean;
  address?:any[];
  accept?:string;
  key?:any;
  searchText?:any;
  filteredOptions?:any;
    


}

interface FormsSchemaData {
  // forms_row_id:any;
  form_link: any;
}


@Component({
  selector: 'app-rate',
  imports: [MatDialogModule,MatButtonModule,FormPreviewComponent],
  templateUrl: './rate.component.html',
  styleUrl: './rate.component.scss'
})
export class RateComponent {

      formItems: FormElement[] = [];
       formsdata: FormsSchemaData[];
     
     
       tablename:string;
        config: string = config.apiBaseURL;
      
     media_data:any;

       constructor(
             @Inject(MAT_DIALOG_DATA) public data: {medialink: string,mediadata:any},
                 private dialogRef: MatDialogRef<RateComponent>, // Inject MatDialogRef
                 private Apicontroller: ApicontrollerService
             
         ){
           this.showforms()
       this.media_data = data.mediadata
         }
       
         exitbtn(){
       
           this.dialogRef.close();
       
         }
     
         async showforms(){
           console.log('show forms data');
     
           const resp = await this.Apicontroller.loadForms('ratforms');
           console.log("resp", resp[0].form_data)
           this.formItems = resp[0].form_data;
     
         }

}
