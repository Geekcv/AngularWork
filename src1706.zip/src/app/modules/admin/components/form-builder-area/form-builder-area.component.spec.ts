import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FormBuilderAreaComponent } from './form-builder-area.component';

describe('FormBuilderAreaComponent', () => {
  let component: FormBuilderAreaComponent;
  let fixture: ComponentFixture<FormBuilderAreaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FormBuilderAreaComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FormBuilderAreaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
