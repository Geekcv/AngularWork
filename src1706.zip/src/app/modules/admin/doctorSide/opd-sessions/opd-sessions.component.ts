import { Component, ViewChild } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatDialog } from '@angular/material/dialog';
import { DeldialogComponent } from '../../dialog/deldialog/deldialog.component';
import { CommonModule } from '@angular/common';
import { MatSort, MatSortModule } from '@angular/material/sort';

interface appointment {
  apt_row_id: string;
  date_of_apt: string;
  // date_of_req:string;
  patient_name: string;
  user_contact_number: string;
  time_of_apt: string;
  // time_of_req:string;
  appointment_details: any;
  pat_row_id:any
  // appointment_details:{appt_status:any,appt_type:any,virtual_link:any};
  // updatedby_user_name:any
}

@Component({
  selector: 'app-opd-sessions',
  imports: [MatTableModule, MatButtonModule,
                  CommonModule,
      MatIconModule,MatInputModule,MatPaginatorModule,MatSortModule],
  templateUrl: './opd-sessions.component.html',
  styleUrl:'./opd-sessions.component.css'
})


export class OpdSessionsComponent {
 appointmentColumns: string[] = [
    'apt_row_id',
    'date_of_apt',
    // 'date_of_req',
    'patient_name',
    'user_contact_number',
    'time_of_apt',
    // 'time_of_req',
    'appointment_status',
    'updatedby_user_type',

    'appointment_Type',
    'Action'

  ];
  

   role :any ='';

   isSearchActive = false;
  appointmentdata: appointment[] = [];

    appointment = new MatTableDataSource<appointment>([]); // Use MatTableDataSource for pagination

    
      @ViewChild(MatPaginator) paginator!: MatPaginator;
            @ViewChild(MatSort) sort!: MatSort;
      

   constructor(
     private Apicontroller: ApicontrollerService,
     private router: Router,
       private _matDialog: MatDialog
   ) { 

    this.role=  localStorage.getItem('role')

  // console.log("my role",this.role)
   }
 
   ngOnInit(): void {
     this.Patients();
   }

   ngAfterViewInit() {
    this.appointment.paginator = this.paginator; // Set paginator after view init
    this.appointment.sort = this.sort; // Set paginator after view init

  }

   page: number = 1; // Default to first page
   async Patients() {
     try {
       const resp = await this.Apicontroller.fetchopdappointment();
       console.log("Patients", resp);
       this.appointment.data= resp.data  as appointment[]
     } catch (error) {
       console.error("Error fetching doctors:", error);
     }
 
   }
 




  filterByQuery(query: string): void {
    const trimmedQuery = query.trim().toLowerCase();

    if (trimmedQuery) {
        this.isSearchActive = true;
        this.appointment.filter = trimmedQuery;

        if (this.appointment.paginator) {
            this.appointment.paginator.firstPage(); // Reset to first page after search
        }
    } else {
        this.isSearchActive = false;
        this.appointment.filter = ''; // Clear filter

        // Reset the paginator and restore original data
        setTimeout(() => {
            this.appointment.paginator = this.paginator;
        });
    }
}

  exportToExcel(): void {
      const dataToExport = this.appointment.data.map((appoint) => ({
        ID: appoint.pat_row_id,
        Name: appoint.patient_name,
        Date: appoint.date_of_apt,
        Time: appoint.time_of_apt,
        PatientsNo: appoint.user_contact_number,
      }));
  
      const worksheet = XLSX.utils.json_to_sheet(dataToExport);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Doctors');
  
      const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
      const data = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      
      saveAs(data, 'Patients_List.xlsx');
    }


    refresh(){
      console.log("refresh----")
      this.Patients();
      // window.location.reload();
    }
  
    addpatientdialog(){
        // const dialogRef = this._matDialog.open(AddpatientdialogComponent);
      }



      deletebtn(){
      
          const dialogRef = this._matDialog.open(DeldialogComponent);
          // dialogRef.afterClosed().subscribe((result) => {
          //     console.log('dialog was closed!');
          // });
      
          console.log("delete.....")
        }


        viewteleDetails(patient_rowId: string) {
          console.log("viewdata",patient_rowId)
          this.router.navigate(['viewOpdSessionsdetails', patient_rowId]);
          // this.router.navigate(['patientpanel', patient_rowId]);
          
        }
}
