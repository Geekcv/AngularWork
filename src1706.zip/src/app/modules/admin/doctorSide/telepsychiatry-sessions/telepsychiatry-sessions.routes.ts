import { Routes } from '@angular/router';
import { TelepsychiatrySessionsComponent } from 'app/modules/admin/doctorSide/telepsychiatry-sessions/telepsychiatry-sessions.component';

export default [
    {
        path: '',
        component: TelepsychiatrySessionsComponent,
    },
] as Routes;
