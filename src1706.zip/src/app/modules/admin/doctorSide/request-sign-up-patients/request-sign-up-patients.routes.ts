import { Routes } from '@angular/router';
import { RequestSignUpPatientsComponent } from './request-sign-up-patients.component';

export default [
    {
        path: '',
        component: RequestSignUpPatientsComponent,
    },
] as Routes;
