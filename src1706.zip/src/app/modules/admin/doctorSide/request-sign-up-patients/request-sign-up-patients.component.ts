import { Component, ViewChild } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { AddpatientdialogComponent } from '../../dialog/doctor/addpatientdialog/addpatientdialog.component';
import { MatDialog } from '@angular/material/dialog';
import { DeldialogComponent } from '../../dialog/deldialog/deldialog.component';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { SuspendPatientComponent } from '../../dialog/suspend-patient/suspend-patient.component';
import { ActivePatientsComponent } from '../../dialog/active-patients/active-patients.component';

interface Patient {
 
  patient_age: string;
  patient_email: string;
  patient_gender: string;
  patient_name:string;
  user_contact_number:string;
  user_password:string;
  user_row_id:string;
  qualifications_details:string;
  qualifications:string;
  }
   
@Component({
  selector: 'app-request-sign-up-patients',
  imports: [
    MatTableModule, MatButtonModule,
  MatIconModule,MatInputModule,MatPaginatorModule,CommonModule,FormsModule
  ],
  templateUrl: './request-sign-up-patients.component.html',
  styleUrl: './request-sign-up-patients.component.scss'
})


export class RequestSignUpPatientsComponent {

  // patient: Patient[] = [];
   
    displayedColumns: string[] = [
      'user_row_id',
      'patient_name',
      'patient_email',
      'user_contact_number',
      

      'actions'
    ];
  

   role :any ='';

   isSearchActive = false;

    patient = new MatTableDataSource<Patient>([]); // Use MatTableDataSource for pagination

    
      @ViewChild(MatPaginator) paginator!: MatPaginator;

   constructor(
     private Apicontroller: ApicontrollerService,
     private router: Router,
       private _matDialog: MatDialog
   ) { 

    this.role=  localStorage.getItem('role')

  // console.log("my role",this.role)
   }
 
   ngOnInit(): void {
     this.Patients();
   }

   ngAfterViewInit() {
    this.patient.paginator = this.paginator; // Set paginator after view init
  }

   page: number = 1; // Default to first page
   async Patients() {
     try {
       const resp = await this.Apicontroller.fetchDeactivePatients('common',this.page);
       console.log("Patients", resp);
       this.patient.data = resp.data as Patient[]; // Type assert to Doctor[]
     } catch (error) {
       console.error("Error fetching doctors:", error);
     }
 
   }
 
 
   viewDoctorDetails(patient: Patient) {
     this.router.navigate(['patientDetails', patient.user_row_id]);
   }




  

    refresh(){
      console.log("refresh----")
      this.Patients();
      // window.location.reload();
    }
  
    



      activebtn(patient: Patient){
      console.log("status of patients click ",patient)
          const dialogRef = this._matDialog.open(ActivePatientsComponent,{data:{patient:patient}} ) // ,{ data: { doctordata: user_row_id  }}
          // dialogRef.afterClosed().subscribe((result) => {
          //     console.log('dialog was closed!');
          // });
      
          console.log("delete.....")
        }


        viewpatientDetails(patient_rowId: string) {
          console.log("viewdata",patient_rowId)
          // this.router.navigate(['patientDetails', patient_rowId]);
          this.router.navigate(['patientpanel', patient_rowId]);

          
        }


       
      
      
}
