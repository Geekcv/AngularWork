import { Component, ViewChild } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

import { CommonModule } from '@angular/common';
import { ChangeDetectorRef } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatTooltipModule } from '@angular/material/tooltip';
import { DeldialogComponent } from '../../dialog/deldialog/deldialog.component';
import { AddpatientdialogComponent } from '../../dialog/doctor/addpatientdialog/addpatientdialog.component';
import { CloumnShowdialogComponent } from '../../dialog/doctor/cloumn-showdialog/cloumn-showdialog.component';
import { SuspendPatientComponent } from '../../dialog/suspend-patient/suspend-patient.component';

interface Patient {
    patient_age: string;
    patient_email: string;
    patient_gender: string;
    patient_name: string;
    user_contact_number: string;
    user_password: string;
    user_row_id: string;
    qualifications_details: string;
    qualifications: string;
}

interface Column {
    name: string; // The column name/key (must match MatTable's columnDef)
    label: string; // The displayed label for checkbox and header
    visible: boolean; // Whether this column is currently shown
}

@Component({
    selector: 'app-viewpatients',
    // encapsulation: ViewEncapsulation.None,
    // changeDetection: ChangeDetectionStrategy.OnPush,

    imports: [
        MatTableModule,
        MatButtonModule,
        MatIconModule,
        MatInputModule,
        MatPaginatorModule,
        CommonModule,
        FormsModule,
        MatSortModule,
        MatTooltipModule,
    ],
    templateUrl: './viewpatients.component.html',
    styleUrl: './viewpatients.component.css',
})
export class ViewpatientsComponent {
    // displayedColumns: string[] = [
    //   'user_row_id',
    //   'patient_name',
    //   'patient_email',
    //   'user_contact_number',
    //   'qualifications',
    //   'qualifications_details',
    //   'actions'
    // ];

    columns: Column[] = [
        { name: 'user_row_id', label: 'ID', visible: true },
        { name: 'patient_name', label: 'Name', visible: true },
        { name: 'patient_email', label: 'Email', visible: true },
        { name: 'user_contact_number', label: 'Contact Number', visible: true },
        { name: 'qualifications', label: 'Qualifications', visible: true },
        {
            name: 'qualifications_details',
            label: 'Qualification Details',
            visible: true,
        },
        { name: 'actions', label: 'Actions', visible: true },
    ];

    role: any = '';
    patient = new MatTableDataSource<Patient>([]);

    @ViewChild(MatPaginator) paginator!: MatPaginator;
    @ViewChild(MatSort) sort!: MatSort;

    constructor(
        private Apicontroller: ApicontrollerService,
        private router: Router,
        private _matDialog: MatDialog,
        private cdRef: ChangeDetectorRef // Add this
    ) {
        this.role = localStorage.getItem('role');
    }

    ngOnInit(): void {
        this.Patients();
    }

    ngAfterViewInit() {
        this.patient.paginator = this.paginator;
        this.patient.sort = this.sort;
    }

    page: number = 1;

    async Patients() {
        try {
            const resp = await this.Apicontroller.fetchPatients(
                'common',
                this.page
            );
            this.patient.data = resp.data as Patient[];
        } catch (error) {
            console.error('Error fetching patients:', error);
        }
    }

    trackByFn(index: number, item: any) {
        return item.name; // Or unique identifier
    }

    viewDoctorDetails(patient: Patient) {
        this.router.navigate(['patientDetails', patient.user_row_id]);
    }

    refresh() {
        this.Patients();
    }

    addpatientdialog() {
        this._matDialog.open(AddpatientdialogComponent, {
            position: { right: '1%' },
        });
    }

    selectedRow: any = null;
selectedAction: string = '';
visitedActions: { [key: string]: string[] } = {};

deletebtn(row: any): void {
  this.selectedRow = row;
  this.selectedAction = 'delete';

  const id = row.user_row_id;

  if (!this.visitedActions[id]) {
    this.visitedActions[id] = [];
  }

  if (!this.visitedActions[id].includes('delete')) {
    this.visitedActions[id].push('delete');
  }

  this._matDialog.open(DeldialogComponent, {
    data: { patient: row },
  });
}

    

    viewpatientDetails(patient_rowId: string) {
        this.router.navigate(['patientpanel', patient_rowId]);
    }

    get displayedColumns(): string[] {
        return this.columns.filter((c) => c.visible).map((c) => c.name);
    }

    cloumnshow() {
        const dialogRef = this._matDialog.open(CloumnShowdialogComponent, {
            position: { right: '1%' },
            data: { columns: this.columns },
        });

        dialogRef.afterClosed().subscribe((result: Column[] | undefined) => {
            console.log('res', result);
            if (result) {
                // Update visibility based on dialog result
                result.forEach((colFromDialog) => {
                    const col = this.columns.find(
                        (c) => c.name === colFromDialog.name
                    );
                    if (col) {
                        col.visible = colFromDialog.visible;
                    }
                });
                // The getter will recalc displayedColumns automatically
            }
        });
    }

    isSearchActive = false;

    suspendPatient(patient: any) {
        this._matDialog.open(SuspendPatientComponent, {
            data: { patient: patient },
        });
    }

    editRowId: number | null = null;

    editRow(rowId: number) {
        this.editRowId = rowId;
    }

    async saveRow(row: any) {
        this.editRowId = null;
        try {
            const resp = await this.Apicontroller.updatePatients('common', row);
            console.log('Patients update data:', resp);
        } catch (error) {
            console.error('Error updating patients:', error);
        }
    }

    cancelEdit() {
        this.editRowId = null;
    }

    displayheaderdata: any;

    isRowEditing(rowId: any) {
        return this.editRowId === rowId;
    }
}
