import { Routes } from '@angular/router';
import { ViewTeleSessionsdetailsComponent } from 'app/modules/admin/doctorSide/view-tele-sessionsdetails/view-tele-sessionsdetails.component';

export default [
    {
        path: '',
        component: ViewTeleSessionsdetailsComponent,
    },
] as Routes;
