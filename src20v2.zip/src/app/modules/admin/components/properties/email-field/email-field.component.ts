import { CommonModule, NgClass, NgIf } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatCheckboxModule } from '@angular/material/checkbox';

interface FormElement {
  type: string;
  label: string;
  placeholder?: string;
  required?: boolean;
  fontSize?: string;
  fontColor?: string;
  fontFamily?: string;
  fontWeight?: string;
  borderStyle?: string;
  borderWidth?: string;
  bordercolor?: string;
  padding?: string;
  margin?: string;
  bgColor?: string;
  width?: string;
  height?: string;
  value?: string;
  invalid?: boolean;
}

@Component({
  selector: 'app-email-field',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    NgIf,
    MatInputModule,
    MatCheckboxModule,
    NgClass,
    
  ],
  templateUrl: './email-field.component.html',
  styleUrls: ['./email-field.component.scss']
})
export class EmailFieldComponent implements OnInit {

  @Input() selectedElementIndex: number | null = null;
  @Input() formItems: FormElement[] = [];

  fontSize: string = '14px';
  fontColor: string = '#000000';
  fontFamily: string = 'Arial';
  fontWeight: string = 'normal';
  borderStyle: string = 'solid';
  borderWidth: string = '1px';
  bordercolor: string = '#cccccc';
  padding: string = '8px';
  margin: string = '5px';
  bgColor: string = '#ffffff';
  width: string = '100%';
  height: string = '40px';
  required: boolean = false;
  emailTouched: boolean = false;

  ngOnInit(): void {
    this.updateLocalProperties();
  }

  updateLocalProperties(): void {
    if (this.selectedElementIndex !== null && this.formItems[this.selectedElementIndex]) {
      const selectedElement = this.formItems[this.selectedElementIndex];
      this.fontSize = selectedElement.fontSize || '14px';
      this.fontColor = selectedElement.fontColor || '#000000';
      this.fontFamily = selectedElement.fontFamily || 'Arial';
      this.fontWeight = selectedElement.fontWeight || 'normal';
      this.borderStyle = selectedElement.borderStyle || 'solid';
      this.borderWidth = selectedElement.borderWidth || '1px';
      this.bordercolor = selectedElement.bordercolor || '#cccccc';
      this.padding = selectedElement.padding || '8px';
      this.margin = selectedElement.margin || '5px';
      this.bgColor = selectedElement.bgColor || '#ffffff';
      this.width = selectedElement.width || '100%';
      this.height = selectedElement.height || '40px';
      this.required = selectedElement.required || false;
    }
  }

  updateProperties(): void {
    if (this.selectedElementIndex !== null) {
      const selectedElement = this.formItems[this.selectedElementIndex];
      selectedElement.fontSize = this.fontSize;
      selectedElement.fontColor = this.fontColor;
      selectedElement.fontFamily = this.fontFamily;
      selectedElement.fontWeight = this.fontWeight;
      selectedElement.borderStyle = this.borderStyle;
      selectedElement.borderWidth = this.borderWidth;
      selectedElement.bordercolor = this.bordercolor;
      selectedElement.padding = this.padding;
      selectedElement.margin = this.margin;
      selectedElement.bgColor = this.bgColor;
      selectedElement.width = this.width;
      selectedElement.height = this.height;
      selectedElement.required = this.required;
    }
  }

  isLabelInvalid(): boolean {
    return this.selectedElementIndex !== null &&
      !this.formItems[this.selectedElementIndex]?.label?.trim();
  }

  isPlaceholderInvalid(): boolean {
    return this.selectedElementIndex !== null &&
      !this.formItems[this.selectedElementIndex]?.placeholder?.trim();
  }

  validateLabel() {
    if (this.selectedElementIndex !== null) {
      const element = this.formItems[this.selectedElementIndex];
      element.invalid = !element.label?.trim();
    }
  }

  validatePlaceholder() {
    // Placeholder is optional
  }

  
}
