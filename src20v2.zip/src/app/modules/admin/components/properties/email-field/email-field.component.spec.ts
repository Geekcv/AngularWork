import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { MatCheckboxModule } from '@angular/material/checkbox'; // Import if using MatCheckbox

import { EmailFieldComponent } from './email-field.component';

describe('EmailFieldComponent', () => {
  let component: EmailFieldComponent;
  let fixture: ComponentFixture<EmailFieldComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        EmailFieldComponent, // If standalone
        // CommonModule,       // If not standalone
        // FormsModule,        // If not standalone
        // MatCheckboxModule,  // If not standalone
        NoopAnimationsModule
       ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EmailFieldComponent);
    component = fixture.componentInstance;

    // Provide mock data
    component.formItems = [
      { type: 'email', label: 'Test Email', placeholder: 'test@example.com', required: false }
    ];
    component.selectedElementIndex = 0;

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should load initial properties', () => {
    component.ngOnInit();
    expect(component.formItems[0].label).toBe('Test Email');
    expect(component.required).toBe(false);
  });

   it('should update required property', () => {
      component.required = true;
      component.updateProperties();
      expect(component.formItems[component.selectedElementIndex!].required).toBe(true);
    });

   it('should update style properties', () => {
     component.fontSize = '16px';
     component.updateProperties();
     expect(component.formItems[component.selectedElementIndex!].fontSize).toBe('16px');
   });

   it('should validate label', () => {
      component.formItems[component.selectedElementIndex!].label = ' '; // Invalid label
      component.validateLabel();
      expect(component.formItems[component.selectedElementIndex!].invalid).toBe(true);

      component.formItems[component.selectedElementIndex!].label = 'Valid Label'; // Valid label
      component.validateLabel();
       // Assuming validation resets invalid flag on success
      expect(component.formItems[component.selectedElementIndex!].invalid).toBe(false);
    });

});