import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SuspendPatientComponent } from './suspend-patient.component';

describe('SuspendPatientComponent', () => {
  let component: SuspendPatientComponent;
  let fixture: ComponentFixture<SuspendPatientComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SuspendPatientComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SuspendPatientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
