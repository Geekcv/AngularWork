import { Routes } from '@angular/router';
import { AddClassComponent } from './add-class.component';

export default [
    {
        path: '',
        component: AddClassComponent,
    },
] as Routes;
