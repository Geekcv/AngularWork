import { HttpClient } from '@angular/common/http';
import { Component, inject, ViewChild } from '@angular/core';
import {
    FormsModule,
    NgForm,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { config } from '../../../../../../config';

interface classData{
  row_id:string;
  name:string
}

interface subjectData{
  row_id:string;
  name:string
}

interface board {
 row_id:string;
  name:string;
}

@Component({
  selector: 'app-add-chapter',
  imports: [
      FormsModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatInputModule,
        MatButtonModule,
        MatIconModule,
        MatCheckboxModule,
        MatProgressSpinnerModule,
        MatSelectModule,
  ],
  templateUrl: './add-chapter.component.html',
  styleUrl: './add-chapter.component.scss'
})
export class AddChapterComponent {

 @ViewChild('chapterNgForm') chapterNgForm: NgForm;

  chapterForm: UntypedFormGroup;
  showAlert = false;
  role: any = '';
  config: any;

  subjectList = []
  classList = []

  constructor(
      private _formBuilder: UntypedFormBuilder,
      private _router: Router,
      private api: ApicontrollerService,
  ) {
      this.config = config.apiBaseURL;
      this.role = localStorage.getItem('role');
      this.fetchallboard()
  }

  private _snackBar = inject(MatSnackBar);

  ngOnInit(): void {
      this.chapterForm = this._formBuilder.group({
          chaptername: ['', Validators.required],
        class_id :['',Validators.required],
          board_id: ['', Validators.required], 
          subject_id:['',Validators.required]
          
      });
  }

  // boardList = [
  //     { row_id: '1729833318838_Ir5A', name: 'CBSE' },
  //     { row_id: '1729862517377_iMzd', name: 'RBSE' },
  // ];

  boardList = []

  async addChapter(): Promise<void> {
      if (this.chapterForm.invalid) {
          this.chapterForm.markAllAsTouched();
          return;
      }

      const payload = {
          ...this.chapterForm.value,
      };

      const resp = await this.api.addChapter(payload);

      if (resp.status === 0) {
          this._snackBar.open(resp.msg, '', {
              duration: 3000,
              verticalPosition: 'top',
              horizontalPosition: 'center',
          });

          this.chapterNgForm.resetForm();
      } else {
          this._snackBar.open(resp.msg || 'Failed to add chapter', '', {
              duration: 3000,
              verticalPosition: 'top',
              horizontalPosition: 'center',
          });
      }
  }

  selectedValue:any;

    async onSelectionChange(event: Event){
        // this.selectedValue = (event.target as HTMLSelectElement).value;
        console.log('Selected value:---------', this.selectedValue);

        const resp = await this.api.fetchAllclassOfboard('common', this.selectedValue);
        console.log("resp",resp)
        this.classList = resp as classData[]
       

      }

      async fetchallboard(){
    // 
      const resp = await this.api.fetchallBoard();
      this.boardList = resp as board[]

  }

  // 

    selectedValueclass:any;

    async onSelectionChangeclass(event: Event){
        // this.selectedValue = (event.target as HTMLSelectElement).value;
        console.log('Selected value:---------', this.selectedValueclass);

        const resp = await this.api.fetchAllsubjectOfclass('common', this.selectedValueclass);
        console.log("resp",resp)
        this.subjectList = resp as subjectData[]
       

      }
}
