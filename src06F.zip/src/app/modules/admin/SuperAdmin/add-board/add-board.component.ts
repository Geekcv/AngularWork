import { Component, inject, ViewChild } from '@angular/core';
import {
    FormsModule,
    NgForm,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { config } from '../../../../../../config';


@Component({
  selector: 'app-add-board',
  imports: [
     FormsModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatInputModule,
        MatButtonModule,
        MatIconModule,
        MatCheckboxModule,
        MatProgressSpinnerModule,
        MatSelectModule,
  ],
  templateUrl: './add-board.component.html',
  styleUrl: './add-board.component.scss'
})
export class AddBoardComponent {
   @ViewChild('boardNgForm') boardNgForm: NgForm;

  boardForm: UntypedFormGroup;
  config:any;
  role:any;

   constructor(
        private _formBuilder: UntypedFormBuilder,
        private _router: Router,
        private api: ApicontrollerService,
    ) {
        this.config = config.apiBaseURL;
        this.role = localStorage.getItem('role');
    }
  
    private _snackBar = inject(MatSnackBar);
  
    ngOnInit(): void {
        this.boardForm = this._formBuilder.group({
            board: ['', Validators.required],         
        });
    }
  

  
    async addBoard(): Promise<void> {
        if (this.boardForm.invalid) {
            this.boardForm.markAllAsTouched();
            return;
        }
  
        const payload = {
            ...this.boardForm.value,
        };
  
        // pending to create add board
        const resp = await this.api.createboard(payload);
  
        if (resp.status === 0) {
            this._snackBar.open(resp.msg, '', {
                duration: 3000,
                verticalPosition: 'top',
                horizontalPosition: 'center',
            });
  
            this.boardNgForm.resetForm();
        } else {
            this._snackBar.open(resp.msg || 'Failed to add board', '', {
                duration: 3000,
                verticalPosition: 'top',
                horizontalPosition: 'center',
            });
        }
    }
}
