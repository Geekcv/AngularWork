import { Routes } from '@angular/router';
import { ClassDetailsComponent } from './class-details.component';

export default [
    {
        path: '',
        component: ClassDetailsComponent,
    },
] as Routes;
