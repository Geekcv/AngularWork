// /* eslint-disable */
// import { FuseNavigationItem } from '@fuse/components/navigation';

// export const defaultNavigation = (role: any): FuseNavigationItem[] => {
//     const navigation: FuseNavigationItem[] = [];

//     if (role === 1) {
//         // Super Admin - Full Access
//         navigation.push(
//             {
//                 id: 'dashboard',
//                 title: 'Dashboard',
//                 type: 'basic',
//                 icon: 'mat_solid:dashboard',
//                 link: '/dashboard',
//             },
//             {
//                 id: 'schoolManagement',
//                 title: 'School Management',
//                 type: 'collapsable',
//                 icon: 'heroicons_outline:academic-cap',
//                 children: [
//                     {
//                         id: 'addschool',
//                         title: 'Add School',
//                         type: 'basic',
//                         icon: 'heroicons_outline:building-library',
//                         link: '/addschool',
//                     },
//                     {
//                         id: 'addboard',
//                         title: 'Add Board',
//                         type: 'basic',
//                         icon: 'heroicons_outline:clipboard-document-check',
//                         link: '/addboard',
//                     },
//                     {
//                         id: 'addclass',
//                         title: 'Add Class',
//                         type: 'basic',
//                         icon: 'heroicons_outline:rectangle-stack',
//                         link: '/addclass',
//                     },
//                     {
//                         id: 'addsubject',
//                         title: 'Add Subject',
//                         type: 'basic',
//                         icon: 'heroicons_outline:book-open',
//                         link: '/addsubject',
//                     },
//                     {
//                         id: 'addchapter',
//                         title: 'Add Chapters',
//                         type: 'basic',
//                         icon: 'heroicons_outline:document-text',
//                         link: '/addchapter',
//                     },
//                 ],
//             }
//         );
//     } else if (role === 2) {
//         // School Admin - Limited Access
//         navigation.push(
//             {
//                 id: 'dashboard',
//                 title: 'Dashboard',
//                 type: 'basic',
//                 icon: 'mat_solid:dashboard',
//                 link: '/dashboard',
//             },
//             {
//                 id: 'class',
//                 title: 'Class',
//                 type: 'basic',
//                 icon: 'heroicons_outline:rectangle-stack',
//                 link: '/showclass',
//             },
//             {
//                 id: 'schoolManagement',
//                 title: 'Account Create',
//                 type: 'collapsable',
//                 icon: 'heroicons_outline:academic-cap',
//                 children: [
//             {
//                 id: 'addStudent',
//                 title: 'Add Student',
//                 type: 'basic',
//                 icon: 'heroicons_outline:user-plus',
//                 link: '/addStudent',
//             },
//             {
//                 id: 'addTeacher',
//                 title: 'Add Teacher',
//                 type: 'basic',
//                 icon: 'heroicons_outline:user-plus',
//                 link: '/addteacher',
//             }
//         ]
//     },
//             {
//                 id: 'assignSubjecttoteacher',
//                 title: 'Assign Subjects',
//                 type: 'basic',
//                 icon: 'heroicons_outline:user-plus',
//                 link: '/assignSubject',
//             }
//         );
//     } else if (role === 3) {
//         // Teacher/Faculty
//         navigation.push(
//             {
//                 id: 'dashboard',
//                 title: 'Dashboard',
//                 type: 'basic',
//                 icon: 'mat_solid:dashboard',
//                 link: '/dashboard',
//             },
//             {
//                 id: 'reports',
//                 title: 'My Class',
//                 type: 'basic',
//                 icon: 'heroicons_outline:chart-bar',
//                 link: '/myclass',
//             }
//         );
//     } else if (role === 4) {
//         // Student/User
//         navigation.push({
//             id: 'dashboard',
//             title: 'Dashboard',
//             type: 'basic',
//             icon: 'mat_solid:dashboard',
//             link: '/dashboard',
//         });
//     }

//     return navigation;
// };



/* eslint-disable */
import { FuseNavigationItem } from '@fuse/components/navigation';

export const defaultNavigation = (role: any): FuseNavigationItem[] => {
    const navigation: FuseNavigationItem[] = [];

    if (role === 1) {
        // Super Admin
        navigation.push(
            {
                id: 'dashboard',
                title: 'Admin Dashboard',
                type: 'basic',
                icon: 'mat_solid:dashboard',
                link: '/dashboard',
            },
            {
                id: 'schoolManagement',
                title: 'Institution Setup',
                type: 'collapsable',
                icon: 'heroicons_outline:academic-cap',
                children: [
                    {
                        id: 'addschool',
                        title: 'Register School',
                        type: 'basic',
                        icon: 'heroicons_outline:building-office',
                        link: '/addschool',
                    },
                    {
                        id: 'addboard',
                        title: 'Create Education Board',
                        type: 'basic',
                        icon: 'heroicons_outline:clipboard-document-check',
                        link: '/addboard',
                    },
                    {
                        id: 'addclass',
                        title: 'Define Classes',
                        type: 'basic',
                        icon: 'heroicons_outline:rectangle-stack',
                        link: '/addclass',
                    },
                    {
                        id: 'addsubject',
                        title: 'Define Subjects',
                        type: 'basic',
                        icon: 'heroicons_outline:book-open',
                        link: '/addsubject',
                    },
                    {
                        id: 'addchapter',
                        title: 'Manage Chapters',
                        type: 'basic',
                        icon: 'heroicons_outline:document-text',
                        link: '/addchapter',
                    }
                ],
            },
            
           
        );
    }

    else if (role === 2) {
        // School Admin
        navigation.push(
            {
                id: 'dashboard',
                title: 'School Dashboard',
                type: 'basic',
                icon: 'mat_solid:dashboard',
                link: '/dashboard',
            },
            {
                id: 'class',
                title: 'View Classes',
                type: 'basic',
                icon: 'heroicons_outline:rectangle-stack',
                link: '/showclass',
            },
            {
                id: 'accountCreation',
                title: 'Create Accounts',
                type: 'collapsable',
                icon: 'heroicons_outline:user-plus',
                children: [
                    {
                        id: 'addStudent',
                        title: 'Add Student',
                        type: 'basic',
                        icon: 'heroicons_outline:academic-cap',
                        link: '/addStudent',
                    },
                    {
                        id: 'addTeacher',
                        title: 'Add Teacher',
                        type: 'basic',
                        icon: 'heroicons_outline:user-circle',
                        link: '/addteacher',
                    }
                ]
            },
            {
                id: 'assignSubjectToTeacher',
                title: 'Assign Subject',
                type: 'basic',
                icon: 'heroicons_outline:clipboard-document-check',
                link: '/assignSubject',
            },
            {
                id: 'reports',
                title: 'Reports',
                type: 'basic',
                icon: 'heroicons_outline:chart-bar',
                link: '/reports',
            }
        );
    }

    else if (role === 3) {
        //  Teacher
        navigation.push(
            {
                id: 'dashboard',
                title: 'My Dashboard',
                type: 'basic',
                icon: 'mat_solid:dashboard',
                link: '/dashboard',
            },
            {
                id: 'myClass',
                title: 'My Classes Subjects Assigned',
                type: 'basic',
                icon: 'heroicons_outline:academic-cap',
                link: '/myclass',
            },
            {
                id: 'createMCQ',
                title: 'MCQ',
                type: 'basic',
                icon: 'heroicons_outline:clipboard-document-check', // better represents quiz/test
                link: '/addmcq',
            },
            {
                id: 'createExam',
                title: 'Exam',
                type: 'basic',
                icon: 'heroicons_outline:pencil-square', // represents exam/test writing
                link: '/addexam',
            }
            
            
        );
    }

    else if (role === 4) {
        // 👨‍🎓 Student
        navigation.push(
            {
                id: 'dashboard',
                title: 'Student Dashboard',
                type: 'basic',
                icon: 'mat_solid:dashboard',
                link: '/dashboard',
            },
            {
                id: 'mySubjects',
                title: 'My Subjects',
                type: 'basic',
                icon: 'heroicons_outline:book-open',
                link: '/student/subjects',
            },
            {
                id: 'myAttendance',
                title: 'My Attendance',
                type: 'basic',
                icon: 'heroicons_outline:calendar-days',
                link: '/student/attendance',
            },
            {
                id: 'examResults',
                title: 'Exam Results',
                type: 'basic',
                icon: 'heroicons_outline:document-check',
                link: '/student/results',
            }
        );
    }

    return navigation;
};
