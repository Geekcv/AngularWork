import { Component, inject, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import {
    FormsModule,
    NgForm,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { Router, RouterLink } from '@angular/router';
import { fuseAnimations } from '@fuse/animations';
import { FuseAlertComponent, FuseAlertType } from '@fuse/components/alert';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { AuthService } from 'app/core/auth/auth.service';
import {MatSnackBar} from '@angular/material/snack-bar';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { config } from '../../../../../../../config';

interface Doctor {
    doctor_email: string;
    doctor_gender: string;
    firstname: string;
    lastname:string;
    user_contact_number: string;
    user_password: string;
    user_row_id: string;
    photo_path:string;
  }

@Component({
  selector: 'app-addgroup',
  imports: [ MatSelectModule,
        MatFormFieldModule,
        MatInputModule,
        ReactiveFormsModule,
        MatButtonModule,
        MatDialogModule,MatSidenavModule,        MatIconModule,CommonModule],
  templateUrl: './addgroup.component.html',
  styleUrl: './addgroup.component.scss'
})
export class AddgroupComponent {
alert: { type: FuseAlertType; message: string } = {
        type: 'success',
        message: '',
    };
    signUpForm: UntypedFormGroup;
    showAlert: boolean = false;
    role :any ='';

    genders: string[] = ['Male', 'Female', 'Other']; // List of genders
    doctorType:string[]=['Dermatologist','Neurologist','Cardiologist','Psychiatrist','Gastroenterologist','Family medicine']
    /**
     * Constructor
     */
    constructor(
        private _authService: AuthService,
        private _formBuilder: UntypedFormBuilder,
        private _router: Router,
        private Apicontroller: ApicontrollerService,private router: Router,private http: HttpClient,
        private dialogRef: MatDialogRef<AddgroupComponent>
    ) {

      this.role=  localStorage.getItem('role')

      // console.log("my role",this.role)
    }

    private _snackBar = inject(MatSnackBar);

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void {
        // Create the form
        this.signUpForm = this._formBuilder.group({
          group_name: ['', Validators.required],
         
        });
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * Sign up
     */
 

    async addgroup(){


     const resp = await this.Apicontroller.creategroup(this.signUpForm.value);

   
      if (resp.status === 0) {       
        
        this._snackBar.open(resp.msg, '', {
          duration: 3000, // Duration in milliseconds (3 seconds)
          verticalPosition: 'top', // Position: 'top' | 'bottom'
          horizontalPosition: 'center', // Position: 'start' | 'center' | 'end' | 'left' | 'right'
        });
    
        this.signUpForm.reset()

      }else{
  
       console.log("error ")
      } 
    }

    exitbtn() {
        this.dialogRef.close();
    }
}
