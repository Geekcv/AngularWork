import { HttpClient } from '@angular/common/http';
import { Component, inject, ViewChild } from '@angular/core';
import {
    FormsModule,
    NgForm,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { config } from '../../../../../../config';

@Component({
    selector: 'app-addresearchers',
    imports: [
        //RouterLink,
        // FuseAlertComponent,
        FormsModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatInputModule,
        MatButtonModule,
        MatIconModule,
        MatCheckboxModule,
        MatProgressSpinnerModule,
        MatSelectModule,
    ],
    templateUrl: './addresearchers.component.html',
})
export class AddresearchersComponent {
    @ViewChild('schoolNgForm') schoolNgForm: NgForm;

    schoolForm: UntypedFormGroup;
    showAlert = false;
    role: any = '';
    config: any;
    filepath: any;
    mediatype: any;

    constructor(
        private _formBuilder: UntypedFormBuilder,
        private _router: Router,
        private api: ApicontrollerService,
        private http: HttpClient
    ) {
        this.config = config.apiBaseURL;
        this.role = localStorage.getItem('role');
    }

    private _snackBar = inject(MatSnackBar);

    ngOnInit(): void {
        this.schoolForm = this._formBuilder.group({
            name: ['', Validators.required],
            email: ['', [Validators.required, Validators.email]],
            phone: ['', Validators.required],
            address: ['', Validators.required],
            board_id: ['', Validators.required], // 👈 required!
            password: ['', Validators.required],
            is_active: [true],
        });
    }

    boardList = [
        { row_id: 'board-cbse', name: 'CBSE' },
        { row_id: 'board-rbse', name: 'RBSE' },
    ];

    async addSchool(): Promise<void> {
        if (this.schoolForm.invalid) {
            this.schoolForm.markAllAsTouched();
            return;
        }

        const payload = {
            ...this.schoolForm.value,
            created_by: localStorage.getItem('row_id') || '', // optional
        };

        const resp = await this.api.createschool(payload);

        if (resp.status === 0) {
            this._snackBar.open(resp.msg, '', {
                duration: 3000,
                verticalPosition: 'top',
                horizontalPosition: 'center',
            });

            this.schoolNgForm.resetForm();
        } else {
            this._snackBar.open(resp.msg || 'Failed to add school', '', {
                duration: 3000,
                verticalPosition: 'top',
                horizontalPosition: 'center',
            });
        }
    }
}




// studentForm = this.fb.group({
//     name: ['', Validators.required],
//     email: ['', Validators.email],
//     phone: [''],
//     school_id: ['', Validators.required],
//     class_id: ['', Validators.required],
//     is_active: [true]
//   });
  
//   schoolList = []; // Fill this from API
//   classList = []; // Fill this from API
  
//   addStudent() {
//     if (this.studentForm.valid) {
//       const data = this.studentForm.value;
//       this.studentForm.disable();
  
//       this.apiService.addStudent(data).subscribe({
//         next: (res) => {
//           this.toast.success('Student added successfully');
//           this.studentForm.reset();
//           this.studentForm.enable();
//         },
//         error: (err) => {
//           this.toast.error('Failed to add student');
//           this.studentForm.enable();
//         }
//       });
//     } else {
//       this.toast.error('Please fill all required fields');
//     }
//   }
  