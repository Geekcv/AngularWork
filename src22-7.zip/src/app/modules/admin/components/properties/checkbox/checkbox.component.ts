import { CommonModule, NgFor, NgIf } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatIconModule } from '@angular/material/icon'; // Assuming you use Material Icons

// --- Interface (Ensure this matches/extends the one in other components) ---
interface FormElement {
  type: string;
  label: string;
  options?: { label: string; value: string; }[]; // Array for radio options
  layout?: 'horizontal' | 'vertical'; // Layout direction
  fontColor?: string;
  fontSize?: string;
  fontFamily?: string;
  fontWeight?: string;
  margin?: string;
  padding?: string;
  // Add other properties from your base interface if needed
  placeholder?: string; // May not be needed for radio, but keep interface consistent
  invalid?: boolean;
  key?:string
  required?: boolean;

  // ... other properties from your base FormElement interface
}
// --- End Interface ---

@Component({
  selector: 'app-checkbox',
  imports: [
    CommonModule,
    FormsModule,
    NgIf,
    NgFor,
    MatIconModule, // Import MatIconModule
    MatCheckboxModule

  ],
  templateUrl: './checkbox.component.html',
  styleUrl: './checkbox.component.scss'
})
export class CheckboxComponent {
  @Input() selectedElementIndex: number | null = null;
  @Input() formItems: FormElement[] = [];

  // --- Style Properties ---
  fontColor: string = '#000000';
  fontSize: string = '14px'; // Default font size
  fontFamily: string = 'Arial';
  fontWeight: string = 'normal';
  margin: string = '5px';
  padding: string = '5px';
  layout: 'horizontal' | 'vertical' = 'vertical'; // Default layout
  required: boolean = false;

  // --- End Style Properties ---

  ngOnInit(): void {
    // Initialize properties when component loads or selection changes (if needed)
    this.updateLocalProperties();
  }

  // Helper to load current element's properties into local component variables
  updateLocalProperties(): void {
    if (this.selectedElementIndex !== null && this.formItems[this.selectedElementIndex]) {
      const selectedElement = this.formItems[this.selectedElementIndex];
      this.fontColor = selectedElement.fontColor || '#000000';
      this.fontSize = selectedElement.fontSize || '14px';
      this.fontFamily = selectedElement.fontFamily || 'Arial';
      this.fontWeight = selectedElement.fontWeight || 'normal';
      this.margin = selectedElement.margin || '5px';
      this.padding = selectedElement.padding || '5px';
      this.layout = selectedElement.layout || 'vertical';

      // Ensure options array exists
      if (!selectedElement.options) {
        selectedElement.options = [{ label: 'Option 1', value: 'option1' }]; // Default option
      }
    }
  }

  // Update the main formItems array when properties change
  updateStyles(): void {
    if (this.selectedElementIndex !== null) {
      const selectedElement = this.formItems[this.selectedElementIndex];
      selectedElement.fontColor = this.fontColor;
      selectedElement.fontSize = this.fontSize;
      selectedElement.fontFamily = this.fontFamily;
      selectedElement.fontWeight = this.fontWeight;
      selectedElement.margin = this.margin;
      selectedElement.padding = this.padding;
      selectedElement.layout = this.layout;
      selectedElement.required = this.required

      // Note: Options are directly modified via ngModel in the template
    }
  }

  // --- Option Management ---
  addOption(): void {
    if (this.selectedElementIndex !== null) {
      const selectedElement = this.formItems[this.selectedElementIndex];
      if (!selectedElement.options) {
        selectedElement.options = [];
      }
      const newIndex = selectedElement.options.length + 1;
      selectedElement.options.push({ label: `Option ${newIndex}`, value: `option${newIndex}` });
    }
  }

  removeOption(index: number): void {
    if (this.selectedElementIndex !== null) {
      const selectedElement = this.formItems[this.selectedElementIndex];
      if (selectedElement.options && selectedElement.options.length > index) {
        selectedElement.options.splice(index, 1);
      }
    }
  }
  // --- End Option Management ---

  // --- Validation (Example for Label) ---
  isLabelInvalid(): boolean {
    return this.selectedElementIndex !== null &&
      !this.formItems[this.selectedElementIndex]?.label?.trim();
  }

  validateLabel() {
    if (this.selectedElementIndex !== null) {
      const element = this.formItems[this.selectedElementIndex];
      element.invalid = !element.label?.trim();
    }
  }
  // --- End Validation ---

  syncLabelToKey(): void {
    // Sync label to key in real-time
    this.formItems[this.selectedElementIndex].key = this.formItems[this.selectedElementIndex].label;
  }
}
