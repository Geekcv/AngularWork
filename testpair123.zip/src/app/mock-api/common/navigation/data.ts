/* eslint-disable */
import { FuseNavigationItem } from '@fuse/components/navigation';

export const defaultNavigation = (role: any): FuseNavigationItem[] => {
    const navigation: FuseNavigationItem[] = [];

    if (role === 1) {
        // Super Admin - Full Access
        navigation.push(
            {
                id: 'dashboard',
                title: 'Dashboard',
                type: 'basic',
                icon: 'heroicons_outline:home', // home/dashboard icon
                link: '/dashboard',
            },
            {
                id: 'schoolManagement',
                title: 'School Management',
                type: 'collapsable',
                icon: 'heroicons_outline:academic-cap', // education cap
                children: [
                    {
                        id: 'addschool',
                        title: 'Add School',
                        type: 'basic',
                        icon: 'heroicons_outline:building-office', // building
                        link: '/addschool',
                    },
                    {
                        id: 'addboard',
                        title: 'Add Board',
                        type: 'basic',
                        icon: 'heroicons_outline:clipboard-document-list', // board/documents
                        link: '/addboard',
                    },
                    {
                        id: 'addclass',
                        title: 'Add Class',
                        type: 'basic',
                        icon: 'heroicons_outline:view-columns', // columns for class structure
                        link: '/addclass',
                    },
                    {
                        id: 'addsubject',
                        title: 'Add Subject',
                        type: 'basic',
                        icon: 'heroicons_outline:book-open', // book for subjects
                        link: '/addsubject',
                    },
                    {
                        id: 'addchapter',
                        title: 'Add Chapters',
                        type: 'basic',
                        icon: 'heroicons_outline:document-text', // text document
                        link: '/addchapter',
                    },
                ],
            }
        );
    } else if (role === 2) {
        // School Admin - Limited Access
        navigation.push(
            {
                id: 'dashboard',
                title: 'Dashboard',
                type: 'basic',
                icon: 'heroicons_outline:home',
                link: '/dashboard',
            },
            {
                id: 'schoolManagement',
                title: 'My School',
                type: 'collapsable',
                icon: 'heroicons_outline:building-office',
                children: [
                    {
                        id: 'class',
                        title: 'Class',
                        type: 'basic',
                        icon: 'heroicons_outline:view-columns',
                        link: '/showclass',
                    },
                    {
                        id: 'addStudent',
                        title: 'Add Student',
                        type: 'basic',
                        icon: 'heroicons_outline:user-plus',
                        link: '/addStudent',
                    },
                    {
                        id: 'addTeacher',
                        title: 'Add Teacher',
                        type: 'basic',
                        icon: 'heroicons_outline:user-group', // teacher group
                        link: '/addteacher',
                    },
                    {
                        id: 'assignSubjectToTeacher',
                        title: 'Assign Subject',
                        type: 'basic',
                        icon: 'heroicons_outline:squares-plus', // assign link
                        link: '/assignSubject',
                    },
                    {
                        id: 'createQuestion',
                        title: 'Question',
                        type: 'basic',
                        icon: 'heroicons_outline:question-mark-circle', // quiz/question icon
                        link: '/addquestionadmin',
                    },
                ]
            }
        );
    } else if (role === 3) {
        // Teacher/Faculty
        navigation.push(
            {
                id: 'dashboard',
                title: 'Dashboard',
                type: 'basic',
                icon: 'heroicons_outline:home',
                link: '/dashboard',
            },
            {
                id: 'myClass',
                title: 'My Classes Subjects Assigned',
                type: 'basic',
                icon: 'heroicons_outline:clipboard-document-list',
                link: '/myclass',
            },
            {
                id: 'createQuestion',
                title: 'Question',
                type: 'basic',
                icon: 'heroicons_outline:question-mark-circle',
                link: '/addquestion',
            },
            {
                id: 'Exam',
                title: 'Exam',
                type: 'basic',
                icon: 'heroicons_outline:clipboard-check', // exam/approved test
                link: '/addexam',
            },
        );
    } else if (role === 4) {
        // Student/User
        navigation.push(
            {
                id: 'dashboard',
                title: 'Dashboard',
                type: 'basic',
                icon: 'heroicons_outline:home',
                link: '/dashboard',
            }
        );
    }

    return navigation; 
};
