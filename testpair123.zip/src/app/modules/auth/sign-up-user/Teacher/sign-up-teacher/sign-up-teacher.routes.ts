import { Routes } from '@angular/router';
import { SignUpTeacherComponent } from './sign-up-teacher.component';

export default [
    {
        path: '',
        component: SignUpTeacherComponent,
    },
] as Routes;
