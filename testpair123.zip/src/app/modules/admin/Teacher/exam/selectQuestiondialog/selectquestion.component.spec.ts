import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectquestionComponent } from './selectquestion.component';

describe('SelectquestionComponent', () => {
  let component: SelectquestionComponent;
  let fixture: ComponentFixture<SelectquestionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SelectquestionComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SelectquestionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
