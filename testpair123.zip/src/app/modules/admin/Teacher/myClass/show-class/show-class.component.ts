import { CommonModule, NgStyle } from '@angular/common';
import { Component, inject, ViewChild } from '@angular/core';
import { FormsModule, NgForm, ReactiveFormsModule, UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatTooltipModule } from '@angular/material/tooltip';
import { Router } from '@angular/router';
import { FuseDrawerComponent } from '@fuse/components/drawer';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

interface Class {
  row_id: string;
  name: string;


}



interface Column {
  name: string; // The column name/key (must match MatTable's columnDef)
  label: string; // The displayed label for checkbox and header
  visible: boolean; // Whether this column is currently shown
}

interface Teacher{
  email: string;
  name:string;
  row_id:string;
  role:string;
}
@Component({
  selector: 'app-show-class',
  imports: [
    MatTableModule,
    MatPaginatorModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    NgStyle, MatTooltipModule, MatSortModule,
    ReactiveFormsModule, MatFormFieldModule,
    MatSelectModule, CommonModule,
    FormsModule, 
    //FuseDrawerComponent
  ],
  templateUrl: './show-class.component.html',
  styleUrl: './show-class.component.scss'
})
export class ShowClassComponent {

  classData = new MatTableDataSource<Class>([]); // Use MatTableDataSource for pagination
  @ViewChild(MatPaginator) paginator!: MatPaginator;

  @ViewChild('addclassNgForm') addclassNgForm: NgForm;

  private _snackBar = inject(MatSnackBar);

  addclassForm: UntypedFormGroup;
  @ViewChild(MatSort) sort!: MatSort;



  TeacherDeatials: Teacher = {
    email: '',
    name:'',
    row_id:'',
    role:''
    };

  // classData:any;
  isSearchActive = false;

  constructor(
    private Apicontroller: ApicontrollerService,
    private router: Router,
    private _formBuilder: UntypedFormBuilder,


  ) {
    this.TeacherDeatials = JSON.parse(localStorage.getItem("userDeatials"));
    this.fetchclassdata()
  }


  ngOnInit(): void {
    this.addclassForm = this._formBuilder.group({
      classname: ['', Validators.required],
    });
  }



  async fetchclassdata() {
    console.log(" before data")

    try {
      const resp = await this.Apicontroller.fetchOwnlass('common', this.TeacherDeatials.row_id);
      //  this.classData.data = resp
      console.log("class data ------------------>", resp.data);

      const data = resp.data as Class[];

      // Add sr_no for each row (based on pagination if needed)
      this.classData.data = data.map((item, index) => ({
        ...item,
        sr_no: index + 1 + this.classData.paginator.pageIndex * this.classData.paginator.pageSize
      }));

      console.log("class data ------------------>", this.classData);


      // Enable sorting for custom fields like user_row_id (extract numeric part)
      this.classData.sortingDataAccessor = (item, property) => {
        if (property === 'row_id') {
          return Number(item.row_id?.split('_')[0]); // numeric part
        }
        return item[property];
      };



    } catch (error) {
      // console.error("Error fetching doctors:", error);
    }

  }


  get displayedColumns(): string[] {
    return this.columns.filter((c) => c.visible).map((c) => c.name);
  }


  columns: Column[] = [
    { name: 'sr_no', label: 'Sr.No', visible: true },
    { name: 'name', label: 'Class Name', visible: true },
    { name: 'actions', label: 'Actions', visible: true },


  ];


  editRowId: number | null = null;

  editRow(rowId: number) {
    this.editRowId = rowId;
  }

  isRowEditing(rowId: any) {
    return this.editRowId === rowId;
  }
  

  


  ngAfterViewInit() {
    // console.log(" ngAfterViewInit")
    this.classData.paginator = this.paginator; // Set paginator after view init
    this.classData.sort = this.sort

  }

  viewClassDetails(rowId: string) {
    // console.log("viewdata", doctor_rowId)
    this.router.navigate(['myclassdetails', rowId]);
  }


  

  refresh() {
    this.fetchclassdata()
  }
}
