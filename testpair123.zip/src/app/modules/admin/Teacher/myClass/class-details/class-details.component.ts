import { CommonModule, NgIf, NgStyle } from '@angular/common';
import { Component, inject, ViewChild } from '@angular/core';
import { FormsModule, NgForm, ReactiveFormsModule, UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatTooltipModule } from '@angular/material/tooltip';
import { ActivatedRoute, Router } from '@angular/router';
import { FuseDrawerComponent } from '@fuse/components/drawer';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

interface Subject {
  row_id: string;
  name: string;


}

interface Chapter {
  row_id: string;
  name: string;
}


interface Column {
  name: string; // The column name/key (must match MatTable's columnDef)
  label: string; // The displayed label for checkbox and header
  visible: boolean; // Whether this column is currently shown
}



interface Teacher{
  email: string;
  name:string;
  row_id:string;
  role:string;
}


@Component({
  selector: 'app-class-details',
  imports: [
    MatTableModule,
    MatPaginatorModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    NgStyle, MatTooltipModule, MatSortModule,
    ReactiveFormsModule, MatFormFieldModule,
    MatSelectModule, CommonModule,
    FormsModule, NgIf, 
    //FuseDrawerComponent,
  ],
  templateUrl: './class-details.component.html',
  styleUrl: './class-details.component.scss'
})
export class ClassDetailsComponent {
  subjectData = new MatTableDataSource<Subject>([]); // Use MatTableDataSource for pagination
  @ViewChild(MatPaginator) paginator!: MatPaginator;

  @ViewChild('addsubjectNgForm') addsubjectNgForm: NgForm;
  @ViewChild(MatSort) sort!: MatSort;

  private _snackBar = inject(MatSnackBar);

  addsubjectForm: UntypedFormGroup;

  chapter: Chapter[] = [];


  // classData:any;
  isSearchActive = false;
  classId: any;

  isviewbtn = false;

  TeacherDeatials: Teacher = {
    email: '',
    name:'',
    row_id:'',
    role:''
    };

  constructor(
    private Apicontroller: ApicontrollerService,
    private router: Router,
    private route: ActivatedRoute,
    private _formBuilder: UntypedFormBuilder,



  ) {
    this.TeacherDeatials = JSON.parse(localStorage.getItem("userDeatials"));
    this.classId = this.route.snapshot.paramMap.get('id');
    this.fetchschooldata()
  }


  ngOnInit(): void {
    this.addsubjectForm = this._formBuilder.group({
      subjectname: ['', Validators.required],
    });
  }

  async fetchschooldata() {
    console.log(" before data")

    
    try {

      const dataid = {
        class_id : this.classId,
        teacher_id:this.TeacherDeatials.row_id
       }

       console.log("dataa--",dataid)
  
      const resp = await this.Apicontroller.fetchClassSubjectByteacher('common',dataid);
      //  this.classData.data = resp
      console.log("school data ------------------>",);

      const data = resp as Subject[];

      // Add sr_no for each row (based on pagination if needed)
      this.subjectData.data = data.map((item, index) => ({
        ...item,
        sr_no: index + 1 + this.subjectData.paginator.pageIndex * this.subjectData.paginator.pageSize
      }));

      // Enable sorting for custom fields like user_row_id (extract numeric part)
      this.subjectData.sortingDataAccessor = (item, property) => {
        if (property === 'row_id') {
          return Number(item.row_id?.split('_')[0]); // numeric part
        }
        return item[property];
      };



    } catch (error) {
      // console.error("Error fetching doctors:", error);
    }

  }


  get displayedColumns(): string[] {
    return this.columns.filter((c) => c.visible).map((c) => c.name);
  }


  columns: Column[] = [
    { name: 'sr_no', label: 'Sr.No', visible: true },
    { name: 'name', label: 'Subject Name', visible: true },
    { name: 'actions', label: 'Actions', visible: true },


  ];


  editRowId: number | null = null;

  editRow(rowId: number) {
    this.editRowId = rowId;
  }

  isRowEditing(rowId: any) {
    return this.editRowId === rowId;
  }






  


  ngAfterViewInit() {
    // console.log(" ngAfterViewInit")
    this.subjectData.paginator = this.paginator; // Set paginator after view init
    this.subjectData.sort = this.sort

  }

  viewClassDetails(rowId: string) {
    // console.log("viewdata", doctor_rowId)
    // this.router.navigate(['classdetails', rowId]);
  }

  goback() {
    this.router.navigate(['/myclass'])
  }

  

  viewSubjectbtn(rowId: string) {
    this.router.navigate(['mysubjectdetails', rowId, this.classId]);

  }


  

  

  refresh() {
    this.fetchschooldata()

  }



  
}
