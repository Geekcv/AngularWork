import { HttpClient } from '@angular/common/http';
import { Component, inject, ViewChild } from '@angular/core';
import {
    FormsModule,
    NgForm,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { config } from '../../../../../../../config';
import { FuseDrawerComponent } from '@fuse/components/drawer';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { CommonModule, NgStyle } from '@angular/common';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSort, MatSortModule } from '@angular/material/sort';

interface classData{
  row_id:string;
  name:string
}

interface subjectData{
  row_id:string;
  name:string
}

interface Teacher{
  row_id:string;
  name:string
  user_row_id:string
}


interface SchoolAdmin {
  email: string;
  role: string;
  name: string;
  row_id: string;
  school_id: string;
}

  interface Column {
  name: string; // The column name/key (must match MatTable's columnDef)
  label: string; // The displayed label for checkbox and header
  visible: boolean; // Whether this column is currently shown
}


interface Teacherdata {
   row_id:string;
  class_name:string;
  class_row_id:string;
  subject_name:string;
  teacher_name:string

}


@Component({
  selector: 'app-assign-subject',
  imports: [
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatCheckboxModule,
    MatProgressSpinnerModule,
    MatSelectModule,
      FuseDrawerComponent,    
                 MatTableModule,
                    MatPaginatorModule,
                 
                    NgStyle , MatTooltipModule, MatSortModule,

                   CommonModule
                               
  ],
  templateUrl: './assign-subject.component.html',
  styleUrl: './assign-subject.component.scss'
})
export class AssignSubjectComponent {

  @ViewChild('assignSubjectNgForm') assignSubjectNgForm: NgForm;

  assignSubjectForm: UntypedFormGroup;
    teacherData = new MatTableDataSource<Teacherdata>([]); // Use MatTableDataSource for pagination
     @ViewChild(MatPaginator) paginator!: MatPaginator;
        @ViewChild(MatSort) sort!: MatSort;
     
  
  showAlert = false;
  role: any = '';
  config: any;

  subjectList = []
  classList = []
  teacherList = []

  SchoolAdminDeatials: SchoolAdmin = {
    email: '',
    name: '',
    role: '',
    row_id: '',
    school_id: ''
  };

   isSearchActive = false;

        columns: Column[] = [
    { name: 'sr_no', label: 'Sr.No', visible: true },
    { name: 'teacher_name', label: 'Teacher Name', visible: true },
    { name: 'subject_name', label: 'Subject', visible: true },
    { name: 'class_name', label: 'Class', visible: true },
   


    { name: 'actions', label: 'Actions', visible: true },


  ];

  constructor(
      private _formBuilder: UntypedFormBuilder,
      private api: ApicontrollerService,
  ) {
      this.config = config.apiBaseURL;
      this.role = localStorage.getItem('role');
      this.SchoolAdminDeatials = JSON.parse(localStorage.getItem("userDeatials"));
      this.fetchclassdata()
      this.fetchallTeacher()
      this.allsubject()

  }

  private _snackBar = inject(MatSnackBar);

  ngOnInit(): void {
      this.assignSubjectForm = this._formBuilder.group({
        class_id :['',Validators.required],
          subject_id:['',Validators.required],
          teacher_id:['',Validators.required]
          
      });
  }

  
   get displayedColumns(): string[] {
    return this.columns.filter((c) => c.visible).map((c) => c.name);
  }


  async addSubject(): Promise<void> {
      if (this.assignSubjectForm.invalid) {
          this.assignSubjectForm.markAllAsTouched();
          return;
      }

      const payload = {
          ...this.assignSubjectForm.value,
      };

      const resp = await this.api.assignSubject(payload);

      if (resp.status === 0) {
          this._snackBar.open(resp.msg, '', {
              duration: 3000,
              verticalPosition: 'top',
              horizontalPosition: 'center',
          });

          this.assignSubjectNgForm.resetForm();
           this.allsubject()
      } else {
          this._snackBar.open(resp.msg || 'Failed to add Assign Subject', '', {
              duration: 3000,
              verticalPosition: 'top',
              horizontalPosition: 'center',
          });
      }
  }


    async fetchclassdata(){
        // this.selectedValue = (event.target as HTMLSelectElement).value;

        const resp = await this.api.fetchSchoolclass('common', this.SchoolAdminDeatials.school_id);
        console.log("resp",resp)
        this.classList = resp as classData[]
       

      }

      async fetchallTeacher(){
    
      const resp = await this.api.fetchallSchoolownTeacher('common',this.SchoolAdminDeatials.school_id);
      console.log("teacher data",resp)
      this.teacherList = resp as Teacher[]

  }

  // 

  selectedValueclass:any;

    async onSelectionChangeclass(event: Event){
        // this.selectedValue = (event.target as HTMLSelectElement).value;
        console.log('Selected  value:---------', this.selectedValueclass);

        // const resp = await this.api.fetchAllsubjectOfclass('common', this.selectedValueclass);
        const resp = await this.api.fetchClassSubject('common', this.selectedValueclass);

        console.log("resp",resp)
        this.subjectList = resp as subjectData[]
       

      }

      async allsubject(){     
      
         try {
        const resp = await this.api.fetchallSubjectOfteacher('common',this.SchoolAdminDeatials.school_id);

        console.log("subjects--------->",resp)
      //  this.classData.data = resp
      console.log("Teacher data ------------------>", resp);

      const data = resp as Teacherdata[];

      console.log("teacher data",data)

      // Add sr_no for each row (based on pagination if needed)
      this.teacherData.data = data.map((item, index) => ({
        ...item,
        sr_no: index + 1 + this.teacherData.paginator.pageIndex * this.teacherData.paginator.pageSize
      }));

      console.log("teacherData.data ------------------>", this.teacherData.data);


      // Enable sorting for custom fields like user_row_id (extract numeric part)
      this.teacherData.sortingDataAccessor = (item, property) => {
        if (property === 'row_id') {
          return Number(item.row_id?.split('_')[0]); // numeric part
        }
        return item[property];
      };



    } catch (error) {
      // console.error("Error fetching doctors:", error);
    }





      }


      filterByQuery(query: string): void {
    const trimmedQuery = query.trim().toLowerCase();

    if (trimmedQuery) {
      this.isSearchActive = true;
      this.teacherData.filter = trimmedQuery;

      if (this.teacherData.paginator) {
        this.teacherData.paginator.firstPage(); // Reset to first page after search
      }
    } else {
      this.isSearchActive = false;
      this.teacherData.filter = ''; // Clear filter

      // Reset the paginator and restore original data
      setTimeout(() => {
        this.teacherData.paginator = this.paginator;
      });
    }
  }

    editRowId: number | null = null;

  editRow(rowId: number) {
    this.editRowId = rowId;
  }

  isRowEditing(rowId: any) {
    return this.editRowId === rowId;
  }

  refresh(){

  }

    ngAfterViewInit() {
    // console.log(" ngAfterViewInit")
    this.teacherData.paginator = this.paginator; // Set paginator after view init
    this.teacherData.sort = this.sort

  }

  viewteacherDetails(){

  }
  cancelEdit(){
    this.editRowId = null;

  }
  saveRow(data:any){
    this.editRowId = null;

  }

 async teacherUnassigned(row:any){
    console.log("data---------->",row) 

      var subjectId = {
         "row_id":row
      }

      const resp = await this.api.SubjectUnassinged('common',subjectId);
      console.log("res--->",resp)

      this.allsubject()

  }
}
