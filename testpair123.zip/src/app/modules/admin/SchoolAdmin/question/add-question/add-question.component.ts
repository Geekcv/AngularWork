import { CommonModule } from '@angular/common';
import { Component, inject, ViewChild } from '@angular/core';
import {
    FormArray,
    FormsModule,
    NgForm,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectChange, MatSelectModule } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { config } from '../../../../../../../config';
import { HttpClient } from '@angular/common/http';

interface ChapterData {
    chapter_id: string;
    chapter_name: string;
}

interface Teacher {
    email: string;
    name: string;
    row_id: string;
    role: string;
}

interface SchoolAdmin {
    email: string;
    role: string;
    name: string;
    row_id: string;
    school_id:string
  }


  interface Class {
  row_id: string;
  name: string;
}

interface Subject {
  row_id: string;
  name: string;
}

interface Chapter {
    row_id: string;
    name: string;
}


@Component({
    selector: 'app-add-question',
    standalone: true,
    imports: [
        FormsModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatInputModule,
        MatButtonModule,
        MatIconModule,
        MatCheckboxModule,
        MatProgressSpinnerModule,
        MatSelectModule,
        CommonModule,
    ],
    templateUrl: './add-question.component.html',
    styleUrl: './add-question.component.scss',
})
export class AddQuestionComponent {
    @ViewChild('questionNgForm') questionNgForm: NgForm;

    questionForm: UntypedFormGroup;
    role: string = '';
    config: any;
    showOptions = false;

    //  Dynamic Arrays for Match and Arrange
    matchPairs: { left: string; right: string }[] = [{ left: '', right: '' }];
    arrangeList: { text: string }[] = [{ text: '' }];

    subjectList = [];
    chapterList: ChapterData[] = [];

    TeacherDeatials: Teacher = {
        email: '',
        name: '',
        row_id: '',
        role: '',
    };

      SchoolAdminDeatials: SchoolAdmin = {
        email: '',
        name: '',
        role:'',
        row_id: '',
        school_id:''
      };

    selectedFile: any | null = null;

    private _snackBar = inject(MatSnackBar);

    constructor(
        private _formBuilder: UntypedFormBuilder,
        private _router: Router,
        private api: ApicontrollerService,
         private http: HttpClient
    ) {
        this.config = config.apiBaseURL;
        this.role = localStorage.getItem('role') || '';

        
        this.TeacherDeatials = JSON.parse(
            localStorage.getItem('userDeatials') || '{}'
        );

        this.SchoolAdminDeatials = JSON.parse(
            localStorage.getItem('userDeatials') || '{}'
        );

        this.fetchCompletedChapter();
        this.fetchclassdata();
        this.fetchallteacher()
    }

    ngOnInit(): void {
        this.initForm();
    }

    initForm(): void {
        this.questionForm = this._formBuilder.group({
            chapter_id: ['', Validators.required],
            class_id:['',Validators.required],
            subject_id:['',Validators.required],
            type: ['', Validators.required],
            content: ['', Validators.required],
            option_a: [''],
            option_b: [''],
            option_c: [''],
            option_d: [''],
            correct_option: [''], //  For MCQ single answer
            correct_options: this._formBuilder.array([]), //  For multiple answers
            tf_answer: [''],
            fill_answer: [''],
            coding_output: [''],
            passage: [''],
            description: [''],
            cloze_text: [''],
        });
    }

    get correctOptionsArray(): FormArray {
        return this.questionForm.get('correct_options') as FormArray;
    }

    onTypeChange(): void {
        const type = this.questionForm.get('type')?.value;
        this.showOptions = [
            'mcq',
            'checkbox',
            'image_mcq',
            'video_mcq',
            'audio_mcq',
        ].includes(type);

        if (type === 'match') {
            this.matchPairs = [{ left: '', right: '' }];
        }

        if (type === 'arrange') {
            this.arrangeList = [{ text: '' }];
        }
    }

    addMatchPair(): void {
        this.matchPairs.push({ left: '', right: '' });
    }

    addArrangeStatement(): void {
        this.arrangeList.push({ text: '' });
    }

    toggleCheckbox(opt: string, checked: boolean): void {
        if (checked) {
            this.correctOptionsArray.push(this._formBuilder.control(opt));
        } else {
            const index = this.correctOptionsArray.controls.findIndex(
                (x: any) => x.value === opt
            );
            if (index >= 0) {
                this.correctOptionsArray.removeAt(index);
            }
        }
    }

         filepath:any;
      mediatype:any;

    onFileSelected(event: Event): void {
         const input = event.target as HTMLInputElement;
    
        if (input.files && input.files.length > 0) {
            const file = input.files[0];
    
            //  Show preview instantly (before upload)
            const reader = new FileReader();
           
            reader.readAsDataURL(file);
    
            // Upload to server
            const formData = new FormData();
            formData.append('file', file);
    
            this.http.post(`${this.config}/common/upload`, formData).subscribe({
                next: (response: any) => {
                    if (response?.data) {
                        this.filepath = response.data.foPa || response.data.filePath;
                        this.mediatype = response.data.mimetype;
    
                        // Update the AdminDeatials so it's saved on submit
                        this.selectedFile = this.filepath;
                    }
                },
                error: (err) => console.error('Upload failed', err),
            });
        }

    }

    async submitQuestion(): Promise<void> {
        if (this.questionForm.invalid) {
            this.questionForm.markAllAsTouched();
            return;
        }

        const formData = this.questionForm.value;
        let options: any = null;
        let correct_answer: any = {};

        switch (formData.type) {
            case 'mcq':
            case 'image_mcq':
            case 'video_mcq':
            case 'audio_mcq':
                options = [
                    { label: 'A', text: formData.option_a },
                    { label: 'B', text: formData.option_b },
                    { label: 'C', text: formData.option_c },
                    { label: 'D', text: formData.option_d },
                ];
                correct_answer = { selected: formData.correct_option };
                break;

            case 'checkbox':
                options = [
                    { label: 'A', text: formData.option_a },
                    { label: 'B', text: formData.option_b },
                    { label: 'C', text: formData.option_c },
                    { label: 'D', text: formData.option_d },
                ];
                correct_answer = { selected: formData.correct_options }; //  Now working
                break;

            case 'tf':
                correct_answer = { selected: formData.tf_answer === 'true' };
                break;

            case 'fill':
            case 'numeric':
            case 'short':
            case 'long':
                correct_answer = { answers: [formData.fill_answer] };
                break;

            case 'match':
                options = this.matchPairs;
                correct_answer = { pairs: this.matchPairs };
                break;

            case 'arrange':
                options = this.arrangeList;
                correct_answer = {
                    order: this.arrangeList
                        .map((item) => item.text)
                        .filter(Boolean),
                };
                break;

            case 'coding':
                correct_answer = { expected_output: formData.coding_output };
                break;

            default:
                correct_answer = {};
        }

        const payload = {
            chapter_id: formData.chapter_id,
            type: formData.type,
            content: formData.content,
            options: options,
            correct_answer: correct_answer,
            created_by: this.TeacherDeatials.row_id,
            media_file:this.selectedFile || null
        };

        console.log(' Final Payload: --------------->>>>>', payload);

        const resp = await this.api.addQuestion(payload);

        if (resp.status === 0) {
            this._snackBar.open(resp.msg, '', {
                duration: 3000,
                verticalPosition: 'top',
                horizontalPosition: 'center',
            });

            this.questionNgForm.resetForm();
            this.initForm();
            this.showOptions = false;
            this.matchPairs = [{ left: '', right: '' }];
            this.arrangeList = [{ text: '' }];
            this.selectedFile = null;
        } else {
            this._snackBar.open(resp.msg || 'Failed to add question', '', {
                duration: 3000,
                verticalPosition: 'top',
                horizontalPosition: 'center',
            });
        }
    }

  
    async fetchCompletedChapter() {

        if (this.role === '3') {
            var data = {
                "teacher_id": this.TeacherDeatials.row_id
            }

            console.log("theacher")
            const resp = await this.api.fetchAllcompletedChapter(
                'common',
                data
            );
            this.chapterList = resp.data as ChapterData[];
        }

        if (this.role === '2') {
            console.log("school")
            var dataSchool = {
                "school_id": this.SchoolAdminDeatials.school_id
            }

            const resp = await this.api.fetchAllcompletedChapter(
                'common',
                dataSchool
            );
            this.chapterList = resp.data as ChapterData[];

        }

    }


   classList: Class[] = [];


     async fetchclassdata() {
    console.log(" before data")

    try {
      const resp = await this.api.fetchOwnlass('common', this.TeacherDeatials.row_id);
      //  this.classData.data = resp
      console.log("class data ------------------>", resp.data);

       this.classList  = resp.data as Class[];    


    } catch (error) {
      // console.error("Error fetching doctors:", error);
    }

  }



   subList: Subject[] = [];

  selectedclassValue:any;

 async onSelectionclassChange(event:MatSelectChange){

    console.log("data---->",event.value)

    const dataid = {
        class_id : event.value,
        teacher_id:this.TeacherDeatials.row_id
       }

       console.log("dataa--",dataid)
  
      const resp = await this.api.fetchClassSubjectByteacher('common',dataid);
      //  this.classData.data = resp
      console.log("school data ------------------>",resp);

      this.subList = resp as Subject[];

      console.log("sub lsit ",this.subList)

  }



   chapList: Subject[] = [];

  selectedsubValue:any
   async onSelectionsubChange(event:MatSelectChange){

    console.log("data---->",event.value)

    
  
        const resp = await this.api.fetchSubjectChapter(
                'common',
                 event.value
            );
            //  this.classData.data = resp
            console.log('chapter data ------------------>', resp);

            this.chapList = resp as Chapter[];

  }


  teacherlist : Teacher[] = []
  selectedteacherValue:any;


  async onSelectionteacherChange(event:MatSelectChange){

    console.log("event --->",event.value)
    const resp = await this.api.fetchOwnlass('common', event.value);
      //  this.classData.data = resp
      console.log("class data ------------------>", resp);

       this.classList  = resp as Class[]; 

       console.log("classlsit--->",this.classList)
  }

  async fetchallteacher(){
     const resp = await this.api.fetchAllteacherOfSchool('common', this.SchoolAdminDeatials.school_id);
      //  this.classData.data = resp
      console.log("Teacher data ------------------>", resp);

      this.teacherlist = resp as Teacher[];
  }
}
