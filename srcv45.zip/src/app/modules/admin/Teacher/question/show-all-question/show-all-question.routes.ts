import { Routes } from '@angular/router';
import { ShowAllQuestionComponent } from './show-all-question.component';

export default [
    {
        path: '',
        component: ShowAllQuestionComponent,
    },
] as Routes;
