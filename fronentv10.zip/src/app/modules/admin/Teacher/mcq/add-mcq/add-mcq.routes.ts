import { Routes } from '@angular/router';
import { AddMCQComponent } from './add-mcq.component';

export default [
    {
        path: '',
        component: AddMCQComponent,
    },
] as Routes;
