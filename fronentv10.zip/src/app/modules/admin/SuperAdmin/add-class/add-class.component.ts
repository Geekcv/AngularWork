import { Component, inject, ViewChild } from '@angular/core';
import {
    FormsModule,
    NgForm,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { config } from '../../../../../../config';
import { FuseDrawerComponent } from '@fuse/components/drawer';
import { CommonModule, NgStyle } from '@angular/common';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSort, MatSortModule } from '@angular/material/sort';

interface board {
 row_id:string;
  name:string;
}


interface classData{
  row_id:string;
  name:string;
  board_name:string;
}

  interface Column {
  name: string; // The column name/key (must match MatTable's columnDef)
  label: string; // The displayed label for checkbox and header
  visible: boolean; // Whether this column is currently shown
}


@Component({
  selector: 'app-add-class',
  imports: [
   FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatCheckboxModule,
    MatProgressSpinnerModule,
    MatSelectModule,
      FuseDrawerComponent,
            NgStyle,
              MatTableModule,
                            MatPaginatorModule,
                         
                            NgStyle , MatTooltipModule, MatSortModule,
                          
                                CommonModule,
  ],
  templateUrl: './add-class.component.html',
  styleUrl: './add-class.component.scss'
})
export class AddClassComponent {
 @ViewChild('classNgForm') classNgForm: NgForm;

  classForm: UntypedFormGroup;
  showAlert = false;
  role: any = '';
  config: any;
  
   isSearchActive = false;
      classData = new MatTableDataSource<classData>([]); // Use MatTableDataSource for pagination
       @ViewChild(MatPaginator) paginator!: MatPaginator;
         @ViewChild(MatSort) sort!: MatSort;

  constructor(
      private _formBuilder: UntypedFormBuilder,
      private _router: Router,
      private api: ApicontrollerService,
  ) {
      this.config = config.apiBaseURL;
      this.role = localStorage.getItem('role');
      this.fetchallboard()
      this.fetchallClass()
  }

  private _snackBar = inject(MatSnackBar);

  ngOnInit(): void {
      this.classForm = this._formBuilder.group({
          classname: ['', Validators.required],         
          board_id: ['', Validators.required], 
          
      });
  }

    get displayedColumns(): string[] {
    return this.columns.filter((c) => c.visible).map((c) => c.name);
  }

  // boardList = [
  //     { row_id: '1729833318838_Ir5A', name: 'CBSE' },
  //     { row_id: '1729862517377_iMzd', name: 'RBSE' },
  // ];

  boardList = []

  getBoardNameById(rowId: string): string {
    console.log("rowid--------",rowId)
    const board = this.boardList.find(b => b.name === rowId);
    return board ? board.name : 'N/A';
  }
  
  trackByBoardId(index: number, board: any): string {
    return board.row_id;
  }
  
  

  async addClass(addclass:any): Promise<void> {
      if (this.classForm.invalid) {
          this.classForm.markAllAsTouched();
          return;
      }

      const payload = {
          ...this.classForm.value,
          created_by: localStorage.getItem('row_id') || '', // optional
      };

      const resp = await this.api.createclass(payload);

      if (resp.status === 0) {
          this._snackBar.open(resp.msg, '', {
              duration: 3000,
              verticalPosition: 'top',
              horizontalPosition: 'center',
          });

          this.classNgForm.resetForm();
          addclass.close()
      this.fetchallClass()

      } else {
          this._snackBar.open(resp.msg || 'Failed to add class', '', {
              duration: 3000,
              verticalPosition: 'top',
              horizontalPosition: 'center',
          });
      }
  }

    async fetchallboard(){
    // 
      const resp = await this.api.fetchallBoard();
      this.boardList = resp as board[]

  }

            columns: Column[] = [
    { name: 'sr_no', label: 'Sr.No', visible: true },
    { name: 'name', label: 'Class Name', visible: true },   
    { name: 'board_name', label: 'Board Name', visible: true },   
    { name: 'actions', label: 'Actions', visible: true },


  ];

   editRowId: number | null = null;

   editRow(rowId: number) {
    this.editRowId = rowId;
  
    // Convert number to string to match string row_id
    const row = this.classData.data.find((r) => r.row_id === String(rowId));
  
    if (row) {
      const match = this.boardList.find((b) => b.name === row.board_name);
      if (match) {
        row.board_name = match.row_id;
      }
    }
  }
  
  

  isRowEditing(rowId: any) {
    return this.editRowId === rowId;
  }

  

     async saveRow(row: any) {
    console.log("row-----", row)
    this.editRowId = null;

    try {
      const resp = await this.api.createclass(row);
      // console.log('doctors update data:', resp);
      if (resp.status === 0) {
        this._snackBar.open(resp.msg, '', {
          duration: 3000,
          verticalPosition: 'top',
          horizontalPosition: 'center',
        });
      this.fetchallClass()

      } else {
        this._snackBar.open(resp.msg, '', {
          duration: 4000,
          verticalPosition: 'top',
          horizontalPosition: 'center',
        });
      }
    } catch (error) {
      console.error('Error updating board:', error);
    }
   
  }

  cancelEdit() {
    this.editRowId = null;
  }


    async fetchallClass() {
    console.log(" before data")

    try {
     const resp = await this.api.fetchallclass('common');

      const data = resp as classData[];

      console.log("class data",data)

      // Add sr_no for each row (based on pagination if needed)
      this.classData.data = data.map((item, index) => ({
        ...item,
        sr_no: index + 1 + this.classData.paginator.pageIndex * this.classData.paginator.pageSize
      }));

      console.log("class.data ------------------>", this.classData.data);


      // Enable sorting for custom fields like user_row_id (extract numeric part)
      this.classData.sortingDataAccessor = (item, property) => {
        if (property === 'row_id') {
          return Number(item.row_id?.split('_')[0]); // numeric part
        }
        return item[property];
      };



    } catch (error) {
      // console.error("Error fetching doctors:", error);
    }

  }

   ngAfterViewInit() {
    // console.log(" ngAfterViewInit")
    this.classData.paginator = this.paginator; // Set paginator after view init
    this.classData.sort = this.sort

  }

    filterByQuery(query: string): void {
    const trimmedQuery = query.trim().toLowerCase();

    if (trimmedQuery) {
      this.isSearchActive = true;
      this.classData.filter = trimmedQuery;

      if (this.classData.paginator) {
        this.classData.paginator.firstPage(); // Reset to first page after search
      }
    } else {
      this.isSearchActive = false;
      this.classData.filter = ''; // Clear filter

      // Reset the paginator and restore original data
      setTimeout(() => {
        this.classData.paginator = this.paginator;
      });
    }
  }
}
