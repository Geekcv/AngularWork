import { HttpClient } from '@angular/common/http';
import { Component, inject, ViewChild } from '@angular/core';
import {
    FormsModule,
    NgForm,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { config } from '../../../../../../config';
import { FuseDrawerComponent } from '@fuse/components/drawer';
import { CommonModule, NgStyle } from '@angular/common';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSort, MatSortModule } from '@angular/material/sort';


interface board {
 row_id:string;
  name:string;
}

interface classData{
  row_id:string;
  name:string
}

  interface Column {
  name: string; // The column name/key (must match MatTable's columnDef)
  label: string; // The displayed label for checkbox and header
  visible: boolean; // Whether this column is currently shown
}

interface SubjectData {
 row_id:string;
  name:string;
  class_name:string;
  board_name:string;
}

@Component({
  selector: 'app-add-subject',
  imports: [
     FormsModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatInputModule,
        MatButtonModule,
        MatIconModule,
        MatCheckboxModule,
        MatProgressSpinnerModule,
        MatSelectModule,
           FuseDrawerComponent,
                    NgStyle,
                      MatTableModule,
                                    MatPaginatorModule,
                                 
                                    NgStyle , MatTooltipModule, MatSortModule,
                                  
                                        CommonModule,
  ],
  templateUrl: './add-subject.component.html',
  styleUrl: './add-subject.component.scss'
})
export class AddSubjectComponent {
 @ViewChild('subjectNgForm') subjectNgForm: NgForm;

  subjectForm: UntypedFormGroup;
  showAlert = false;
  role: any = '';
  config: any;


   isSearchActive = false;
        subjectData = new MatTableDataSource<SubjectData>([]); // Use MatTableDataSource for pagination
         @ViewChild(MatPaginator) paginator!: MatPaginator;
           @ViewChild(MatSort) sort!: MatSort;

  constructor(
      private _formBuilder: UntypedFormBuilder,
      private _router: Router,
      private api: ApicontrollerService,
  ) {
      this.config = config.apiBaseURL;
      this.role = localStorage.getItem('role');
      this.fetchallboard();
      this.fetchallsubject()
  }

  private _snackBar = inject(MatSnackBar);

  ngOnInit(): void {
      this.subjectForm = this._formBuilder.group({
          subjectname: ['', Validators.required],
          board_id:['',Validators.required],
          class_id: ['', Validators.required], 
         
      });
  }

  // boardList = [
  //     { row_id: '1729833318838_Ir5A', name: 'CBSE' },
  //     { row_id: '1729862517377_iMzd', name: 'RBSE' },
  // ];

  boardList = [];

    get displayedColumns(): string[] {
    return this.columns.filter((c) => c.visible).map((c) => c.name);
  }


  async addSubject(addsubject): Promise<void> {
      if (this.subjectForm.invalid) {
          this.subjectForm.markAllAsTouched();
          return;
      }

      const payload = {
          ...this.subjectForm.value,
      };

      const resp = await this.api.addSubject(payload);

      if (resp.status === 0) {
          this._snackBar.open(resp.msg, '', {
              duration: 3000,
              verticalPosition: 'top',
              horizontalPosition: 'center',
          });

          this.subjectNgForm.resetForm();
          addsubject.close()
      this.fetchallsubject()


      } else {
          this._snackBar.open(resp.msg || 'Failed to add subject', '', {
              duration: 3000,
              verticalPosition: 'top',
              horizontalPosition: 'center',
          });
      }
  }

 async fetchallboard(){
    // 
      const resp = await this.api.fetchallBoard();
      this.boardList = resp as board[]

  }


  
  selectedValue: string = '';
  classList = []

     async onSelectionChange(event: Event){
        // this.selectedValue = (event.target as HTMLSelectElement).value;
        console.log('Selected value:---------', this.selectedValue);

        const resp = await this.api.fetchAllclassOfboard('common', this.selectedValue);
        console.log("resp",resp)
        this.classList = resp as classData[]
       

      }

      
            columns: Column[] = [
    { name: 'sr_no', label: 'Sr.No', visible: true },
    { name: 'name', label: 'Subject Name', visible: true },   
    { name: 'class_name', label: 'Class Name', visible: true },
    { name: 'board_name', label: 'Board Name', visible: true },
    { name: 'actions', label: 'Actions', visible: true },

  ];

   editRowId: number | null = null;

  editRow(rowId: number) {
    this.editRowId = rowId;
  }

  isRowEditing(rowId: any) {
    return this.editRowId === rowId;
  }

     async saveRow(row: any) {
    console.log("row-----", row)
    this.editRowId = null;


    //    try {
    //   const resp = await this.api.addSubject(row);
    //   // console.log('doctors update data:', resp);
    //   if (resp.status === 0) {
    //     this._snackBar.open(resp.msg, '', {
    //       duration: 3000,
    //       verticalPosition: 'top',
    //       horizontalPosition: 'center',
    //     });
    //   this.fetchallsubject()

    //   } else {
    //     this._snackBar.open(resp.msg, '', {
    //       duration: 4000,
    //       verticalPosition: 'top',
    //       horizontalPosition: 'center',
    //     });
    //   }
    // } catch (error) {
    //   console.error('Error updating board:', error);
    // }
   
  }

  cancelEdit() {
    this.editRowId = null;
  }

     async fetchallsubject() {
    console.log(" before data")

    try {
     const resp = await this.api.fetchallSubject('common');

      const data = resp as SubjectData[];

      console.log("class data",data)

      // Add sr_no for each row (based on pagination if needed)
      this.subjectData.data = data.map((item, index) => ({
        ...item,
        sr_no: index + 1 + this.subjectData.paginator.pageIndex * this.subjectData.paginator.pageSize
      }));

      console.log("class.data ------------------>", this.subjectData.data);


      // Enable sorting for custom fields like user_row_id (extract numeric part)
      this.subjectData.sortingDataAccessor = (item, property) => {
        if (property === 'row_id') {
          return Number(item.row_id?.split('_')[0]); // numeric part
        }
        return item[property];
      };



    } catch (error) {
      // console.error("Error fetching doctors:", error);
    }

  }

   ngAfterViewInit() {
    // console.log(" ngAfterViewInit")
    this.subjectData.paginator = this.paginator; // Set paginator after view init
    this.subjectData.sort = this.sort

  }

  filterByQuery(query: string): void {
    const trimmedQuery = query.trim().toLowerCase();

    if (trimmedQuery) {
      this.isSearchActive = true;
      this.subjectData.filter = trimmedQuery;

      if (this.subjectData.paginator) {
        this.subjectData.paginator.firstPage(); // Reset to first page after search
      }
    } else {
      this.isSearchActive = false;
      this.subjectData.filter = ''; // Clear filter

      // Reset the paginator and restore original data
      setTimeout(() => {
        this.subjectData.paginator = this.paginator;
      });
    }
  }
}
