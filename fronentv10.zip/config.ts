export const config = {
    
    apiBaseURL : 'http://192.168.114.1:3000', 

    // apiBaseURL:'https://research.ftisindia.com'

    appVersion: '1.1.1'
}

