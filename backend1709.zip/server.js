const express = require("express");
const app = express()
// const fileUpload = require('express-fileupload');
require('dotenv').config();
const path = require("path");
const bodyParser = require("body-parser");

const fs = require('fs');
const cors = require('cors');
const common = require('./public/lib/common.js');
const auth1 = require("./public/lib/google_auth/connect");

const PORT = process.env.SERVER_PORT || 3000;

// require("./public/lib/google_auth/passport.js"); 

app.use(cors());


const session = require("express-session");
const passport = require("passport");

app.use(
  session({
    secret: "aiims_research_jwt_secret729@",
    resave: false,
    saveUninitialized: true,
  })
);

app.use(passport.initialize());
app.use(passport.session());

passport.use(auth1.googleAuthentication());

// Required session handlers
passport.serializeUser((user, done) => {
  done(null, user); // Store user object (or just user.id if preferred)
});

passport.deserializeUser((user, done) => {
  done(null, user); // Retrieve full user (or lookup by ID)
});


app.use(bodyParser.json({ limit: '100mb', type: "application/json" }));
app.use(bodyParser.urlencoded({ limit: '5000mb', extended: true, parameterLimit: 50000 }));

app.use(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});
app.use('/common', common);
app.use('/', express.static('public'));
app.use("/node_modules", express.static(path.join(__dirname, "node_modules")));
app.use("/bower_components", express.static(path.join(__dirname, "bower_components")));

app.use(express.static(path.join(__dirname, 'public/frontend')));
app.get('/*', (req,res)=>{
    res.sendFile(path.join(__dirname, 'public/frontend/index.html'))
})
//////////////--------------------File Upload----------------------------------///////////////

// upload file path
// const FILE_PATH = 'uploads';
// var storage = multer.diskStorage({
//     destination: function (req, file, cb) {
//         cb(null, `./public/${FILE_PATH}/`)
//     },
//     filename: function (req, file, cb) {
//         cb(null, Date.now() + "_" + file.originalname)
//     }
// })

// var upload = multer({ storage: storage })
// // const upload = multer({
// //     dest: `./public/${FILE_PATH}/`
// // });
// app.post('/upload', upload.single('file'), async (req, res) => {
//     try {
//         const file = req.file;
//         // console.log(file);
//         // make sure file is available
//         if (!file) {
//             res.status(400).send({
//                 status: false,
//                 data: 'No file is selected.'
//             });
//         } else {
//             res.send({
//                 status: true,
//                 message: 'File is uploaded.',
//                 data: {
//                     name: file.filename,
//                     originalname: file.originalname,
//                     foPa: FILE_PATH + "/" + file.filename,
//                     mimetype: file.mimetype,
//                     size: file.size
//                 }
//             });
//         }
//     } catch (err) {
//         res.status(500).send(err);
//     }
// });

app.listen(PORT, function () {
    console.log("app is listening on port " + PORT);
});