import { Routes } from '@angular/router';
import { AddBoardComponent } from './add-board.component';

export default [
    {
        path: '',
        component: AddBoardComponent,
    },
] as Routes;
