import { HttpClient } from '@angular/common/http';
import { Component, inject, ViewChild } from '@angular/core';
import {
    FormsModule,
    NgForm,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectChange, MatSelectModule } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { config } from '../../../../../../../config';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core'; // For native date adapter
import dashboardRoutes from 'app/modules/admin/dashboard/dashboard.routes';
import { CommonModule } from '@angular/common';

interface ChapterData {
    chapter_id: string;
    chapter_name: string;
}


interface Teacher{
  email: string;
  name:string;
  row_id:string;
  role:string;
}

interface SchoolAdmin {
    email: string;
    role: string;
    name: string;
    row_id: string;
    school_id:string
  }


@Component({
  selector: 'app-add-exam',
  imports: [FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatCheckboxModule,
    MatProgressSpinnerModule,
    MatSelectModule,MatDatepickerModule,MatNativeDateModule,CommonModule,                  
  ],
  templateUrl: './add-exam.component.html',
  styleUrl: './add-exam.component.scss'
})
export class AddExamComponent {
  @ViewChild('examNgForm') examNgForm: NgForm;

  examForm: UntypedFormGroup;
  showAlert = false;
  role: any = '';
  config: any;

  chapterList = []

  
      SchoolAdminDeatials: SchoolAdmin = {
        email: '',
        name: '',
        role:'',
        row_id: '',
        school_id:''
      };
  
  TeacherDeatials: Teacher = {
    email: '',
    name:'',
    row_id:'',
    role:''
    };

  constructor(
      private _formBuilder: UntypedFormBuilder,
      private _router: Router,
      private api: ApicontrollerService,
  ) {
      this.config = config.apiBaseURL;
      this.role = localStorage.getItem('role');
    this.TeacherDeatials = JSON.parse(localStorage.getItem("userDeatials"));

      this.SchoolAdminDeatials = JSON.parse(
            localStorage.getItem('userDeatials') || '{}'
        );

//  this.fetchCompletedChapter();
//  this.fetchquestion()
this.fetchexam()
this.fetchallTeacher()
    }

  private _snackBar = inject(MatSnackBar);

  ngOnInit(): void {
    this.examForm = this._formBuilder.group({     
      chapter_id: ['', Validators.required],
      teacher_id :['',Validators.required],
      name: ['', Validators.required],
      total_marks: [null],
      passing_marks: [null],
      duration_minutes: [null],
      scheduled_on: [null],
    });
    
  }

  // boardList = [
  //     { row_id: '1729833318838_Ir5A', name: 'CBSE' },
  //     { row_id: '1729862517377_iMzd', name: 'RBSE' },
  // ];


  async submitExam(): Promise<void> {
      if (this.examForm.invalid) {
          this.examForm.markAllAsTouched();
          return;
      }

 
    

     
         const payload = {
          ...this.examForm.value,created_by:this.selectedValueclass
      };
    
     

      const resp = await this.api.addExam(payload);
      console.log("resp",resp)

      if (resp.status === 0) {
          this._snackBar.open(resp.msg, '', {
              duration: 3000,
              verticalPosition: 'top',
              horizontalPosition: 'center',
          });

          this.examNgForm.resetForm();
          // this.teacherList = []
      } else {
          this._snackBar.open(resp.msg || 'Failed to add chapter', '', {
              duration: 3000,
              verticalPosition: 'top',
              horizontalPosition: 'center',
          });
      }
  }

     async fetchCompletedChapter() {

       
            var data = {
                "teacher_id": this.TeacherDeatials.row_id
            }

            console.log("theacher")
            const resp = await this.api.fetchAllcompletedChapter(
                'common',
                data
            );
            this.chapterList = resp.data as ChapterData[];
               

    }

    async fetchquestion (){
       const resp = await this.api.fetchAllquestionOfchapter(
            'common',
            '1753766673964_U9RB'
        );

        console.log("fetch question ----->",resp)
    }

     async fetchexam (){
       const resp = await this.api.fetchexam(
            'common',
            '1754545945243_zDCB'
        );

        console.log("fetch exam ----->",resp)
    }

  teacherList = []

     async fetchallTeacher(){
    
      const resp = await this.api.fetchallSchoolownTeacher('common',this.SchoolAdminDeatials.school_id);
      console.log("teacher data",resp)
      this.teacherList = resp as Teacher[]

  }

    selectedValueclass:any;

    async onSelectionChangeChapter(event: any){
        this.selectedValueclass = event.value;
        console.log(' teacher Selected  value:---------',event.value );

          console.log("theacher")

          var data = {
                "teacher_id": event.value
            }

            const resp = await this.api.fetchAllcompletedChapter(
                'common',
                data
            );

            console.log("data----------->",resp)
            //if (resp.status === '0') {
                
                this.chapterList = resp.data as ChapterData[];
                return;
            //}
       
            //this.chapterList = []

      }
}
