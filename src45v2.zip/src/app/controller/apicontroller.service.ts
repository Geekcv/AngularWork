import { Injectable } from '@angular/core';
import { ApiService } from '../Services/api.service';

@Injectable({
    providedIn: 'root',
})
export class ApicontrollerService {
    constructor(private apiService: ApiService) { }

    async loginuser(logindata: any, url: string = 'common/user') {
        const data = {
            fn: 'common_fn',
            se: 'lo_us',
            data: logindata,
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

    // --------------------------------

    async createschool(schooldata: any, url: string = 'common') {
        const data = {
            fn: 'common_fn',
            se: 'cr_sh',
            data: schooldata,
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

    async registerschool(schooldata: any, url: string = 'common/user') {
        const data = {
            fn: 'common_fn',
            se: 're_sh',
            data: schooldata,
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

    async fetchSchoolData(url: string = 'common', page: number = 1) {
        const data = {
            "fn": "common_fn",
            "se": "fe_sc_data",
            "data": {
                "limit": 100,
                page
            }
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

    async fetchSchoolclass(url: string = 'common', schoolId: any) {
        const data = {
            "fn": "common_fn",
            "se": "fe_sc_class",
            "data": schoolId

        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

    async fetchClassSubject(url: string = 'common', classId: any) {
        const data = {
            "fn": "common_fn",
            "se": "fe_sb",
            "data": classId

        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

    async fetchSubjectChapter(url: string = 'common', subjectId: any) {
        const data = {
            "fn": "common_fn",
            "se": "fe_chap",
            "data": subjectId

        };

        console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        console.log(resp);
        return resp;
    }

    async fetchAllSchool(url: string = 'common') {
        const data = {
            "fn": "common_fn",
            "se": "fe_all_sch",
            "data": ""

        };

        console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        console.log(resp);
        return resp;
    }

    async fetchAllclassOfSchool(url: string = 'common', schoolId: any) {
        const data = {
            "fn": "common_fn",
            "se": "fe_all_cls_of_school",
            "data": schoolId

        };

        console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        console.log(resp);
        return resp;
    }

    async createstudent(studentdata: any, url: string = 'common') {
        const data = {
            fn: 'common_fn',
            se: 'cr_stu',
            data: studentdata,
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

    async createboard(boardata: any, url: string = 'common') {
        const data = {
            fn: 'common_fn',
            se: 'add_bod',
            data: boardata,
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

    async createclass(classdata: any, url: string = 'common') {
        const data = {
            fn: 'common_fn',
            se: 'add_class',
            data: classdata,
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

    async fetchallBoard(url: string = 'common/user') {
        const data = {
            fn: 'common_fn',
            se: 'fe_bod',
            data: "",
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

    async fetchAllclassOfboard(url: string = 'common', boardId: any) {
        const data = {
            "fn": "common_fn",
            "se": "fe_cls_bod",
            "data": boardId

        };

        console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        console.log(resp);
        return resp;
    }

    async addSubject(subjectdata: any, url: string = 'common') {
        const data = {
            fn: 'common_fn',
            se: 'add_sub',
            data: subjectdata,
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }


    async fetchAllsubjectOfclass(url: string = 'common', classId: any) {
        const data = {
            "fn": "common_fn",
            "se": "fe_sub_cl",
            "data": classId

        };

        console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        console.log(resp);
        return resp;
    }

     async addChapter(chapterdata: any, url: string = 'common') {
        const data = {
            fn: 'common_fn',
            se: 'cr_chap',
            data: chapterdata,
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

     async createorEditSchoolOwnClass(clasdata: any, url: string = 'common') {
        const data = {
            fn: 'common_fn',
            se: 'cr_cl',
            data: clasdata,
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

     async createorEditSchoolOwnClassofSubject(subjectdata: any, url: string = 'common') {
        const data = {
            fn: 'common_fn',
            se: 'cr_sb',
            data: subjectdata,
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

     async createorEditSchoolOwnSubjectofChapter(chapterdata: any, url: string = 'common') {
        const data = {
            fn: 'common_fn',
            se: ' cr_chap_sb',
            data: chapterdata,
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

    async createteacher(teacherdata: any, url: string = 'common') {
        const data = {
            fn: 'common_fn',
            se: 'cr_teac',
            data: teacherdata,
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

     async fetchAllteacherOfSchool(url: string = 'common', schooId: any) {
        const data = {
            "fn": "common_fn",
            "se": "fe_teac",
            "data": schooId

        };

        console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        console.log(resp);
        return resp;
    }

    async fetchallclass(url: string = 'common') {
        const data = {
            fn: 'common_fn',
            se: 'fe_all_cls',
            data: ""
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

    async fetchallSubject(url: string = 'common') {
        const data = {
            fn: 'common_fn',
            se: 'fe_all_sub',
            data: ""
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

     async fetchallChapter(url: string = 'common') {
        const data = {
            fn: 'common_fn',
            se: 'fe_all_chap',
            data: ""
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

     async fetchAllstudentOfSchool(url: string = 'common', schooId: any) {
        const data = {
            "fn": "common_fn",
            "se": "fe_stu_by_school",
            "data": schooId

        };

        console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        console.log(resp);
        return resp;
    }

     async fetchallSchoolownTeacher(url: string = 'common',schoolId:any) {
        const data = {
            fn: 'common_fn',
            se: 'fe_all_teac',
            data: schoolId,
        };

        console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        console.log(resp);
        return resp;
    }

    
    async assignSubject(assignsubjectdata: any, url: string = 'common') {
        const data = {
            fn: 'common_fn',
            se: 'ass_sub',
            data: assignsubjectdata,
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

     async fetchOwnlass(url: string = 'common', teacherId: any) {
        const data = {
            "fn": "common_fn",
            "se": "fe_own_cl",
            "data": teacherId

        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

      async fetchTeacherClass(url: string = 'common', teacherId: any) {
        const data = {
            "fn": "common_fn",
            "se": "fe_clss_admin",
            "data": teacherId

        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

    async fetchClassSubjectByteacher(url: string = 'common', dataId: any) {
        const data = {
            "fn": "common_fn",
            "se": "fe_own_sub",
            "data": dataId

        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

     async fetchAllcompletedChapter(url: string = 'common', teacherId: any) {
        const data = {
            "fn": "common_fn",
            "se": "fe_com_cha",
            "data": teacherId

        };

        console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        console.log(resp);
        return resp;
    }

       async fetchallSubjectOfteacher(url: string = 'common',schooId:any) {
        const data = {
            fn: 'common_fn',
            se: 'fe_sub_of_tech',
            data: schooId
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

     async SubjectUnassinged(url: string = 'common',subjId:any) {
        const data = {
            fn: 'common_fn',
            se: 'sub_un_ass',
            data: subjId
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

    async addQuestion(qdata: any, url: string = 'common') {
        const data = {
            fn: 'common_fn',
            se: 'cr_quest',
            data: qdata,
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

      async addExam(examdata: any, url: string = 'common') {
        const data = {
            fn: 'common_fn',
            se: 'cr_ex',
            data: examdata,
        };

        console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        console.log(resp);
        return resp;
    }

     async fetchAllquestionOfchapter(url: string = 'common', chapterId: any) {
        const data = {
            "fn": "common_fn",
            "se": "fe_quest",
            "data": chapterId

        };

        console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        console.log(resp);
        return resp;
    }

    async fetchexamandQuestions(url: string = 'common', examId: any) {
        const data = {
            "fn": "common_fn",
            "se": "fe_ex_details",
            "data": examId

        };

        console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        console.log(resp);
        return resp;
    }

     async fetchAllexam(url: string = 'common') {
        const data = {
            "fn": "common_fn",
            "se": "fe_ex_stu",
            "data": ""

        };

        console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        console.log(resp);
        return resp;
    }

    async addExamSubmistion(examdata:any,url:string = 'common'){
       const data = {
            "fn": "common_fn",
            "se": "sub_ex_as",
            "data": examdata

        };

        console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        console.log(resp);
        return resp;
    }

     async fetchAllexambyteacher(url: string = 'common') {
        const data = {
            "fn": "common_fn",
            "se": "fe_ex_by_teach",
            "data": ""

        };

        console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        console.log(resp);
        return resp;
    }

     async fetchexamandQuestionsByteacher(url: string = 'common', examId: any) {
        const data = {
            "fn": "common_fn",
            "se": "fe_ex_details_by_teach",
            "data": examId

        };

        console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        console.log(resp);
        return resp;
    }

       async fetchQuestions(url: string = 'common', examId: any) {
        const data = {
            "fn": "common_fn",
            "se": "fe_quest_by_id",
            "data": examId

        };

        console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        console.log(resp);
        return resp;
    }


       async fetchAllexambyschool(url: string = 'common',schoolid:any) {
        const data = {
            "fn": "common_fn",
            "se": "fe_all_exam_sch",
            "data": schoolid

        };

        console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        console.log(resp);
        return resp;
    }
  

       async fetchAllQuestionbyschool(url: string = 'common',schoolid:any) {
        const data = {
            "fn": "common_fn",
            "se": "fe_quest_by_school",
            "data": schoolid

        };

        console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        console.log(resp);
        return resp;
    }
  

     async updateExam(examdata: any, url: string = 'common') {
        const data = {
            fn: 'common_fn',
            se: 'up_exam',
            data: examdata,
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

     async fetchAllQuestion(url: string = 'common') {
        const data = {
            "fn": "common_fn",
            "se": "fe_all_quest",
            "data": ""

        };

        console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        console.log(resp);
        return resp;
    }

}
