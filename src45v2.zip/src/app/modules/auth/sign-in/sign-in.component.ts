import { Component, inject, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import {
    FormsModule,
    NgForm,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { fuseAnimations } from '@fuse/animations';
import { FuseAlertComponent, FuseAlertType } from '@fuse/components/alert';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { AuthService } from 'app/core/auth/auth.service';
import { CommonModule } from '@angular/common';
import {MatRadioModule} from '@angular/material/radio';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserModule } from '@angular/platform-browser';
import { config } from '../../../../../config';


@Component({
    selector: 'auth-sign-in',
    templateUrl: './sign-in.component.html',
    //encapsulation: ViewEncapsulation.None,
    //animations: fuseAnimations,
    imports: [
       RouterLink,
        //FuseAlertComponent,
        MatRadioModule,CommonModule,
        FormsModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatInputModule,
        MatButtonModule,
        MatIconModule,
        MatCheckboxModule,
        MatProgressSpinnerModule
    ],
    // providers: [CookieService]
})
export class AuthSignInComponent implements OnInit {
    @ViewChild('signInNgForm') signInNgForm: NgForm;

    alert: { type: FuseAlertType; message: string } = {
        type: 'success',
        message: '',
    };
    signInForm: UntypedFormGroup;
    showAlert: boolean = false;

      private _snackBar = inject(MatSnackBar);
  cookieValue: string;

    config:any = config.apiBaseURL
     google_user:any;
    

    /**
     * Constructor
     */
    constructor(
        private _activatedRoute: ActivatedRoute,
        private _authService: AuthService,
        private _formBuilder: UntypedFormBuilder,
        private _router: Router,
    private route: ActivatedRoute,
      private Apicontroller: ApicontrollerService,private router: Router,
    ) {

    }

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    async ngOnInit() {
       // Create the form
        this.signInForm = this._formBuilder.group({
            phone: [
                '',
                [Validators.required],
            ],
            password: ['', Validators.required],
            rememberMe: [''],
        });


          const savedPhone = localStorage.getItem('rememberedEmail');
const savedPassword = localStorage.getItem('rememberedPassword');
if (savedPhone && savedPassword) {
    this.signInForm.patchValue({
        phone: savedPhone,
        password: savedPassword,
        rememberMe: true,
    });
}

            
      this.route.queryParams.subscribe((params) => {
      
      
     


     


      
    })

    }

    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

  


    async signIn(){

    //     this.showAlert = false;
     if (this.signInForm.invalid) {
        this.signInForm.markAllAsTouched(); // Show validation messages
        return;
      }

       const resp = await this.Apicontroller.loginuser(this.signInForm.value);


        // console.log("resp------------>",resp.status)


      console.log("resp-----------",resp)
      // Checking resp
      if (resp.status === 0) {



         if (this.signInForm.value.rememberMe) {
    localStorage.setItem('rememberedEmail', this.signInForm.value.phone);
    localStorage.setItem('rememberedPassword', this.signInForm.value.password);

} else {
    localStorage.removeItem('rememberedPhone');
    localStorage.removeItem('rememberedPassword');
}
      
        localStorage.setItem('token', resp.token)
        localStorage.setItem('role',resp.user_type)
        localStorage.setItem('userDeatials',JSON.stringify(resp.user_details))

         this._snackBar.open(resp.msg, '', {
        duration: 3000, // Duration in milliseconds (3 seconds)
        verticalPosition: 'top', // Position: 'top' | 'bottom'
        horizontalPosition: 'center', // Position: 'start' | 'center' | 'end' | 'left' | 'right'
      });
        // console.log("register successfully ")
        this._router.navigate(['/dashboard'])


      }else{
       // this.messageService.add({ severity: 'error', summary: 'Error', detail: resp.msg });
    //    console.log("error ")

     this._snackBar.open(resp.msg, '', {
        duration: 3000, // Duration in milliseconds (3 seconds)
        verticalPosition: 'top', // Position: 'top' | 'bottom'
        horizontalPosition: 'center', // Position: 'start' | 'center' | 'end' | 'left' | 'right'
      });
      } 

    }

    // signwithGoogle(){
    //     console.log("signWith google")
    // }

    signUp(){
        this._router.navigate(['/sign-up'])
    }

    forgotpassword(){
        this._router.navigate(['/forgot-password'])

    }

  

    
}
