import { Routes } from '@angular/router';
import { ShowChapterComponent } from './show-chapter.component';

export default [
    {
        path: '',
        component: ShowChapterComponent,
    },
] as Routes;
