import { Routes } from '@angular/router';
import { AddExamComponent } from './add-exam.component';

export default [
    {
        path: '',
        component: AddExamComponent,
    },
] as Routes;
