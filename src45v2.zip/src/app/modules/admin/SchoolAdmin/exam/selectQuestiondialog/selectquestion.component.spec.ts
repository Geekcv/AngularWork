import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectquestionBySchoolComponent } from './selectquestion.component';

describe('SelectquestionComponent', () => {
  let component: SelectquestionBySchoolComponent;
  let fixture: ComponentFixture<SelectquestionBySchoolComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SelectquestionBySchoolComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SelectquestionBySchoolComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
