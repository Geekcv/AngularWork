import { Component } from '@angular/core';
import { UntypedFormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { config } from '../../../../../../config';

@Component({
  selector: 'app-show-all-exam',
  imports: [],
  templateUrl: './show-all-exam.component.html',
  styleUrl: './show-all-exam.component.scss'
})
export class ShowAllExamComponent {

   examData: any[] = [];
    config: any;
    role: any = '';
  
  
      studentAnswers: Record<string, string | string[] | null> = {};
  
      constructor(
        private _formBuilder: UntypedFormBuilder,
        private router: Router,private _matDialog: MatDialog,
        private api: ApicontrollerService,
    ) {
        this.config = config.apiBaseURL;
        this.role = localStorage.getItem('role');
      //this.TeacherDeatials = JSON.parse(localStorage.getItem("userDeatials"));
  
   this.fetchExam()
      }
  
  async fetchExam() {
    const resp = await this.api.fetchAllexam('common');
    this.examData = resp.data;
  }

    view(rowId: string,min:any) {
    console.log("viewdata", rowId)
    this.router.navigate(['showExamofStu', rowId,min]);
  }

}
