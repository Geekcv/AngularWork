import { CommonModule } from '@angular/common';
import { Component, inject, ViewChild } from '@angular/core';
import {
    FormArray,
    FormsModule,
    NgForm,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { config } from '../../../../../../../config';

interface ChapterData {
    chapter_id: string;
    chapter_name: string;
}

interface Teacher {
    email: string;
    name: string;
    row_id: string;
    role: string;
}

@Component({
    selector: 'app-add-question',
    standalone: true,
    imports: [
        FormsModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatInputModule,
        MatButtonModule,
        MatIconModule,
        MatCheckboxModule,
        MatProgressSpinnerModule,
        MatSelectModule,
        CommonModule,
    ],
    templateUrl: './add-mcq.component.html',
    styleUrl: './add-mcq.component.scss',
})
export class AddMCQComponent {
    @ViewChild('questionNgForm') questionNgForm: NgForm;

    questionForm: UntypedFormGroup;
    role: string = '';
    config: any;
    showOptions = false;

    // ✅ Dynamic Arrays for Match and Arrange
    matchPairs: { left: string; right: string }[] = [{ left: '', right: '' }];
    arrangeList: { text: string }[] = [{ text: '' }];

    subjectList = [];
    chapterList: ChapterData[] = [];

    TeacherDeatials: Teacher = {
        email: '',
        name: '',
        row_id: '',
        role: '',
    };

    selectedFile: File | null = null;

    private _snackBar = inject(MatSnackBar);

    constructor(
        private _formBuilder: UntypedFormBuilder,
        private _router: Router,
        private api: ApicontrollerService
    ) {
        this.config = config.apiBaseURL;
        this.role = localStorage.getItem('role') || '';
        this.TeacherDeatials = JSON.parse(
            localStorage.getItem('userDeatials') || '{}'
        );

        this.fetchCompletedChapter();
    }

    ngOnInit(): void {
        this.initForm();
    }

    initForm(): void {
        this.questionForm = this._formBuilder.group({
            chapter_id: ['', Validators.required],
            type: ['', Validators.required],
            content: ['', Validators.required],
            option_a: [''],
            option_b: [''],
            option_c: [''],
            option_d: [''],
            correct_option: [''], //  For MCQ single answer
            correct_options: this._formBuilder.array([]), //  For multiple answers
            tf_answer: [''],
            fill_answer: [''],
            coding_output: [''],
            passage: [''],
            description: [''],
            cloze_text: [''],
        });
    }

    get correctOptionsArray(): FormArray {
        return this.questionForm.get('correct_options') as FormArray;
    }

    onTypeChange(): void {
        const type = this.questionForm.get('type')?.value;
        this.showOptions = [
            'mcq',
            'checkbox',
            'image_mcq',
            'video_mcq',
            'audio_mcq',
        ].includes(type);

        if (type === 'match') {
            this.matchPairs = [{ left: '', right: '' }];
        }

        if (type === 'arrange') {
            this.arrangeList = [{ text: '' }];
        }
    }

    addMatchPair(): void {
        this.matchPairs.push({ left: '', right: '' });
    }

    addArrangeStatement(): void {
        this.arrangeList.push({ text: '' });
    }

    toggleCheckbox(opt: string, checked: boolean): void {
        if (checked) {
            this.correctOptionsArray.push(this._formBuilder.control(opt));
        } else {
            const index = this.correctOptionsArray.controls.findIndex(
                (x: any) => x.value === opt
            );
            if (index >= 0) {
                this.correctOptionsArray.removeAt(index);
            }
        }
    }

    onFileSelected(event: Event): void {
        const file = (event.target as HTMLInputElement).files?.[0];
        if (file) {
            this.selectedFile = file;
            console.log('Selected file:', file.name);
        }
    }

    async submitQuestion(): Promise<void> {
        if (this.questionForm.invalid) {
            this.questionForm.markAllAsTouched();
            return;
        }

        const formData = this.questionForm.value;
        let options: any = null;
        let correct_answer: any = {};

        switch (formData.type) {
            case 'mcq':
            case 'image_mcq':
            case 'video_mcq':
            case 'audio_mcq':
                options = [
                    { label: 'A', text: formData.option_a },
                    { label: 'B', text: formData.option_b },
                    { label: 'C', text: formData.option_c },
                    { label: 'D', text: formData.option_d },
                ];
                correct_answer = { selected: formData.correct_option };
                break;

            case 'checkbox':
                options = [
                    { label: 'A', text: formData.option_a },
                    { label: 'B', text: formData.option_b },
                    { label: 'C', text: formData.option_c },
                    { label: 'D', text: formData.option_d },
                ];
                correct_answer = { selected: formData.correct_options }; // ✅ Now working
                break;

            case 'tf':
                correct_answer = { selected: formData.tf_answer === 'true' };
                break;

            case 'fill':
            case 'numeric':
            case 'short':
            case 'long':
                correct_answer = { answers: [formData.fill_answer] };
                break;

            case 'match':
                options = this.matchPairs;
                correct_answer = { pairs: this.matchPairs };
                break;

            case 'arrange':
                options = this.arrangeList;
                correct_answer = {
                    order: this.arrangeList
                        .map((item) => item.text)
                        .filter(Boolean),
                };
                break;

            case 'coding':
                correct_answer = { expected_output: formData.coding_output };
                break;

            case 'comprehension':
                options = { passage: formData.passage };
                break;

            case 'essay':
            case 'scenario':
                options = { description: formData.description };
                break;

            case 'cloze':
                options = { cloze_text: formData.cloze_text };
                break;

            default:
                correct_answer = {};
        }

        const payload = {
            chapter_id: formData.chapter_id,
            // chapter_id: formData,
            // chapter_id: formData.chapter_id,
            type: formData.type,
            content: formData.content,
            options: options,
            correct_answer: correct_answer,
            marks: 1,
            difficulty: 'medium',
            created_by: this.TeacherDeatials.row_id,
        };

        console.log(' Final Payload:', payload);

        const resp = await this.api.addQuestion(payload);

        if (resp.status === 0) {
            this._snackBar.open(resp.msg, '', {
                duration: 3000,
                verticalPosition: 'top',
                horizontalPosition: 'center',
            });

            this.questionNgForm.resetForm();
            this.initForm();
            this.showOptions = false;
            this.matchPairs = [{ left: '', right: '' }];
            this.arrangeList = [{ text: '' }];
            this.selectedFile = null;
        } else {
            this._snackBar.open(resp.msg || 'Failed to add question', '', {
                duration: 3000,
                verticalPosition: 'top',
                horizontalPosition: 'center',
            });
        }
    }

    async fetchCompletedChapter() {
        const resp = await this.api.fetchAllcompletedChapter(
            'common',
            this.TeacherDeatials.row_id
        );
        this.chapterList = resp.data as ChapterData[];
    }
}
