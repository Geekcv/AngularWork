import { NgStyle } from '@angular/common';
import { Component } from '@angular/core';
import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-view-questions',
  imports: [MatDialogModule,NgStyle],
  templateUrl: './view-questions.component.html',
  styleUrl: './view-questions.component.scss'
})
export class ViewQuestionsComponent {

   constructor(
          private dialogRef: MatDialogRef<ViewQuestionsComponent>, // Inject MatDialogRef
      ) {


      }

  exitbtn(){
        this.dialogRef.close();

  }

}
