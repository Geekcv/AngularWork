import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowAllQuestionComponent } from './show-all-question.component';

describe('ShowAllQuestionComponent', () => {
  let component: ShowAllQuestionComponent;
  let fixture: ComponentFixture<ShowAllQuestionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ShowAllQuestionComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShowAllQuestionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
