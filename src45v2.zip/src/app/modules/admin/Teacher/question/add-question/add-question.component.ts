import { CommonModule } from '@angular/common';
import { Component, inject, ViewChild } from '@angular/core';
import {
    FormArray,
    FormsModule,
    NgForm,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectChange, MatSelectModule } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { config } from '../../../../../../../config';
import { HttpClient } from '@angular/common/http';
import { MatDialog } from '@angular/material/dialog';
import { ViewQuestionsComponent } from '../view-questions/view-questions.component';

interface ChapterData {
    chapter_id: string;
    chapter_name: string;
}

interface Teacher {
    email: string;
    name: string;
    row_id: string;
    role: string;
    school_id:string;
}

interface SchoolAdmin {
    email: string;
    role: string;
    name: string;
    row_id: string;
    school_id:string
  }


  interface Class {
  row_id: string;
  name: string;
}

interface Subject {
  row_id: string;
  name: string;
}

interface Chapter {
    row_id: string;
    name: string;
}


@Component({
    selector: 'app-add-question',
    standalone: true,
    imports: [
        FormsModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatInputModule,
        MatButtonModule,
        MatIconModule,
        MatCheckboxModule,
        MatProgressSpinnerModule,
        MatSelectModule,
        CommonModule,
    ],
    templateUrl: './add-question.component.html',
    styleUrl: './add-question.component.scss',
})
export class AddQuestionComponent {
    @ViewChild('questionNgForm') questionNgForm: NgForm;

    questionForm: UntypedFormGroup;
    role: string = '';
    config: any;
    showOptions = false;

    //  Dynamic Arrays for Match and Arrange
    matchPairs: { left: string; right: string }[] = [{ left: '', right: '' }];
    arrangeList: { text: string }[] = [{ text: '' }];

    subjectList = [];
    chapterList: ChapterData[] = [];

    TeacherDeatials: Teacher = {
        email: '',
        name: '',
        row_id: '',
        role: '',
        school_id:''
    };

      SchoolAdminDeatials: SchoolAdmin = {
        email: '',
        name: '',
        role:'',
        row_id: '',
        school_id:''
      };

    selectedFile: any | null = null;

    private _snackBar = inject(MatSnackBar);

    constructor(
        private _formBuilder: UntypedFormBuilder,
        private _router: Router,
        private api: ApicontrollerService,
         private http: HttpClient,
               private _matDialog: MatDialog
    ) {
        this.config = config.apiBaseURL;
        this.role = localStorage.getItem('role') || '';

        
        this.TeacherDeatials = JSON.parse(
            localStorage.getItem('userDeatials') || '{}'
        );

        this.SchoolAdminDeatials = JSON.parse(
            localStorage.getItem('userDeatials') || '{}'
        );

        this.fetchCompletedChapter();
        this.fetchclassdata();
    }

    ngOnInit(): void {
        this.initForm();
    }

    initForm(): void {
        this.questionForm = this._formBuilder.group({
            marks:[''],
            chapter_id: ['', Validators.required],
            class_id:['',Validators.required],
            subject_id:['',Validators.required],
            type: ['', Validators.required],
            content: ['', Validators.required],
            option_a: [''],
            option_b: [''],
            option_c: [''],
            option_d: [''],
            correct_option: [''], //  For MCQ single answer
            correct_options: this._formBuilder.array([]), //  For multiple answers
            tf_answer: [''],
            fill_answer: [''],
            coding_output: [''],
            passage: [''],
            description: [''],
            cloze_text: [''],

            fill_question: ['', Validators.required],
            fill_answers: this._formBuilder.array([]),
        

             matchPairs: this._formBuilder.array([
                this._formBuilder.group({ left: [''], right: [''] }),
            ]),
            wrongPairs: this._formBuilder.array([]),

              arrangeList: this._formBuilder.array([
                this._formBuilder.group({ text: '' })
              ]),
              wrongArrangeList: this._formBuilder.array([]),
            
        });
    }

    get correctOptionsArray(): FormArray {
        return this.questionForm.get('correct_options') as FormArray;
    }

     get matchPairsArray(): FormArray {
        return this.questionForm.get('matchPairs') as FormArray;
    }
    get wrongPairsArray(): FormArray {
        return this.questionForm.get('wrongPairs') as FormArray;
    }

     get arrangeArray(): FormArray {
        return this.questionForm.get('arrangeList') as FormArray;
      }
      
      get wrongArrangeArray(): FormArray {
        return this.questionForm.get('wrongArrangeList') as FormArray;
      }

     addMatchPair(): void {
        this.matchPairsArray.push(
            this._formBuilder.group({ left: [''], right: [''] })
        );
    }

    addWrongPair(): void {
        this.wrongPairsArray.push(
            this._formBuilder.group({ left: [''], right: [''] })
        );
    }

     addArrangeStatement() {
        this.arrangeArray.push(this._formBuilder.group({ text: '' }));
      }
      
      addWrongArrangeStatement() {
        this.wrongArrangeArray.push(this._formBuilder.group({ text: '' }));
      }

    onTypeChange(): void {
        const type = this.questionForm.get('type')?.value;
        this.showOptions = [
            'mcq',
            'checkbox',
            'image_mcq',
            'video_mcq',
            'audio_mcq',
        ].includes(type);

        if (type === 'match') {
            this.matchPairsArray.clear();
            this.addMatchPair();
        }

        if (type === 'arrange') {
            this.arrangeList = [{ text: '' }];
        }
    }

   

  

    toggleCheckbox(opt: string, checked: boolean): void {
        if (checked) {
            this.correctOptionsArray.push(this._formBuilder.control(opt));
        } else {
            const index = this.correctOptionsArray.controls.findIndex(
                (x: any) => x.value === opt
            );
            if (index >= 0) {
                this.correctOptionsArray.removeAt(index);
            }
        }
    }

         filepath:any;
      mediatype:any;

    onFileSelected(event: Event): void {
         const input = event.target as HTMLInputElement;
    
        if (input.files && input.files.length > 0) {
            const file = input.files[0];
    
            //  Show preview instantly (before upload)
            const reader = new FileReader();
           
            reader.readAsDataURL(file);
    
            // Upload to server
            const formData = new FormData();
            formData.append('file', file);
    
            this.http.post(`${this.config}/common/upload`, formData).subscribe({
                next: (response: any) => {
                    if (response?.data) {
                        this.filepath = response.data.foPa || response.data.filePath;
                        this.mediatype = response.data.mimetype;
    
                        // Update the AdminDeatials so it's saved on submit
                        this.selectedFile = this.filepath;
                    }
                },
                error: (err) => console.error('Upload failed', err),
            });
        }

    }



    
    // Store option media upload results
optionMedia: Record<string, { filepath: string; mediatype: string } | null> = {
    A: null,
    B: null,
    C: null,
    D: null
  };
  
  onOptionFileSelected(option: string, event: Event): void {
    const input = event.target as HTMLInputElement;
  
    if (input.files && input.files.length > 0) {
      const file = input.files[0];
  
      // Optional preview
      const reader = new FileReader();
      reader.readAsDataURL(file);
  
      // Upload file to server
      const formData = new FormData();
      formData.append('file', file);
  
      this.http.post(`${this.config}/common/upload`, formData).subscribe({
        next: (response: any) => {
          if (response?.data) {
            const filepath = response.data.foPa || response.data.filePath;
            const mediatype = response.data.mimetype;
  
            this.optionMedia[option] = { filepath, mediatype };
            console.log(`Option ${option} uploaded:`, this.optionMedia[option]);
          }
        },
        error: (err) => console.error(`Upload failed for option ${option}`, err),
      });
    }
  }

    async submitQuestion(): Promise<void> {
        if (this.questionForm.invalid) {
            this.questionForm.markAllAsTouched();
            return;
        }

        const formData = this.questionForm.value;
        let options: any = null;
        let correct_answer: any = {};

        switch (formData.type) {
            case 'mcq':
            case 'image_mcq':
            case 'video_mcq':
            case 'audio_mcq':
                options = [
                    { label: 'A', text: formData.option_a, media: this.optionMedia.A || null },
                    { label: 'B', text: formData.option_b, media: this.optionMedia.B || null },
                    { label: 'C', text: formData.option_c, media: this.optionMedia.C || null },
                    { label: 'D', text: formData.option_d, media: this.optionMedia.D || null },
                ];
                  correct_answer = { answers: formData.correct_option };
                break;

            case 'checkbox':
                options = [
                    { label: 'A', text: formData.option_a },
                    { label: 'B', text: formData.option_b },
                    { label: 'C', text: formData.option_c },
                    { label: 'D', text: formData.option_d },
                ];
                correct_answer = { answers: formData.correct_options }; //  Now working
                break;

            case 'tf':
                correct_answer = { answers: formData.tf_answer === 'true' };
                break;

            
            case 'numeric':
            case 'short':
            case 'long':
                correct_answer = { answers: [formData.fill_answer] };
                break;

                case 'fill':
                    correct_answer = { 
                        answers: formData.fill_answers.map((a: any) => a.answer) 
                    };
                    break;
                

             case 'match':
                const correctPairs = this.matchPairsArray.value; //  Only correct
                const wrongPairs = this.wrongPairsArray.value; //  Only wrong
                options = [...wrongPairs];
                correct_answer = { answers: correctPairs };
                break;

             case 'arrange':
                    const correctOrder = this.arrangeArray.value.filter((item: any) => item.text);
                    const wrongStatements = this.wrongArrangeArray.value.filter((item: any) => item.text);                
                    options = [...wrongStatements];                
                    correct_answer = { answers: correctOrder.map((item: any) => item.text) };
                    break;          

            default:
                correct_answer = {};
        }

        console.log("match pairs ---->",this.matchPairs)
        const payload = {
            marks:formData.marks,
            chapter_id: formData.chapter_id,
            class_id:formData.class_id,
            subject_id:formData. subject_id,
            type: formData.type,
            content: formData.content || formData.fill_question,
            options: options,
            correct_answer: correct_answer,
            created_by: this.TeacherDeatials.row_id,
            media_file:this.selectedFile || null,
            school_id:this.TeacherDeatials.school_id
        };

        console.log(' Final Payload: --------------->>>>>', payload);

        const resp = await this.api.addQuestion(payload);

        if (resp.status === 0) {
            this._snackBar.open(resp.msg, '', {
                duration: 3000,
                verticalPosition: 'top',
                horizontalPosition: 'center',
            });

            this.questionNgForm.resetForm();
            this.initForm();
            this.showOptions = false;
            this.matchPairs = [{ left: '', right: '' }];
            this.arrangeList = [{ text: '' }];
            this.selectedFile = null;
        } else {
            this._snackBar.open(resp.msg || 'Failed to add question', '', {
                duration: 3000,
                verticalPosition: 'top',
                horizontalPosition: 'center',
            });
        }
    }

  
    async fetchCompletedChapter() {

        if (this.role === '3') {
            var data = {
                "teacher_id": this.TeacherDeatials.row_id
            }

            console.log("theacher")
            const resp = await this.api.fetchAllcompletedChapter(
                'common',
                data
            );
            this.chapterList = resp.data as ChapterData[];
        }

        if (this.role === '2') {
            console.log("school")
            var dataSchool = {
                "school_id": this.SchoolAdminDeatials.school_id
            }

            const resp = await this.api.fetchAllcompletedChapter(
                'common',
                dataSchool
            );
            this.chapterList = resp.data as ChapterData[];

        }

    }


   classList: Class[] = [];


     async fetchclassdata() {
    console.log(" before data")

    try {
      const resp = await this.api.fetchOwnlass('common', this.TeacherDeatials.row_id);
      //  this.classData.data = resp
      console.log("class data ------------------>", resp.data);

       this.classList  = resp.data as Class[];    


    } catch (error) {
      // console.error("Error fetching doctors:", error);
    }

  }



   subList: Subject[] = [];

  selectedclassValue:any;

 async onSelectionclassChange(event:MatSelectChange){

    console.log("data---->",event.value)

    const dataid = {
        class_id : event.value,
        teacher_id:this.TeacherDeatials.row_id
       }

       console.log("dataa--",dataid)
  
      const resp = await this.api.fetchClassSubjectByteacher('common',dataid);
      //  this.classData.data = resp
      console.log("school data ------------------>",resp);

      this.subList = resp as Subject[];

      console.log("sub lsit ",this.subList)

  }



   chapList: Subject[] = [];

  selectedsubValue:any
   async onSelectionsubChange(event:MatSelectChange){

    console.log("data---->",event.value)

    
  
        const resp = await this.api.fetchSubjectChapter(
                'common',
                 event.value
            );
            //  this.classData.data = resp
            console.log('chapter data ------------------>', resp);

            this.chapList = resp as Chapter[];

  }


  viewquestions(){
          const dialogRef = this._matDialog.open(ViewQuestionsComponent);

  }


  get fillAnswersArray() {
    return this.questionForm.get('fill_answers') as FormArray;
  }

  generateBlankAnswers() {
    const question = this.questionForm.get('fill_question')?.value || '';
    const blankCount = (question.match(/___/g) || []).length;
  
    // reset if count changes
    while (this.fillAnswersArray.length < blankCount) {
      this.fillAnswersArray.push(
        this._formBuilder.group({
          answer: ['', Validators.required],
        })
      );
    }
  
    while (this.fillAnswersArray.length > blankCount) {
      this.fillAnswersArray.removeAt(this.fillAnswersArray.length - 1);
    }
  }
}
