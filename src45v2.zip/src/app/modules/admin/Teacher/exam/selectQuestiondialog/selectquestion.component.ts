import { CommonModule, NgStyle } from '@angular/common';
import { Component, Inject } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import {
    MAT_DIALOG_DATA,
    MatDialogModule,
    MatDialogRef,
} from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectChange, MatSelectModule } from '@angular/material/select';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { MatListModule } from '@angular/material/list';

interface ChapterData {
    chapter_id: string;
    chapter_name: string;
}

interface Teacher {
    email: string;
    name: string;
    row_id: string;
    role: string;
}

  interface Class {
  row_id: string;
  name: string;
}

interface Subject {
  row_id: string;
  name: string;
}


@Component({
    selector: 'app-selectquestion',
    imports: [
        MatDialogModule,
        MatButtonModule,
        NgStyle,
        MatFormFieldModule,
        MatInputModule,
        FormsModule,
        ReactiveFormsModule,
        MatSelectModule,
        CommonModule,
        MatInputModule,
        MatCheckboxModule,
        MatListModule,
    
    ],
    templateUrl: './selectquestion.component.html',
    styleUrl: './selectquestion.component.scss',
})
export class SelectquestionComponent {
   // chapterList: ChapterData[] = [];

    TeacherDeatials: Teacher = {
        email: '',
        name: '',
        row_id: '',
        role: '',
    };
    totalMarks: any =0;

    constructor(
        @Inject(MAT_DIALOG_DATA)
        public data: { medialink: string; mediadata: any },
        private dialogRef: MatDialogRef<SelectquestionComponent>, // Inject MatDialogRef
        private api: ApicontrollerService
    ) {
        this.TeacherDeatials = JSON.parse(
            localStorage.getItem('userDeatials') || '{}'
        );
        this.fetchCompletedChapter();
        //this.fetchquestion();
        this.fetchclassdata()
    }
    exitbtn() {
        this.dialogRef.close();
    }

   

    selectedchapterValue: any;
    selectedlimitValue: any;
    questionList: any[] = [];
    selectedQuestions: any[] = [];

    sumofMarks:any= 0;
    
    async fetchquestion() {
        const data = { chapter_id: this.selectedchapterValue };
        const resp = await this.api.fetchAllquestionOfchapter('common', data);
        this.questionList = resp || [];


        // for (let index = 0; index < this.questionList.length; index++) {
            
        //     console.log("question marks------",this.questionList[index].marks)
        //     this.sumofMarks = this.sumofMarks + this.questionList[index].marks
            
        // }
        
        // Always pick random questions after fetching
        this.onLimitChange();
    }
    
    showQuestion() {
        this.fetchquestion();
    }
    
    // Optional: method to handle final selection
    submitSelectedQuestions() {
        console.log('Selected Question IDs:', this.selectedQuestions);
        console.log('chapters IDs:', this.selectedchapterValue);

        var data = {
           "questiondid":this.selectedQuestions,
           "chapter_id":this.selectedchapterValue,
           "class_id":this.selectedclassValue,
           "subject_id":this.selectedsubValue,
           "totalMarks":this.totalMarks
        }

        console.log("data----",data)

        this.dialogRef.close(data);


    }
    


       classList: Class[] = [];
    
    
         async fetchclassdata() {
        console.log(" before data")
    
        try {
          const resp = await this.api.fetchOwnlass('common', this.TeacherDeatials.row_id);
          //  this.classData.data = resp
          console.log("class data ------------------>", resp.data);
    
           this.classList  = resp.data as Class[];    
    
    
        } catch (error) {
          // console.error("Error fetching doctors:", error);
        }
    
      }
    
    
    
       subList: Subject[] = [];
    
      selectedclassValue:any;
    
     async onSelectionclassChange(event:MatSelectChange){
    
        console.log("data---->",event.value)
        this.selectedclassValue = event.value
    
        const dataid = {
            class_id : event.value,
            teacher_id:this.TeacherDeatials.row_id
           }
    
           console.log("dataa--",dataid)
      
          const resp = await this.api.fetchClassSubjectByteacher('common',dataid);
          //  this.classData.data = resp
          console.log("school data ------------------>",resp);
    
          this.subList = resp as Subject[];
    
          console.log("sub lsit ",this.subList)
    
      }
    

        chapterList: ChapterData[] = [];
      
        selectedsubValue:any
         async onSelectionsubChange(event:MatSelectChange){
      
          console.log("data---->",event.value)
          this.selectedsubValue = event.value
      
          
        
              var data = {
            teacher_id: this.TeacherDeatials.row_id,
            subject_id:event.value
        };

        console.log('theacher');
        const resp = await this.api.fetchAllcompletedChapter('common', data);
        this.chapterList = resp.data as ChapterData[];

        }

         async fetchCompletedChapter() {
       
    }
    

     // Auto-select questions based on entered limit
    // onLimitChange() {
    //     if (this.selectedlimitValue > 0 && this.questionList.length > 0) {
    //         //  Randomly shuffle the question list
    //         const shuffled = [...this.questionList].sort(() => Math.random() - 0.5);
    
    //         // Pick the first N from the shuffled list
    //         this.selectedQuestions = shuffled
    //             .slice(0, this.selectedlimitValue)
    //             .map(q => q.row_id);
    
    //         console.log('Randomly selected:', this.selectedQuestions);

            
    //     } else {
    //         this.selectedQuestions = [];
    //     }
    // }


    onLimitChange() {
        if (this.selectedlimitValue > 0 && this.questionList.length > 0) {
     
        // Randomly shuffle the question list
        const shuffled = [...this.questionList].sort(() => Math.random() - 0.5);
        // Pick the first N from the shuffled list
        const selected = shuffled.slice(0, this.selectedlimitValue);
        // Store only the row_ids
        this.selectedQuestions = selected.map(q => q.row_id);
        // :white_check_mark: Calculate the sum of marks
        this.totalMarks = selected.reduce((sum, q) => sum + (q.marks || 0), 0);
        console.log('Randomly selected questions:', this.selectedQuestions);
        console.log('Total marks of selected questions:', this.totalMarks);
    } else {
        this.selectedQuestions = [];
        console.log('Total marks: 0');
    }
}


    
    // Select all questions
selectAllQuestions() {
    this.selectedQuestions = this.questionList.map(q => q.row_id);
    console.log('All selected:', this.selectedQuestions);
}

// Clear all selections
clearAllQuestions() {
    this.selectedQuestions = [];
    console.log('Selection cleared');
}

}
