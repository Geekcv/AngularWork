import { Routes } from '@angular/router';
import { ShowAllExamComponent } from './show-all-exam.component';

export default [
    {
        path: '',
        component: ShowAllExamComponent,
    },
] as Routes;
