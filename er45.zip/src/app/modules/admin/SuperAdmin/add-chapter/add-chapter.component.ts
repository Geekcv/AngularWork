import { HttpClient } from '@angular/common/http';
import { Component, inject, ViewChild } from '@angular/core';
import {
    FormsModule,
    NgForm,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { config } from '../../../../../../config';
import { CommonModule, NgStyle } from '@angular/common';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { FuseDrawerComponent } from '@fuse/components/drawer';

interface classData{
  row_id:string;
  name:string
}

interface subjectData{
  row_id:string;
  name:string
}

interface board {
 row_id:string;
  name:string;
}

  interface Column {
  name: string; // The column name/key (must match MatTable's columnDef)
  label: string; // The displayed label for checkbox and header
  visible: boolean; // Whether this column is currently shown
}

interface ChapterData {
 row_id:string;
  name:string;
  sub_name:string;
  class_name:string;
  board_name:string;
  sub_row_id:string;
  class_row_id:string;
  board_row_id:string
}

@Component({
  selector: 'app-add-chapter',
  imports: [
      FormsModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatInputModule,
        MatButtonModule,
        MatIconModule,
        MatCheckboxModule,
        MatProgressSpinnerModule,
        MatSelectModule,
         NgStyle,FuseDrawerComponent,
                              MatTableModule,
                                            MatPaginatorModule

                                         
                                             , MatTooltipModule, MatSortModule,
                                          
                                                CommonModule,
  ],
  templateUrl: './add-chapter.component.html',
  styleUrl: './add-chapter.component.scss'
})
export class AddChapterComponent {

 @ViewChild('chapterNgForm') chapterNgForm: NgForm;

  chapterForm: UntypedFormGroup;
  showAlert = false;
  role: any = '';
  config: any;

  subjectList = []
  classList = []

   isSearchActive = false;
          chapterData = new MatTableDataSource<ChapterData>([]); // Use MatTableDataSource for pagination
           @ViewChild(MatPaginator) paginator!: MatPaginator;
             @ViewChild(MatSort) sort!: MatSort;

  constructor(
      private _formBuilder: UntypedFormBuilder,
      private _router: Router,
      private api: ApicontrollerService,
  ) {
      this.config = config.apiBaseURL;
      this.role = localStorage.getItem('role');
      this.fetchallboard()
      this.fetchallchapter()
  }

  private _snackBar = inject(MatSnackBar);

  ngOnInit(): void {
      this.chapterForm = this._formBuilder.group({
          chaptername: ['', Validators.required],
        class_id :['',Validators.required],
          board_id: ['', Validators.required], 
          subject_id:['',Validators.required]
          
      });
  }

 
    get displayedColumns(): string[] {
    return this.columns.filter((c) => c.visible).map((c) => c.name);
  }


  boardList = []

  async addChapter(addchapter:any): Promise<void> {
      if (this.chapterForm.invalid) {
          this.chapterForm.markAllAsTouched();
          return;
      }

      const payload = {
          ...this.chapterForm.value,
      };

      const resp = await this.api.addChapter(payload);

      if (resp.status === 0) {
          this._snackBar.open(resp.msg, '', {
              duration: 3000,
              verticalPosition: 'top',
              horizontalPosition: 'center',
          });

          this.chapterNgForm.resetForm();
          addchapter.close()
      this.fetchallchapter()

      } else {
          this._snackBar.open(resp.msg || 'Failed to add chapter', '', {
              duration: 3000,
              verticalPosition: 'top',
              horizontalPosition: 'center',
          });
      }
  }

  selectedValue:any;

    async onSelectionChange(elements: any){
       console.log("data1 elements.value======",elements.value)
      console.log("data2 elements======",elements.board_name)
        // this.selectedValue = (event.target as HTMLSelectElement).value;
        console.log('Selected value:---------', this.selectedValue);
    this.selectedValue = elements.value || elements.board_name

        const resp = await this.api.fetchAllclassOfboard('common', this.selectedValue);
        console.log("resp",resp)
        this.classList = resp as classData[]
       

      }

      async fetchallboard(){
    // 
      const resp = await this.api.fetchallBoard();
      this.boardList = resp as board[]

  }

  // 

    selectedValueclass:any;

    async onSelectionChangeclass(elements :any){
            console.log("data1 elements.value======",elements)
      console.log("data2 elements======",elements.class_name)
        // this.selectedValue = (event.target as HTMLSelectElement).value;
        console.log('Selected value:---------', this.selectedValueclass);

    this.selectedValueclass = elements.value || elements.class_name


        const resp = await this.api.fetchAllsubjectOfclass('common', this.selectedValueclass);
        console.log("resp--------->",resp)
        this.subjectList = resp as subjectData[]
       

      }

                columns: Column[] = [
    { name: 'sr_no', label: 'Sr.No', visible: true },
    { name: 'name', label: 'Chapter Name', visible: true }, 
    { name: 'board_name', label: 'Board Name', visible: true },
    { name: 'class_name', label: 'Class Name', visible: true },
    { name: 'sub_name', label: 'Subject Name', visible: true },
    { name: 'actions', label: 'Actions', visible: true },

  ];

   editRowId: number | null = null;

 async editRow(rowId: number) {
    this.editRowId = rowId;

    const row = this.chapterData.data.find((r) => r.row_id === String(rowId));
     

        const resp = await this.api.fetchAllclassOfboard('common', row.board_row_id);
        // console.log("resp ------------>",resp)
        this.classList = resp as classData[]
        console.log("my classlsit----",this.classList)
   

  
    if (row) {
      const match = this.boardList.find((b) => b.name === row.board_name);
      if (match) {
        row.board_name = match.row_id;
      }
    }

     const match = this.classList.find((b) => b.name === row.class_name);
      // console.log("match class ------",match)
      if (match) {
        row.class_name = match.row_id;
        
      }

      console.log("row--",row)



        const respSubjectdata = await this.api.fetchAllsubjectOfclass('common', row.class_row_id);
        console.log("etchAllsubjectOfclass resp--------->",respSubjectdata)
        this.subjectList = respSubjectdata as subjectData[]

        console.log("subject ----",this.subjectList)

      const matchsubject = this.subjectList.find((b) => b.row_id === row.sub_row_id);
      console.log("match subject ------",matchsubject)
      if (matchsubject) {
        row.sub_name = matchsubject.row_id;        
      }

  }

  isRowEditing(rowId: any) {
    return this.editRowId === rowId;
  }

     async saveRow(row: any) {
    console.log("row-----", row)
    this.editRowId = null;

    const isValid =
    row.name?.trim();

  if (!isValid) {
      this.fetchallchapter()

    return;
  }

       try {
      const resp = await this.api.addChapter(row);
      // console.log('doctors update data:', resp);
      if (resp.status === 0) {
        this._snackBar.open(resp.msg, '', {
          duration: 3000,
          verticalPosition: 'top',
          horizontalPosition: 'center',
        });
           this.fetchallchapter()


      } else {
        this._snackBar.open(resp.msg, '', {
          duration: 4000,
          verticalPosition: 'top',
          horizontalPosition: 'center',
        });
      }
    } catch (error) {
      console.error('Error updating chapter:', error);
    }

   
  }

  cancelEdit() {
      this.fetchallchapter()
    this.editRowId = null;
  }

     async fetchallchapter() {
    console.log(" before data")

    try {
     const resp = await this.api.fetchallChapter('common');

      const data = resp as ChapterData[];

     // console.log("class data=========================",data)

      // Add sr_no for each row (based on pagination if needed)
      this.chapterData.data = data.map((item, index) => ({
        ...item,
        sr_no: index + 1 + this.chapterData.paginator.pageIndex * this.chapterData.paginator.pageSize
      }));

      console.log("class.data 5555------------------>", this.chapterData.data);


      // Enable sorting for custom fields like user_row_id (extract numeric part)
      this.chapterData.sortingDataAccessor = (item, property) => {
        if (property === 'row_id') {
          return Number(item.row_id?.split('_')[0]); // numeric part
        }
        return item[property];
      };



    } catch (error) {
      // console.error("Error fetching doctors:", error);
    }

  }

   ngAfterViewInit() {
    // console.log(" ngAfterViewInit")
    this.chapterData.paginator = this.paginator; // Set paginator after view init
    this.chapterData.sort = this.sort

  }

   filterByQuery(query: string): void {
    const trimmedQuery = query.trim().toLowerCase();

    if (trimmedQuery) {
      this.isSearchActive = true;
      this.chapterData.filter = trimmedQuery;

      if (this.chapterData.paginator) {
        this.chapterData.paginator.firstPage(); // Reset to first page after search
      }
    } else {
      this.isSearchActive = false;
      this.chapterData.filter = ''; // Clear filter

      // Reset the paginator and restore original data
      setTimeout(() => {
        this.chapterData.paginator = this.paginator;
      });
    }
  }
}
