import { Component } from '@angular/core';

@Component({
  selector: 'app-show-subject',
  imports: [],
  templateUrl: './show-subject.component.html',
  styleUrl: './show-subject.component.scss'
})
export class ShowSubjectComponent {

}
