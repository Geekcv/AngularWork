import { Routes } from '@angular/router';
import { AssignSubjectComponent } from './assign-subject.component';

export default [
    {
        path: '',
        component: AssignSubjectComponent,
    },
] as Routes;
