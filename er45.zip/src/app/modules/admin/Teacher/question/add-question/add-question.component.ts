import { CommonModule } from '@angular/common';
import { Component, inject, ViewChild } from '@angular/core';
import {
    FormArray,
    FormGroup,
    FormsModule,
    NgForm,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectChange, MatSelectModule } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { config } from '../../../../../../../config';
import { HttpClient } from '@angular/common/http';
import { MatDialog } from '@angular/material/dialog';
import { ViewQuestionsComponent } from '../view-questions/view-questions.component';

import { CdkDragDrop, DragDropModule, moveItemInArray } from '@angular/cdk/drag-drop';


interface ChapterData {
    chapter_id: string;
    chapter_name: string;
}

interface Teacher {
    email: string;
    name: string;
    row_id: string;
    role: string;
    school_id:string;
}

interface SchoolAdmin {
    email: string;
    role: string;
    name: string;
    row_id: string;
    school_id:string
  }


  interface Class {
  row_id: string;
  name: string;
}

interface Subject {
  row_id: string;
  name: string;
}

interface Chapter {
    row_id: string;
    name: string;
}


@Component({
    selector: 'app-add-question',
    standalone: true,
    imports: [
        FormsModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatInputModule,
        MatButtonModule,
        MatIconModule,
        MatCheckboxModule,
        MatProgressSpinnerModule,
        MatSelectModule,
        CommonModule,DragDropModule
    ],
    templateUrl: './add-question.component.html',
    styleUrl: './add-question.component.scss',
})
export class AddQuestionComponent {
    @ViewChild('questionNgForm') questionNgForm: NgForm;

    questionForm: UntypedFormGroup;
    role: string = '';
    config: any;
    showOptions = false;

    //  Dynamic Arrays for Match and Arrange
   // matchPairs: { left: string; right: string }[] = [{ left: '', right: '' }];
    arrangeList: { text: string }[] = [{ text: '' }];

    subjectList = [];
    chapterList: ChapterData[] = [];

    TeacherDeatials: Teacher = {
        email: '',
        name: '',
        row_id: '',
        role: '',
        school_id:''
    };

      SchoolAdminDeatials: SchoolAdmin = {
        email: '',
        name: '',
        role:'',
        row_id: '',
        school_id:''
      };

    selectedFile: any | null = null;

    private _snackBar = inject(MatSnackBar);

    constructor(
        private _formBuilder: UntypedFormBuilder,
        private _router: Router,
        private api: ApicontrollerService,
         private http: HttpClient,
               private _matDialog: MatDialog
    ) {
        this.config = config.apiBaseURL;
        this.role = localStorage.getItem('role') || '';

        
        this.TeacherDeatials = JSON.parse(
            localStorage.getItem('userDeatials') || '{}'
        );

        this.SchoolAdminDeatials = JSON.parse(
            localStorage.getItem('userDeatials') || '{}'
        );

        this.fetchCompletedChapter();
        this.fetchclassdata();
    }

    ngOnInit(): void {
        this.initForm();
    }

    initForm(): void {
        this.questionForm = this._formBuilder.group({
            marks:[''],
            chapter_id: ['', Validators.required],
            class_id:['',Validators.required],
            subject_id:['',Validators.required],
            type: ['', Validators.required],
            content: ['', Validators.required],
            option_a: [''],
            option_b: [''],
            option_c: [''],
            option_d: [''],
            correct_option: [''], //  For MCQ single answer
            correct_options: this._formBuilder.array([]), //  For multiple answers
            tf_answer: [''],
            fill_answer: [''],
            coding_output: [''],
            passage: [''],
            description: [''],
            cloze_text: [''],

              matchPairs: this._formBuilder.array([
                this._formBuilder.group({ left: [''], right: [''] }),
            ]),
            
        });
    }

   
    
    onTypeChange(): void {
        const type = this.questionForm.get('type')?.value;
        this.showOptions = [
            'mcq',
            'checkbox',
            'image_mcq',
            'video_mcq',
            'audio_mcq',
        ].includes(type);

        
    }

   

  

    get matchPairs(): FormArray {
      return this.questionForm.get('matchPairs') as FormArray;
    }
  
    addPair() {
      this.matchPairs.push(
        this._formBuilder.group({
          left: ['', Validators.required],
          right: ['', Validators.required],
        })
      );
    }
  
    removePair() {
      if (this.matchPairs.length > 1) {
        this.matchPairs.removeAt(this.matchPairs.length - 1);
      }
    }
  
    drop(event: CdkDragDrop<FormGroup[]>) {
      moveItemInArray(this.matchPairs.controls, event.previousIndex, event.currentIndex);
      this.matchPairs.updateValueAndValidity();
    }
    shuffleFormArray(formArray: FormArray) {
    const values = formArray.value;
    for (let i = values.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [values[i], values[j]] = [values[j], values[i]];
    }
    // Clear and re-insert shuffled values
    while (formArray.length) {
      formArray.removeAt(0);
    }
    values.forEach((val: any) => {
      formArray.push(this._formBuilder.group({ left: [val.left], right: [val.right] }));
    });
  }

    async submitQuestion(): Promise<void> {
        if (this.questionForm.invalid) {
            this.questionForm.markAllAsTouched();
            return;
        }

        const formData = this.questionForm.value;
        let options: any = null;
        let correct_answer: any = {};

        switch (formData.type) {
          
              case 'match':
                    const correctPairs = this.matchPairs.value; // Correct pairs
                    options = correctPairs;

                    // Store correct answer for evaluation
                    correct_answer = { answers: correctPairs };
                    break;
                  

             
            default:
                correct_answer = {};
        }

        // console.log("match pairs ---->",this.matchPairs)
        const payload = {
            marks:formData.marks,
            chapter_id: formData.chapter_id,
            class_id:formData.class_id,
            subject_id:formData. subject_id,
            type: formData.type,
            content: formData.content,
            options: options,
            correct_answer: correct_answer,
            created_by: this.TeacherDeatials.row_id,
            media_file:this.selectedFile || null,
            school_id:this.TeacherDeatials.school_id
        };

        console.log(' Final Payload: --------------->>>>>', payload);

        const resp = await this.api.addQuestion(payload);

        if (resp.status === 0) {
            this._snackBar.open(resp.msg, '', {
                duration: 3000,
                verticalPosition: 'top',
                horizontalPosition: 'center',
            });

            this.questionNgForm.resetForm();
            this.initForm();
            this.showOptions = false;
           // this.matchPairs = [{ left: '', right: '' }];
            this.arrangeList = [{ text: '' }];
            this.selectedFile = null;
        } else {
            this._snackBar.open(resp.msg || 'Failed to add question', '', {
                duration: 3000,
                verticalPosition: 'top',
                horizontalPosition: 'center',
            });
        }
    }

  
    async fetchCompletedChapter() {

        if (this.role === '3') {
            var data = {
                "teacher_id": this.TeacherDeatials.row_id
            }

            console.log("theacher")
            const resp = await this.api.fetchAllcompletedChapter(
                'common',
                data
            );
            this.chapterList = resp.data as ChapterData[];
        }

        if (this.role === '2') {
            console.log("school")
            var dataSchool = {
                "school_id": this.SchoolAdminDeatials.school_id
            }

            const resp = await this.api.fetchAllcompletedChapter(
                'common',
                dataSchool
            );
            this.chapterList = resp.data as ChapterData[];

        }

    }


   classList: Class[] = [];


     async fetchclassdata() {
    console.log(" before data")

    try {
      const resp = await this.api.fetchOwnlass('common', this.TeacherDeatials.row_id);
      //  this.classData.data = resp
      console.log("class data ------------------>", resp.data);

       this.classList  = resp.data as Class[];    


    } catch (error) {
      // console.error("Error fetching doctors:", error);
    }

  }



   subList: Subject[] = [];

  selectedclassValue:any;

 async onSelectionclassChange(event:MatSelectChange){

    console.log("data---->",event.value)

    const dataid = {
        class_id : event.value,
        teacher_id:this.TeacherDeatials.row_id
       }

       console.log("dataa--",dataid)
  
      const resp = await this.api.fetchClassSubjectByteacher('common',dataid);
      //  this.classData.data = resp
      console.log("school data ------------------>",resp);

      this.subList = resp as Subject[];

      console.log("sub lsit ",this.subList)

  }



   chapList: Subject[] = [];

  selectedsubValue:any
   async onSelectionsubChange(event:MatSelectChange){

    console.log("data---->",event.value)

    
  
        const resp = await this.api.fetchSubjectChapter(
                'common',
                 event.value
            );
            //  this.classData.data = resp
            console.log('chapter data ------------------>', resp);

            this.chapList = resp as Chapter[];

  }


  viewquestions(){
          const dialogRef = this._matDialog.open(ViewQuestionsComponent);

  }
}
