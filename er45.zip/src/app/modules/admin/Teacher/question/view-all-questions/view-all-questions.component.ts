import { CommonModule, NgStyle } from '@angular/common';
import { Component, ViewChild } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSelectModule } from '@angular/material/select';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatTooltipModule } from '@angular/material/tooltip';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { config } from '../../../../../../../config';
import { Router } from '@angular/router';

interface Column {
  name: string; // The column name/key (must match MatTable's columnDef)
  label: string; // The displayed label for checkbox and header
  visible: boolean; // Whether this column is currently shown
}

interface questions{
  row_id:string;
  class_name:string;
  subject_name:string;
}

interface SchoolAdmin {
  email: string;
  role: string;
  name: string;
  row_id: string;
  school_id: string;
}


@Component({
  selector: 'app-view-all-questions',
  imports: [
     MatTableModule,
        MatPaginatorModule,
        MatButtonModule,
        MatIconModule,
        MatInputModule,
        NgStyle, MatTooltipModule, MatSortModule,
        ReactiveFormsModule, MatFormFieldModule,
        MatSelectModule, CommonModule,
        FormsModule, 
  ],
  templateUrl: './view-all-questions.component.html',
  styleUrl: './view-all-questions.component.scss'
})
export class ViewAllQuestionsComponent {

       questionData = new MatTableDataSource<questions>([]); // Use MatTableDataSource for pagination
  
        @ViewChild(MatPaginator) paginator!: MatPaginator;
            @ViewChild(MatSort) sort!: MatSort;

    config: any;
    role: any = '';
  

     SchoolAdminDeatials: SchoolAdmin = {
    email: '',
    name: '',
    role: '',
    row_id: '',
    school_id: ''
  };

  constructor(
     private api: ApicontrollerService,
      private router: Router
  ){

     this.config = config.apiBaseURL;
     this.role = localStorage.getItem('role');
      this.SchoolAdminDeatials = JSON.parse(localStorage.getItem("userDeatials"));
    this.fetchquestionByTeacher()
  }


    async fetchquestionByTeacher(){


         if(this.role == 3){
           const resp = await this.api.fetchAllQuestion();
          console.log("question data ---->>",resp)  

            const data = resp.data as questions[];

    // Add sr_no for each row (based on pagination if needed)
      this.questionData.data = data.map((item, index) => ({
        ...item,
        sr_no: index + 1 + this.questionData.paginator.pageIndex * this.questionData.paginator.pageSize
      }));
         }
    
   if(this.role == 2){
           const resp = await this.api.fetchAllQuestionbyschool('common',this.SchoolAdminDeatials.school_id);
          console.log("question data ---->>",resp)  

            const data = resp.data as questions[];

    // Add sr_no for each row (based on pagination if needed)
      this.questionData.data = data.map((item, index) => ({
        ...item,
        sr_no: index + 1 + this.questionData.paginator.pageIndex * this.questionData.paginator.pageSize
      }));
         }

          
    
      }


        isSearchActive = false;

      columns: Column[] = [
    { name: 'sr_no', label: 'Sr.No', visible: true },
    { name: 'class_name', label: 'Class', visible: true },
    { name: 'subject_name', label: 'Subject', visible: true }, 
    { name: 'chapter_name', label: 'Chapter', visible: true }, 
    { name: 'actions', label: 'Actions', visible: true },

  ];

    get displayedColumns(): string[] {
    return this.columns.filter((c) => c.visible).map((c) => c.name);
  }


  editRowId: number | null = null;

  editRow(rowId: number) {
    this.editRowId = rowId;
  }

  isRowEditing(rowId: any) {
    return this.editRowId === rowId;
  }

      viewexamDetails(rowId: string) {
    // console.log("viewdata", doctor_rowId)
     this.router.navigate(['showAllquestion', rowId]);
  }

   ngAfterViewInit() {
    // console.log(" ngAfterViewInit")
    this.questionData.paginator = this.paginator; // Set paginator after view init
    this.questionData.sort = this.sort

  }
}
