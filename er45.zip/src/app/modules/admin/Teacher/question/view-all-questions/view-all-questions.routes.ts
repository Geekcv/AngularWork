import { Routes } from '@angular/router';
import { ViewAllQuestionsComponent } from './view-all-questions.component';

export default [
    {
        path: '',
        component: ViewAllQuestionsComponent,
    },
] as Routes;
