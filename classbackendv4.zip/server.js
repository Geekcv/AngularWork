const express = require("express");
const app = express();
// const fileUpload = require('express-fileupload');
require("dotenv").config();
const path = require("path");
const bodyParser = require("body-parser");

const cors = require("cors");
const common = require("./public/lib/common.js");
const useragent = require("express-useragent");
const PORT = process.env.SERVER_PORT || 3000;

// require("./public/lib/google_auth/passport.js");

app.use(cors());

app.use(useragent.express());
// app.use(express.urlencoded({ extended: true })); // For parsing URL-encoded form data
app.set("trust proxy", true); // IMPORTANT if using behind proxy

const session = require("express-session");
const passport = require("passport");

app.use(
  session({
    secret: "aiims_research_jwt_secret729@",
    resave: false,
    saveUninitialized: true,
  })
);

app.use(passport.initialize());
app.use(passport.session());


// Required session handlers
passport.serializeUser((user, done) => {
  done(null, user); // Store user object (or just user.id if preferred)
});

passport.deserializeUser((user, done) => {
  done(null, user); // Retrieve full user (or lookup by ID)
});

app.use(bodyParser.json({ limit: "100mb", type: "application/json" }));
app.use(
  bodyParser.urlencoded({
    limit: "5000mb",
    extended: true,
    parameterLimit: 50000,
  })
);

app.use(function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept"
  );
  next();
});
app.use("/common", common);
app.use("/", express.static("public"));
app.use("/node_modules", express.static(path.join(__dirname, "node_modules")));
app.use(
  "/bower_components",
  express.static(path.join(__dirname, "bower_components"))
);

//app.use(express.static(path.join(__dirname, "public/frontend")));

// app.get('/*', (req,res)=>{
//     res.sendFile(path.join(__dirname, 'public/frontend/index.html'))
// })

app.listen(PORT, function () {
  console.log("app is listening on port " + PORT);
});
