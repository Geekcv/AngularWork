// /* eslint-disable */
// import { FuseNavigationItem } from '@fuse/components/navigation';

// export const defaultNavigation: FuseNavigationItem[] = [
//     // {
//     //     id   : 'example',
//     //     title: 'Example15',
//     //     type : 'basic',
//     //     icon : 'heroicons_outline:chart-pie',
//     //     link : '/example'
//     // },
//     // {
//     //     id   : 'test',
//     //     title: 'test',
//     //     type : 'basic',
//     //     icon : 'feather:alert-octagon',
//     //     link : '/test'
//     // },
//     {
//         id   : 'dashboard',
//         title: 'Dashboard',
//         type : 'basic',
//         icon : 'mat_solid:dashboard',
//         link : '/dashboard',
//     },
//     {
//         id   : 'Viewresearchers',
//         title: 'View Researchers',
//         type : 'basic',
//         icon : 'heroicons_outline:viewfinder-circle',
//         link : '/Viewresearchers'
//     },
//     {
//         id   : 'Addresearchers',
//         title: 'Add Researchers',
//         type : 'basic',
//         icon : 'heroicons_outline:adjustments-vertical',
//         link : '/Addresearchers'
//     },
//     {
//         id   : 'Viewpatients',
//         title: 'View Patients',
//         type : 'basic',
//         icon : 'feather:command',
//         link : '/Viewpatients'
//     },
//     {
//         id   : 'Addpatients',
//         title: 'Add Patients',
//         type : 'basic',
//         icon : 'heroicons_solid:arrow-up-on-square-stack',
//         link : '/Addpatients'
//     },
//     {
//         id   : 'Account',
//         title: 'Account',
//         type : 'basic',
//         icon : 'feather:settings',
//         link : '/account'
//     },
// ];
// export const compactNavigation: FuseNavigationItem[] = [
//     {
//         id   : 'example',
//         title: 'Example',
//         type : 'basic',
//         icon : 'heroicons_outline:chart-pie',
//         link : '/example'
//     }
// ];
// export const futuristicNavigation: FuseNavigationItem[] = [
//     {
//         id   : 'example',
//         title: 'Example',
//         type : 'basic',
//         icon : 'heroicons_outline:chart-pie',
//         link : '/example'
//     }
// ];
// export const horizontalNavigation: FuseNavigationItem[] = [
//     {
//         id   : 'example',
//         title: 'Example',
//         type : 'basic',
//         icon : 'heroicons_outline:chart-pie',
//         link : '/example1'
//     }
// ];

/* eslint-disable */
import { FuseNavigationItem } from '@fuse/components/navigation';

export const defaultNavigation = (role: any): FuseNavigationItem[] => {
    const navigation: FuseNavigationItem[] = [];

    if (role === 1) {
        // Super Admin - Full Access
        navigation.push(
            {
                id: 'dashboard',
                title: 'Dashboard',
                type: 'basic',
                icon: 'mat_solid:dashboard',
                link: '/dashboard',
            },

            {
                id: 'addschool',
                title: 'Add School',
                type: 'basic',
                icon: 'heroicons_mini:user-plus',
                link: '/addschool',
            },

            {
                id: 'settings',
                title: 'Settings',
                type: 'basic',
                icon: 'feather:settings',
                link: 'settings',
            }
        );
    } else if (role === 2) {
        // Admin - Limited Access
        navigation.push(
            {
                id: 'dashboard',
                title: 'Dashboard',
                type: 'basic',
                icon: 'mat_solid:dashboard',
                link: '/dashboard',
            },

            {
                id: 'settings',
                title: 'Settings',
                type: 'basic',
                icon: 'feather:settings',
                link: 'settings',
            }
        );
    } else if (role === 3) {
        navigation.push(
            {
                id: 'dashboard',
                title: 'Dashboard',
                type: 'basic',
                icon: 'mat_solid:dashboard',
                link: '/dashboard',
            },

            {
                id: 'addAdmin',
                title: 'Reports',
                type: 'basic',
                icon: 'heroicons_mini:user-plus',
                link: '/addAdmin',
            },
            {
                id: 'settings',
                title: 'Settings',
                type: 'basic',
                icon: 'feather:settings',
                link: 'settings',
            }
        );
    }

    return navigation;
};
