import { Component, inject, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import {
    FormsModule,
    NgForm,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { fuseAnimations } from '@fuse/animations';
import { FuseAlertComponent, FuseAlertType } from '@fuse/components/alert';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { AuthService } from 'app/core/auth/auth.service';
import { CommonModule } from '@angular/common';
import {MatRadioModule} from '@angular/material/radio';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserModule } from '@angular/platform-browser';
import { config } from '../../../../../config';


@Component({
    selector: 'auth-sign-in',
    templateUrl: './sign-in.component.html',
    //encapsulation: ViewEncapsulation.None,
    //animations: fuseAnimations,
    imports: [
       RouterLink,
        //FuseAlertComponent,
        MatRadioModule,CommonModule,
        FormsModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatInputModule,
        MatButtonModule,
        MatIconModule,
        MatCheckboxModule,
        MatProgressSpinnerModule
    ],
    // providers: [CookieService]
})
export class AuthSignInComponent implements OnInit {
    @ViewChild('signInNgForm') signInNgForm: NgForm;

    alert: { type: FuseAlertType; message: string } = {
        type: 'success',
        message: '',
    };
    signInForm: UntypedFormGroup;
    showAlert: boolean = false;

      private _snackBar = inject(MatSnackBar);
  cookieValue: string;

    config:any = config.apiBaseURL
     google_user:any;
    

    /**
     * Constructor
     */
    constructor(
        private _activatedRoute: ActivatedRoute,
        private _authService: AuthService,
        private _formBuilder: UntypedFormBuilder,
        private _router: Router,
    private route: ActivatedRoute,
      private Apicontroller: ApicontrollerService,private router: Router,
    ) {

    }

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    async ngOnInit() {
       // Create the form
        this.signInForm = this._formBuilder.group({
            phone: [
                '',
                [Validators.required],
            ],
            password: ['', Validators.required],
            rememberMe: [''],
        });

            
      this.route.queryParams.subscribe((params) => {
      const token = params['token'];

      // console.log("token----",token)

      const email = params['em']
      // console.log("ema---",email)
      if(email){
      this.loginwithemail(email)
      }

      
      const role = params['role'];
      const userDeatials = params['userDeatials'];

      const pending = params['pending'];

      if (params['google_user'] !=undefined) {
        
        this.google_user = params['google_user']
      }

      // console.log("Pending",pending==='1',pending==='2',pending)

      if (pending==='1') {
         this._snackBar.open('Approval pending by admin', '', {
        duration: 3000, 
        verticalPosition: 'top', 
        horizontalPosition: 'center', 
      });
      }

      if (pending==='2') {
         this._snackBar.open('Approval pending by researcher', '', {
        duration: 3000, 
        verticalPosition: 'top', 
        horizontalPosition: 'center', 
      });
      }

      if (pending==='3') {
         this._snackBar.open('Sign up to continue', '', {
        duration: 3000, 
        verticalPosition: 'top', 
        horizontalPosition: 'center', 
      });
      }



      
      if (token) {
        localStorage.setItem('token', token);
        localStorage.setItem('role', role);
        localStorage.setItem('userDeatials', userDeatials);
        localStorage.setItem('google_user',this.google_user)


        console.log('Token stored from Google login.');
        this.router.navigate(['/dashboard']); // Navigate to actual dashboard
      }})

    }

    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

  
    async loginwithemail(email:any){
      //  const resp = await this.Apicontroller.loginwithemail(email);
  //     //  console.log("resp",resp)
  //  if (resp.status === 0) {
  //    localStorage.setItem('token', resp.token)
  //       localStorage.setItem('role',resp.user_type)
  //       localStorage.setItem('userDeatials',JSON.stringify(resp.user_details))

  //    this._router.navigate(['/dashboard'])
  //  }

    }

    async signIn(){

    //     this.showAlert = false;
     if (this.signInForm.invalid) {
        this.signInForm.markAllAsTouched(); // Show validation messages
        return;
      }

       const resp = await this.Apicontroller.loginuser(this.signInForm.value);


        // console.log("resp------------>",resp.status)


      // console.log("resp",resp)
      // Checking resp
      if (resp.status === 0) {
      
        localStorage.setItem('token', resp.token)
        localStorage.setItem('role',resp.user_type)
        localStorage.setItem('userDeatials',JSON.stringify(resp.user_details))

         this._snackBar.open(resp.msg, '', {
        duration: 3000, // Duration in milliseconds (3 seconds)
        verticalPosition: 'top', // Position: 'top' | 'bottom'
        horizontalPosition: 'center', // Position: 'start' | 'center' | 'end' | 'left' | 'right'
      });
        // console.log("register successfully ")
        this._router.navigate(['/dashboard'])


      }else{
       // this.messageService.add({ severity: 'error', summary: 'Error', detail: resp.msg });
    //    console.log("error ")

     this._snackBar.open(resp.msg, '', {
        duration: 3000, // Duration in milliseconds (3 seconds)
        verticalPosition: 'top', // Position: 'top' | 'bottom'
        horizontalPosition: 'center', // Position: 'start' | 'center' | 'end' | 'left' | 'right'
      });
      } 

    }

    // signwithGoogle(){
    //     console.log("signWith google")
    // }

    signUp(){
        this._router.navigate(['/sign-up'])
    }

    forgotpassword(){
        this._router.navigate(['/forgot-password'])

    }

    //  selectedUserType: 'doctor' | 'patient' = 'doctor';
   selectedUserType = 'doctor';
  UserType: string[] = ['doctor', 'patient'];

    signwithGoogle() {
        // if (!this.selectedUserType) {
        //     alert('Please select whether you are a Doctor or Patient');
        //     return;
        // }

        // console.log('type---------', this.selectedUserType);
        // Redirect to your backend with user type as query param
        window.location.href = `${config.apiBaseURL}/common/auth/google`;
        //this.selectedUserType = null
    }
}
