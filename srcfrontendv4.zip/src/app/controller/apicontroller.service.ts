import { Injectable } from '@angular/core';
import { ApiService } from '../Services/api.service';

@Injectable({
    providedIn: 'root',
})
export class ApicontrollerService {
    constructor(private apiService: ApiService) {}

    async loginuser(logindata: any, url: string = 'common/registration') {
        const data = {
            fn: 'common_fn',
            se: 'lo_us',
            data: logindata,
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

    // --------------------------------

    async createschool(schooldata: any, url: string = 'common') {
        const data = {
            fn: 'common_fn',
            se: 'cr_sh',
            data: schooldata,
        };

        // console.log(data)
        const resp: any = await this.apiService.postUrl(data, url);
        // console.log(resp);
        return resp;
    }

    async registerschool(schooldata: any, url: string = 'common/registration') {
      const data = {
          fn: 'common_fn',
          se: 're_sh',
          data: schooldata,
      };

      // console.log(data)
      const resp: any = await this.apiService.postUrl(data, url);
      // console.log(resp);
      return resp;
  }
}
