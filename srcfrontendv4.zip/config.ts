export const config = {
    // apiBaseURL : 'http://192.168.1.5:3000',
    // apiBaseURL : 'https://clientlogs.ftisindia.com',
    apiBaseURL : 'http://192.168.114.1:3000',

    // apiBaseURL:'https://7e16-223-185-19-41.ngrok-free.app'

    // apiBaseURL:'https://research.ftisindia.com'

    // cryptoSecret: "AmnVRMN38h",
}

