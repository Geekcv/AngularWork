import { Routes } from '@angular/router';
import { ShowSubjectComponent } from './show-subject.component';

export default [
    {
        path: '',
        component: ShowSubjectComponent,
    },
] as Routes;
