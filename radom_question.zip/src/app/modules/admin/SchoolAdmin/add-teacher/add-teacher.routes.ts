import { Routes } from '@angular/router';
import { AddTeacherComponent } from './add-teacher.component';

export default [
    {
        path: '',
        component: AddTeacherComponent,
    },
] as Routes;
