import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowTeacherDeailsComponent } from './show-teacher-deails.component';

describe('ShowTeacherDeailsComponent', () => {
  let component: ShowTeacherDeailsComponent;
  let fixture: ComponentFixture<ShowTeacherDeailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ShowTeacherDeailsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShowTeacherDeailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
