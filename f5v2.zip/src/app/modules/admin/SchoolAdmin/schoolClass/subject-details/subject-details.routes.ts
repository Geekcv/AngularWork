import { Routes } from '@angular/router';
import { SubjectDetailsComponent } from './subject-details.component';

export default [
    {
        path: '',
        component: SubjectDetailsComponent,
    },
] as Routes;
