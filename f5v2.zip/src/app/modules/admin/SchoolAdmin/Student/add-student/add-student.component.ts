import { Component, inject, ViewChild } from '@angular/core';
import { FormsModule, NgForm, ReactiveFormsModule, UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { config } from '../../../../../../../config';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CommonModule } from '@angular/common';

interface school{
  row_id:string;
  name:string;
}

interface classData{
  row_id:string;
  name:string
}

interface SchoolAdmin {
    email: string;
    role: string;
    name: string;
    row_id: string;
    school_id:string
  }


@Component({
  selector: 'app-add-student',
  imports: [
     FormsModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatInputModule,
        MatButtonModule,
        MatIconModule,
        MatCheckboxModule,
        MatProgressSpinnerModule,
        MatSelectModule,CommonModule
  ],
  templateUrl: './add-student.component.html',
  styleUrl: './add-student.component.scss'
})
export class AddStudentComponent {
@ViewChild('studentNgForm') studentNgForm: NgForm;

  studentForm: UntypedFormGroup;
  showAlert = false;
  role: any = '';
  config: any;
   schoolList : school[]; 
  classList = []; 
  // schooldata: school[]

  SchoolAdminDeatials: SchoolAdmin = {
        email: '',
        name: '',
        role:'',
        row_id: '',
        school_id:''
      };

  constructor(
      private _formBuilder: UntypedFormBuilder,
      private _router: Router,

      private Apicontroller: ApicontrollerService,

  ) {
      this.config = config.apiBaseURL;
      
      this.role = localStorage.getItem('role');
      this.SchoolAdminDeatials = JSON.parse(localStorage.getItem("userDeatials"));

      this.fetchOwnclass()
  }

  private _snackBar = inject(MatSnackBar);

  ngOnInit(): void {
      this.studentForm = this._formBuilder.group({
          name: ['', Validators.required],
    email: ['', Validators.email],
    phone: [''],
    password:[''],
    class_id: ['', Validators.required],
    is_active: [true]
      });
  }

 

  async addStudent(): Promise<void> {
      if (this.studentForm.invalid) {
          this.studentForm.markAllAsTouched();
          return;
      }

      const payload = {
          ...this.studentForm.value,
          school_row_id: this.SchoolAdminDeatials.school_id

      };

      const resp = await this.Apicontroller.createstudent(payload);

      if (resp.status === 0) {
          this._snackBar.open(resp.msg, '', {
              duration: 3000,
              verticalPosition: 'top',
              horizontalPosition: 'center',
          });

          this.studentNgForm.resetForm();
      } else {
          this._snackBar.open(resp.msg || 'Failed to add student', '', {
              duration: 3000,
              verticalPosition: 'top',
              horizontalPosition: 'center',
          });
      }
  }





 




     async fetchOwnclass(){
        // this.selectedValue = (event.target as HTMLSelectElement).value;
      

        const resp = await this.Apicontroller.fetchAllclassOfSchool('common', this.SchoolAdminDeatials.school_id);
        console.log("resp",resp)
        this.classList = resp as classData[]
       

      }
}
