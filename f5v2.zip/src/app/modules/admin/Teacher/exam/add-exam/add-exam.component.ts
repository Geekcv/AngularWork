import { HttpClient } from '@angular/common/http';
import { Component, inject, ViewChild } from '@angular/core';
import {
    FormsModule,
    NgForm,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { config } from '../../../../../../../config';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core'; // For native date adapter


interface Class {
  row_id: string;
  name: string;


}


interface subjectData{
  row_id:string;
  name:string
}


interface Teacher{
  email: string;
  name:string;
  row_id:string;
  role:string;
}

@Component({
  selector: 'app-add-exam',
  imports: [FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatCheckboxModule,
    MatProgressSpinnerModule,
    MatSelectModule,MatDatepickerModule,MatNativeDateModule],
  templateUrl: './add-exam.component.html',
  styleUrl: './add-exam.component.scss'
})
export class AddExamComponent {
  @ViewChild('examNgForm') examNgForm: NgForm;

  examForm: UntypedFormGroup;
  showAlert = false;
  role: any = '';
  config: any;

  subjectList = []
  chapterList = []
  classList = []

  
  TeacherDeatials: Teacher = {
    email: '',
    name:'',
    row_id:'',
    role:''
    };

  constructor(
      private _formBuilder: UntypedFormBuilder,
      private _router: Router,
      private api: ApicontrollerService,
  ) {
      this.config = config.apiBaseURL;
      this.role = localStorage.getItem('role');
    this.TeacherDeatials = JSON.parse(localStorage.getItem("userDeatials"));

      this.fetchclassdata()
    }

  private _snackBar = inject(MatSnackBar);

  ngOnInit(): void {
    this.examForm = this._formBuilder.group({
      subject_id: ['', Validators.required],
      chapter_id: ['', Validators.required],
      class_id:['',Validators.required],
      name: ['', Validators.required],
      total_marks: [null],
      passing_marks: [null],
      duration_minutes: [null],
      scheduled_on: [null],
    });
    
  }

  // boardList = [
  //     { row_id: '1729833318838_Ir5A', name: 'CBSE' },
  //     { row_id: '1729862517377_iMzd', name: 'RBSE' },
  // ];


  async submitExam(): Promise<void> {
      if (this.examForm.invalid) {
          this.examForm.markAllAsTouched();
          return;
      }

      const payload = {
          ...this.examForm.value,
      };

      const resp = await this.api.addChapter(payload);

      if (resp.status === 0) {
          this._snackBar.open(resp.msg, '', {
              duration: 3000,
              verticalPosition: 'top',
              horizontalPosition: 'center',
          });

          this.examNgForm.resetForm();
      } else {
          this._snackBar.open(resp.msg || 'Failed to add chapter', '', {
              duration: 3000,
              verticalPosition: 'top',
              horizontalPosition: 'center',
          });
      }
  }

  selectedValue:any;

    async onSelectionChange(event: Event){
        // this.selectedValue = (event.target as HTMLSelectElement).value;
        console.log('Selected value:---------', this.selectedValue);

        const resp = await this.api.fetchSubjectChapter(
          'common',
          this.selectedValue
      );        console.log("resp",resp)
        this.chapterList = resp as Class[]
       

      }

      async fetchclassdata() {
        console.log(" before data")
    
        try {
          const resp = await this.api.fetchOwnlass('common', this.TeacherDeatials.row_id);
          //  this.classData.data = resp
          console.log("class data ------------------>", resp.data);
    
          this.classList = resp.data as Class[];
    
          // Add sr_no for each row (based on pagination if needed)
         
    
    
        } catch (error) {
          // console.error("Error fetching doctors:", error);
        }
    
      }
    

  // 

    selectedValueclass:any;

    async onSelectionChangeclass(event: Event){
        // this.selectedValue = (event.target as HTMLSelectElement).value;
        console.log('Selected value:---------', this.selectedValueclass);

        const dataid = {
          class_id : this.selectedValueclass,
          teacher_id:this.TeacherDeatials.row_id
         }

        const resp = await this.api.fetchClassSubjectByteacher('common',dataid);
        console.log("resp",resp)
        this.subjectList = resp as subjectData[]
       

      }
}
