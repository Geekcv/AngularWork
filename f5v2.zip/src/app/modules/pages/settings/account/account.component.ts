

import { TextFieldModule } from '@angular/cdk/text-field';
import { CommonModule, JsonPipe } from '@angular/common';
import {
    ChangeDetectionStrategy,
    ChangeDetectorRef,
    Component,
    inject,
    LOCALE_ID,
    OnInit,
    ViewEncapsulation,
} from '@angular/core';
import {
    FormsModule,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatOptionModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { escape } from 'lodash';
import { config } from '../../../../../../config';
import { HttpClient } from '@angular/common/http';


interface Doctor {
  doctor_email: string;
  doctor_gender: string;
  firstname:string;
  lastname: string;
  user_contact_number: string;
  user_password: string;
  row_id: string;
}

interface Patient{
  patient_age: string;
  patient_email: string;
  patient_gender: string;
  patient_firstname: string;
  patient_lastname:string;
  user_password: string;
  user_contact_number: string;
  row_id:string;
}

interface Admin{
  firstname: string;
  email:string;
  lastname: string;
  gender: string;
  photo_path: string;
  user_contact_number: string;
  row_id:string;
}

@Component({
    selector: 'settings-account',
    templateUrl: './account.component.html',
    // encapsulation: ViewEncapsulation.None,
    changeDetection: ChangeDetectionStrategy.OnPush,
    imports: [
        FormsModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatIconModule,
        MatInputModule,
        TextFieldModule,
        MatSelectModule,
        MatOptionModule,
        MatButtonModule,FormsModule,CommonModule
        
    ],
})
export class SettingsAccountComponent implements OnInit {

      private _snackBar = inject(MatSnackBar);
  
    config:any ;
     filepath:any;
mediatype:any;

    accountForm: UntypedFormGroup;
      userDeatials: Doctor = {
        doctor_email: '',
        doctor_gender: '',
        firstname:'',
        lastname: '',
        user_contact_number: '',
        user_password: '',
        row_id: ''
      };
      role :any ='';
    
      patientDeatials: Patient = {
        patient_age: '',
      patient_email: '',
      patient_gender: '',
      patient_firstname: '',
      patient_lastname:'',
      user_password: '',
      user_contact_number: '',
      row_id:''
      };

      AdminDeatials: Admin = {
        firstname: '',
      lastname: '',
      email:'',
      gender: '',
      photo_path: '',
      user_contact_number: '',
      row_id:''
      };
    
      google_user:any;
    genders: string[] = ['Male', 'Female', 'Other']; // List of genders
profileImagePreview: any;
resp:any


firstname:any;
lastname:any;
email:any;
gender:any;
user_contact_number:any;
photo_path:any
row_id:any;
    
      constructor(private _formBuilder: UntypedFormBuilder, private Apicontroller: ApicontrollerService,
        private http: HttpClient,private cdRef: ChangeDetectorRef
      ) {

      
        
           this.config = config.apiBaseURL
        
        this.role = Number(localStorage.getItem('role')) || 0; // Convert role to a number
    
        if(this.role==2){
          this.patientDeatials = JSON.parse(localStorage.getItem("userDeatials"));
           if (localStorage.getItem("google_user") === 'undefined') {
            console.log("undefined user")
            this.google_user = 0;
           }else{
          this.google_user = JSON.parse(localStorage.getItem("google_user"))

           }
          console.log("google users---",this.google_user)

    
        }else if(this.role == 1){
          
          this.userDeatials = JSON.parse(localStorage.getItem("userDeatials"));
          if (localStorage.getItem("google_user") === 'undefined') {
            console.log("undefined user")
            this.google_user = 0;
           }else{
          this.google_user = JSON.parse(localStorage.getItem("google_user"))

           }
          console.log("google users---",this.google_user)

        } else if(this.role == 0){
          this.AdminDeatials = JSON.parse(localStorage.getItem("userDeatials"));
        }

      

        
      }
    
     async ngOnInit(){
             

       
      }

      async submit(){
        console.log("sumbit data",this.accountForm.value)

         const data = {
        "firstname":this.accountForm.value.firstname,
        "lastname":this.accountForm.value.lastname,
        "email":this.accountForm.value.email,
        "phone":this.accountForm.value.phone,
        "gender":this.accountForm.value.gender, 
        "row_id":this.accountForm.value.row_id,       
        "photo_path":this.filepath || this.AdminDeatials.photo_path
      }

          
      }


  onProfileImageSelected(event: Event): void {
        const input = event.target as HTMLInputElement;
    
        if (input.files && input.files.length > 0) {
            const file = input.files[0];
    
            //  Show preview instantly (before upload)
            const reader = new FileReader();
            reader.onload = () => {
                this.profileImagePreview = reader.result as string; // Base64 string for instant view
                 this.cdRef.detectChanges();
            };
            reader.readAsDataURL(file);
    
            // Upload to server
            const formData = new FormData();
            formData.append('file', file);
    
            this.http.post(`${this.config}/common/upload`, formData).subscribe({
                next: (response: any) => {
                    if (response?.data) {
                        this.filepath = response.data.foPa || response.data.filePath;
                        this.mediatype = response.data.mimetype;
    
                        // Update the AdminDeatials so it's saved on submit
                        this.AdminDeatials.photo_path = this.filepath;
                    }
                },
                error: (err) => console.error('Upload failed', err),
            });
        }

    
    }
    
admindata:any;
profile_path:any;
doctor_email:any
doctor_gender:any
patient_firstname:any
patient_gender:any
patient_lastname:any
patient_email:any

  

    isEditMode = false;
  originalDoctorData: any = {};


  toggleEditMode() {
    console.log('Before Edit:', this.admindata[0]?.firstname); // should show value like "Abhishek"
    this.originalDoctorData = JSON.parse(JSON.stringify(this.admindata[0]));
    this.isEditMode = true;
  }
  

  cancelEdit() {
    this.admindata[0] = JSON.parse(JSON.stringify(this.originalDoctorData)); // restore original
    this.isEditMode = false;
  }

  async savedataInfo() {
    // Add API call here if needed
    console.log('Saving doctor:', this.admindata[0]);
    this.isEditMode = false;

    

    if(this.role === 0){
         const data = {
        "firstname":this.admindata[0].firstname,
        "lastname":this.admindata[0].lastname,
        "email":this.admindata[0].email,
        "phone":this.admindata[0].user_contact_number,
        "gender":this.admindata[0].gender, 
        "row_id":this.admindata[0].row_id,       
        "photo_path":this.filepath || this.admindata[0].photo_path
      }

      console.log("data",data)

          
      }else if(this.role === 1){


  const data = {
        "firstname":this.admindata[0].firstname,
        "lastname":this.admindata[0].lastname,
        "email":this.admindata[0].doctor_email,
        "phone":this.admindata[0].user_contact_number,
        "gender":this.admindata[0].doctor_gender, 
        "row_id":this.admindata[0].row_id,       
        "photo_path":this.filepath || this.admindata[0].photo_path
      }

      console.log("data",data)

         
      } else if (this.role === 2){



  const data = {
        "firstname":this.admindata[0].patient_firstname,
        "lastname":this.admindata[0].patient_lastname,
        "email":this.admindata[0].patient_email,
        "phone":this.admindata[0].user_contact_number,
        "gender":this.admindata[0].patient_gender, 
        "row_id":this.admindata[0].row_id,       
        "photo_path":this.filepath || this.admindata[0].photo_path
      }

      console.log("data",data)

          
      }

        
  }
    
}
