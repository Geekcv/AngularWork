import { Component, inject, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import {
    FormsModule,
    NgForm,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router, RouterLink } from '@angular/router';
import { fuseAnimations } from '@fuse/animations';
import { FuseAlertComponent, FuseAlertType } from '@fuse/components/alert';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { AuthService } from 'app/core/auth/auth.service';
import { config } from '../../../../../../../config';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';

interface school{
  row_id:string;
  name:string;
}


@Component({
  selector: 'app-sign-up-teacher',
  imports: [RouterLink,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatCheckboxModule,
    MatProgressSpinnerModule,
    MatSelectModule,CommonModule],
  templateUrl: './sign-up-teacher.component.html',
  styleUrl: './sign-up-teacher.component.scss'
})
export class SignUpTeacherComponent {
  @ViewChild('teacherNgForm') teacherNgForm: NgForm;
 
  teacherForm: UntypedFormGroup;

  
  role :any ='';
config:any ;


 

  private _snackBar = inject(MatSnackBar);
  schoolList : school[]; 

  /**
   * Constructor
   */
  constructor(
      private _formBuilder: UntypedFormBuilder,
      private Apicontroller: ApicontrollerService,private router: Router,
  ) {
     this.config = config.apiBaseURL 
  this.role=  localStorage.getItem('role')
  this.fetchallSchool()
  // console.log("my role",this.role)

  }

  // -----------------------------------------------------------------------------------------------------
  // @ Lifecycle hooks
  // -----------------------------------------------------------------------------------------------------

  /**
   * On init
   */
  ngOnInit(): void {
      // Create the form
      this.teacherForm = this._formBuilder.group({
        name: ['', Validators.required],
  email: ['', Validators.email],
  phone: [''],
  password:[''],
  qualification:[''],
  experience:[''],
  school_row_id:['']
  
    });
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  /**
   * Sign up
   */ 

  async addTeacher(): Promise<void> {
    if (this.teacherForm.invalid) {
        this.teacherForm.markAllAsTouched();
        return;
    }

    const payload = {
        ...this.teacherForm.value,

    };

    const resp = await this.Apicontroller.createteacher(payload);

    if (resp.status === 0) {
        this._snackBar.open(resp.msg, '', {
            duration: 3000,
            verticalPosition: 'top',
            horizontalPosition: 'center',
        });

        this.teacherNgForm.resetForm();
    } else {
        this._snackBar.open(resp.msg || 'Failed to add teacher', '', {
            duration: 3000,
            verticalPosition: 'top',
            horizontalPosition: 'center',
        });
    }
}


  async  fetchallSchool(){

    const resp = await this.Apicontroller.fetchAllSchool();
    console.log("fetch all school ------->",resp)
    this.schoolList = resp as school[]
    
}



   

}
