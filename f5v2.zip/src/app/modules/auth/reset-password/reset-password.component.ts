import { HttpClient } from '@angular/common/http';
import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import {
    FormsModule,
    NgForm,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { fuseAnimations } from '@fuse/animations';
import { FuseAlertComponent, FuseAlertType } from '@fuse/components/alert';
import { AuthService } from 'app/core/auth/auth.service';
import { config } from '../../../../../config';

@Component({
    selector: 'auth-reset-password',
    templateUrl: './reset-password.component.html',
    encapsulation: ViewEncapsulation.None,
    animations: fuseAnimations,
    imports: [
        FuseAlertComponent,
        FormsModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatInputModule,
        MatButtonModule,
        MatIconModule,
        MatProgressSpinnerModule,
        RouterLink,
    ],
})
export class AuthResetPasswordComponent implements OnInit {
    @ViewChild('resetPasswordNgForm') resetPasswordNgForm: NgForm;

    alert: { type: FuseAlertType; message: string } = {
        type: 'success',
        message: '',
    };
    forgotPasswordForm: UntypedFormGroup;
    showAlert: boolean = false;

    config:any = config.apiBaseURL
    email:any;
    otp:any;

    /**
     * Constructor
     */
    constructor(
        private _authService: AuthService,
        private _formBuilder: UntypedFormBuilder,
        private http: HttpClient, 
        private snackBar: MatSnackBar, 
        private router: Router,
         private route: ActivatedRoute,
    ) {}

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void {
        // Create the form
       
        console.log("config",config)

            this.route.queryParams.subscribe((params) => {
     this.email = params['email'];
     this.otp = params['otp'];


    //   console.log("token----",email,otp)

      
     })

      this.forgotPasswordForm = this._formBuilder.group({
            email: [this.email, [Validators.required, Validators.email]],
            otp: [this.otp, Validators.required],
            new_password: ['', [Validators.required]],
        });

    }

    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * Reset password
     */
    submitResetPassword() {
        this.forgotPasswordForm.disable();

        console.log(
            'this.forgotPasswordForm.value',
            this.forgotPasswordForm.value
        );
        const { email, otp, new_password } = this.forgotPasswordForm.value;

        this.http
            .post(`${config.apiBaseURL}/common/auth/reset-password`, {
                email,
                otp,
                new_password,
            })
            .subscribe({
                next: (res: any) => {
                    this.snackBar.open(res.message, 'Close', {
                       duration: 3000, // Duration in milliseconds (3 seconds)
        verticalPosition: 'top', // Position: 'top' | 'bottom'
        horizontalPosition: 'center', // Position: 'start' | 'center' | 'end' | 'left' | 'right'
                    });
                    this.router.navigate(['/sign-in']);
                },
                error: (err) => {
                    this.snackBar.open(
                        err.error.message || 'Something went wrong',
                        'Close',
                        { duration: 3000,
                              verticalPosition: 'top', // Position: 'top' | 'bottom'
        horizontalPosition: 'center', // Position: 'start' | 'center' | 'end' | 'left' | 'right'
                         }
                    );
                },
                complete: () => {
                    this.forgotPasswordForm.enable();
                },
            });
    }
}
