import { HttpClient } from '@angular/common/http';
import { Component, inject, ViewChild } from '@angular/core';
import {
    FormsModule,
    NgForm,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { config } from '../../../../../../../config';

interface board {
 row_id:string;
  name:string;
}

@Component({
  selector: 'app-add-school',
  imports: [
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatCheckboxModule,
    MatProgressSpinnerModule,
    MatSelectModule,
  ],
  templateUrl: './add-school.component.html',
  styleUrl: './add-school.component.scss'
})
export class AddSchoolComponent {
  @ViewChild('schoolNgForm') schoolNgForm: NgForm;

  schoolForm: UntypedFormGroup;
  showAlert = false;
  role: any = '';
  config: any;
  filepath: any;
  mediatype: any;

  constructor(
      private _formBuilder: UntypedFormBuilder,
      private _router: Router,
      private api: ApicontrollerService,
  ) {
      this.config = config.apiBaseURL;
      this.role = localStorage.getItem('role');
      this.fetchallboard()
  }

  private _snackBar = inject(MatSnackBar);

  ngOnInit(): void {
      this.schoolForm = this._formBuilder.group({
          name: ['', Validators.required],
          email: ['', [Validators.required, Validators.email]],
          phone: ['', Validators.required],
          address: ['', Validators.required],
          board_id: ['', Validators.required], 
          password: ['', Validators.required],
          is_active: [true],
      });
  }

//   boardList = [
//       { row_id: '1729833318838_Ir5A', name: 'CBSE' },
//       { row_id: '1729862517377_iMzd', name: 'RBSE' },
//   ];

  async addSchool(): Promise<void> {
      if (this.schoolForm.invalid) {
          this.schoolForm.markAllAsTouched();
          return;
      }

      const payload = {
          ...this.schoolForm.value,
          created_by: localStorage.getItem('row_id') || '', // optional
      };

      const resp = await this.api.createschool(payload);

      if (resp.status === 0) {
          this._snackBar.open(resp.msg, '', {
              duration: 3000,
              verticalPosition: 'top',
              horizontalPosition: 'center',
          });

          this.schoolNgForm.resetForm();
      } else {
          this._snackBar.open(resp.msg || 'Failed to add school', '', {
              duration: 3000,
              verticalPosition: 'top',
              horizontalPosition: 'center',
          });
      }
  }

  boardList = []
   async fetchallboard(){
    // 
      const resp = await this.api.fetchallBoard();
      this.boardList = resp as board[]

  }
}


