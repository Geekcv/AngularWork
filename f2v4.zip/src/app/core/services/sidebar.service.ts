// src/app/core/services/sidebar.service.ts
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SidebarService {
  private _collapse = new BehaviorSubject<boolean>(false);

  // Observable for component binding
  collapse$ = this._collapse.asObservable();

  // Toggle the state
  toggleCollapse(): void {
    this._collapse.next(!this._collapse.value);
  }

  // Set collapse explicitly
  setCollapse(value: boolean): void {
    this._collapse.next(value);
  }

  // Get current value
  get collapse(): boolean {
    return this._collapse.value;
  }
}
