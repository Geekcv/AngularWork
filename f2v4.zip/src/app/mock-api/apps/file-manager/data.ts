/* eslint-disable */
export const items = [
    {
        id: 'cd6897cb-acfd-4016-8b53-3f66a5b5fc68',
        folderId: null,
        name: 'Personal',
        createdBy: 'Brian Hughes',
        createdAt: 'April 24, 2018',
        modifiedAt: 'April 24, 2018',
        size: '87 MB',
        type: 'folder',
        contents: '57 files',
        description:
            'Personal documents such as insurance policies, tax papers and etc.',
    },

];
