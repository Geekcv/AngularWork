import { Component, Inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import {
  MatDialog,
  MatDialogActions,
  MatDialogClose,
  MatDialogContent,
  MatDialogRef,
  MatDialogTitle,
} from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { ApicontrollerService } from 'app/controller/apicontroller.service';


@Component({
  selector: 'app-deldialog',
  imports: [MatDialogModule,MatButtonModule,MatIconModule],
  templateUrl: './deldialog.component.html',
  styleUrl: './deldialog.component.css'
})
export class DeldialogComponent {

  ID:any;


  constructor(
     @Inject(MAT_DIALOG_DATA) public data: {patient: any},
                private dialogRef: MatDialogRef<DeldialogComponent>, // Inject MatDialogRef   ,
                    private Apicontroller: ApicontrollerService
                
  ){
      console.log("doctor id",data.patient.user_row_id)
      this.ID = data.patient.user_row_id;

  }

async  deleteresponse(){
    console.log("delete this patiens ",this.ID)

    var data ={
      row_id:this.ID,
      deleted:1
    }

    console.log("data-->",data)

    const resp = await this.Apicontroller.softdelPatient(data);

    // console.log("resp------->",resp)


     this.dialogRef.close(resp);
    //  this.dialogRef.close();
  }

   exitbtn() {
      this.dialogRef.close();
  }

}
