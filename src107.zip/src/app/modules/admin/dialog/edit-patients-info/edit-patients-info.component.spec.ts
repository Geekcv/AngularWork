import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditPatientsInfoComponent } from './edit-patients-info.component';

describe('EditPatientsInfoComponent', () => {
  let component: EditPatientsInfoComponent;
  let fixture: ComponentFixture<EditPatientsInfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EditPatientsInfoComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EditPatientsInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
