import { CommonModule } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import {
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatDrawer, MatSidenavModule } from '@angular/material/sidenav';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatStepperModule } from '@angular/material/stepper';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { config } from '../../../../../../../config';
import { HttpClient } from '@angular/common/http';

interface Doctor {
  doctor_email: string;
  doctor_gender: string;
  doctor_name: string;
  user_contact_number:string;
  user_password:string;
  user_row_id:string;
}


@Component({
    selector: 'app-addpatientdialog',
    imports: [
        MatSelectModule,
        MatStepperModule,
        MatFormFieldModule,
        MatInputModule,
        ReactiveFormsModule,
        MatButtonModule,
        MatDialogModule,MatSidenavModule,        MatIconModule,CommonModule
    ],
    templateUrl: './addpatientdialog.component.html',
    styleUrls: ['./addpatientdialog.component.scss'],
})
export class AddpatientdialogComponent implements OnInit {
[x: string]: any;
    signUpForm: UntypedFormGroup;
    genders: string[] = ['Male', 'Female', 'Other'];
    passwordFieldType: 'password' | 'text' = 'password';
    @ViewChild('drawer') drawer: MatDrawer;
    drawerMode: 'over' | 'side' = 'side';
    drawerOpened: boolean = true;
  doctors: Doctor[];

   config:any ;
  filepath:any;
mediatype:any;

    constructor(
        private _formBuilder: UntypedFormBuilder,
        private _router: Router,
        private _snackBar: MatSnackBar,
        private _apiController: ApicontrollerService,
        private Apicontroller: ApicontrollerService,
        private dialogRef: MatDialogRef<AddpatientdialogComponent>,private http: HttpClient
    ) {
         this.config = config.apiBaseURL
  this.mydoctor()

    }

    ngOnInit(): void {
        this.signUpForm = this._formBuilder.group({
            patient_fname: ['', Validators.required],
            patient_lname: ['', Validators.required],
            patient_email: ['', [Validators.required, Validators.email]],
            patient_number: ['', Validators.required],
            patient_password: ['', Validators.required],
            patient_age: ['', Validators.required],
            patient_gender: ['', Validators.required],
            study_name: ['', Validators.required],
            study_arm: ['', Validators.required],
            // researcher_name: ['', Validators.required],
            researcher_mobile: ['', Validators.required],
            researcher_email: ['', Validators.required],
            doctor_id:['',Validators.required]
        });
    }

    togglePasswordVisibility() {
        this.passwordFieldType =
            this.passwordFieldType === 'password' ? 'text' : 'password';
    }

    exitbtn() {
        this.dialogRef.close();
    }

    async addPatient() {
        if (this.signUpForm.invalid) {
            this.signUpForm.markAllAsTouched();
            return;
        }


const data = {
        "doctor_id":this.signUpForm.value.doctor_id,
        "patient_fname":this.signUpForm.value.patient_fname,
        "patient_lname":this.signUpForm.value.patient_lname,
        "patient_email":this.signUpForm.value.patient_email,
        "patient_number":this.signUpForm.value.patient_number,
        "patient_password":this.signUpForm.value.patient_password,
        // "doctor_type":this.signUpForm.value.doctor_type,
        "patient_age":this.signUpForm.value.patient_age,
        "patient_gender":this.signUpForm.value.patient_gender,
        "study_name":this.signUpForm.value.study_name,
        // "doctor_type":this.signUpForm.value.doctor_type,
        "study_arm":this.signUpForm.value.study_arm,
        "researcher_name":this.signUpForm.value.researcher_name,
        "researcher_mobile":this.signUpForm.value.researcher_mobile,
        "researcher_email":this.signUpForm.value.researcher_email,

        "photo_path":this.filepath
      }




        console.log("add patients ",data)
        const resp = await this._apiController.AddPatients(
            data
        );

        // if (resp.status === 0) {
        //     this._snackBar.open(resp.msg, '', {
        //         duration: 3000,
        //         verticalPosition: 'top',
        //         horizontalPosition: 'center',
        //     });

        //     // this.dialogRef.close();
        //     // this._router.navigate(['/Viewpatients']);
        // } else {
        //     this._snackBar.open('Error creating patient account.', '', {
        //         duration: 3000,
        //         verticalPosition: 'top',
        //         horizontalPosition: 'center',
        //     });
        // }
    }

    create(){
        const email = this.signUpForm.value.patient_email;
        const doc_email = this.signUpForm.value.researcher_email;

        

        console.log("patients email========",email)

        this.http
            .post(`${config.apiBaseURL}/common/auth/email`, {
              email,
            })
            .subscribe({
                next: (res: any) => {
                    console.log("res---",res)
                   
                 
                },
                error: (err) => {
                    console.log("err---",err)
                    
                },
                complete: () => {
                    console.log("rcompletees---",)
                 
                },
            }); 


             this.http
            .post(`${config.apiBaseURL}/common/auth/email`, {
              email:doc_email,
            })
            .subscribe({
                next: (res: any) => {
                    console.log("res---",res)
                   
                 
                },
                error: (err) => {
                    console.log("err---",err)
                    
                },
                complete: () => {
                    console.log("rcompletees---",)
                 
                },
            }); 
    }
    finish() {
        if (this.signUpForm.valid) {
            // Call your addPatient logic or API

            // Optionally, show a confirmation message or close dialog
            this.dialogRef.close(true); // If using MatDialog
        }
    }

    page: number = 1; // Default to first page

  async mydoctor() {
    console.log(" mydoctor")

    try {
      const resp = await this.Apicontroller.fetchdoctor('common',this.page);
      console.log("doctor", resp);
      this.doctors = resp.data as Doctor[]; // Type assert to Doctor[]
      console.log("doctors", this.doctors);



    } catch (error) {
      // console.error("Error fetching doctors:", error);
    }

  }

  selectedValue: string = '';
researcher_mobile:string = ''
researcher_email:string = ''

     async onSelectionChange(event: Event){
        // this.selectedValue = (event.target as HTMLSelectElement).value;
        console.log('Selected value:---------', this.selectedValue);

        const resp = await this.Apicontroller.fetchdoctordetails('common', this.selectedValue);
        console.log("resp",resp)
        console.log("resp",resp.data[0].user_contact_number)
        this.researcher_mobile = resp.data[0].user_contact_number;
        // doctor_email
        this.researcher_email = resp.data[0].doctor_email;

        console.log("data",this.researcher_email,this.researcher_mobile)


      }

       onProfileImageSelected(event: Event): void {
   const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      const file = input.files[0];
      const formData = new FormData();
      formData.append('file', file);
  
      console.log(`upload file path  ${this.config}/common/upload`)
    this.http.post(`${this.config}/common/upload`, formData).subscribe({
      next: async (response: any) => {
        console.log("res",response)
        if (response) {
          this.filepath = response.data.foPa || response.data.filePath; // Ensure correct key name
          this.mediatype = response.data.mimetype;

          console.log('Uploaded File:',this.filepath, this.mediatype);         
         
          
        } else {
          console.log("Invalid server response")

        }
      },
      error: (error) => {
        console.error('Upload failed:', error);
      },
    });

    }
}
}
