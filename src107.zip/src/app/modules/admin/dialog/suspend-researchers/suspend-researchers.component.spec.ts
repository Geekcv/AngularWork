import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SuspendResearchersComponent } from './suspend-researchers.component';

describe('SuspendResearchersComponent', () => {
  let component: SuspendResearchersComponent;
  let fixture: ComponentFixture<SuspendResearchersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SuspendResearchersComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SuspendResearchersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
