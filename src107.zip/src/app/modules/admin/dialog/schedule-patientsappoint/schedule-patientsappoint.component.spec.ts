import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SchedulePatientsappointComponent } from './schedule-patientsappoint.component';

describe('SchedulePatientsappointComponent', () => {
  let component: SchedulePatientsappointComponent;
  let fixture: ComponentFixture<SchedulePatientsappointComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SchedulePatientsappointComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SchedulePatientsappointComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
