import { Component, Inject, inject, ViewChild } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { DeldialogComponent } from '../../dialog/deldialog/deldialog.component';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { AdddoctordialogComponent } from '../../dialog/adddoctordialog/adddoctordialog.component';
import { CommonModule, NgClass, NgIf, NgStyle, NgSwitch } from '@angular/common';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { FuseDrawerComponent } from '@fuse/components/drawer';
import { FormsModule, NgControl, NgForm, ReactiveFormsModule, UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatSnackBar } from '@angular/material/snack-bar';
import { HttpClient } from '@angular/common/http';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { config } from '../../../../../../config';
import { MatStepperModule } from '@angular/material/stepper';
import { SuspendPatientComponent } from '../../dialog/suspend-patient/suspend-patient.component';



interface Doctor {
  doctor_email: string;
  doctor_gender: string;
  doctor_name: string;
  user_contact_number: string;
  user_password: string;
  user_row_id: string;
  firstname: string;
  lastname: string;
  institution: string;

}


interface Column {
  name: string; // The column name/key (must match MatTable's columnDef)
  label: string; // The displayed label for checkbox and header
  visible: boolean; // Whether this column is currently shown
}


@Component({
  selector: 'app-viewresearchers',
  imports: [
    MatTableModule, 
    MatPaginatorModule, 
    MatButtonModule,
    MatIconModule,
    MatInputModule, 
    NgStyle, MatTooltipModule, MatSortModule, FuseDrawerComponent,
    ReactiveFormsModule, MatFormFieldModule,
    MatCheckboxModule,
    MatDialogModule,  
    MatProgressSpinnerModule, MatSelectModule, CommonModule,
    FormsModule,

  ],
  templateUrl: './viewresearchers.component.html',
  styleUrl: './viewresearchers.component.css'
})
export class ViewresearchersComponent {
  role: any = '';
  // doctor: Doctor[] = [];

  doctor = new MatTableDataSource<Doctor>([]); // Use MatTableDataSource for pagination
    // patient = new MatTableDataSource<Patient>([]); // Use MatTableDataSource for pagination
  

  isSearchActive = false;
  isempty = false;
  signUpForm: UntypedFormGroup;

  config: any;
  filepath: any;
  mediatype: any;


  private _snackBar = inject(MatSnackBar);


  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  @ViewChild('signUpNgForm') signUpNgForm: NgForm;

  // readonly dialogRef = inject(MatDialogRef<ViewresearchersComponent>);
  genders: string[] = ['Male', 'Female', 'Other']; // List of genders
  profileImagePreview: any;


     get displayedColumns(): string[] {
        return this.columns.filter((c) => c.visible).map((c) => c.name);
    }



  constructor(
    private Apicontroller: ApicontrollerService,
    private router: Router,
    private _matDialog: MatDialog,
    private _formBuilder: UntypedFormBuilder,
    private http: HttpClient

  ) {
    this.config = config.apiBaseURL

    this.role = localStorage.getItem('role')
this.mydoctor()
    // console.log("my role",this.role)
  }

  ngOnInit(): void {
    console.log(" ngOnInit")

    this.mydoctor();

    this.signUpForm = this._formBuilder.group({
      doctor_fname: ['', Validators.required],
      doctor_lname: ['', Validators.required],
      doctor_email: ['', [Validators.required, Validators.email]],
      doctor_phone: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
      doctor_password: ['', Validators.required],
      // doctor_type: ['', Validators.required],
      doctor_gender: ['', Validators.required],
      institution: ['', Validators.required]
    });
  }

  ngAfterViewInit() {
    console.log(" ngAfterViewInit")
    this.doctor.paginator = this.paginator; // Set paginator after view init
    this.doctor.sort = this.sort; // Set paginator after view init

  }




  columns: Column[] = [
    { name: 'sr_no', label: 'Sr.no', visible: true },
    { name: 'firstname', label: 'First Name', visible: true },
    { name: 'lastname', label: 'Last Name', visible: true },

    { name: 'doctor_email', label: 'Email', visible: true },
    { name: 'doctor_gender', label: 'Gender', visible: true },
    { name: 'user_contact_number', label: 'Phone', visible: true },
    { name: 'institution', label: 'Institution', visible: true },
    {
      name: 'user_password',
      label: 'Password',
      visible: true,
    },
    { name: 'actions', label: 'Actions', visible: true },
  ];




  editRowId: number | null = null;

  editRow(rowId: number) {
    this.editRowId = rowId;
  }

  isRowEditing(rowId: any) {
    return this.editRowId === rowId;
  }






  async saveRow(row: any) {
    this.editRowId = null;
    try {
      const resp = await this.Apicontroller.updateDoctors('common', row);
      console.log('doctors update data:', resp);
       if (resp.status === 0) {
        this._snackBar.open(resp.msg, '', {
          duration: 6000,
          verticalPosition: 'top',
          horizontalPosition: 'center',
        });
      } else {
        this._snackBar.open(resp.msg, '', {
          duration:6000,
          verticalPosition: 'top',
          horizontalPosition: 'center',
        });
      }
    } catch (error) {
      console.error('Error updating doctors:', error);
    }
  }

  cancelEdit() {
    this.editRowId = null;
  }


















  page: number = 1; // Default to first page

  async mydoctor() {
    console.log("mydoctor");
  
    try {
      const resp = await this.Apicontroller.fetchdoctor('common', this.page);
      console.log("doctor", resp);
  
      const data = resp.data as Doctor[];
  
      // Add sr_no for each row (based on pagination if needed)
      this.doctor.data = data.map((item, index) => ({
        ...item,
        sr_no: index + 1 + this.doctor.paginator.pageIndex * this.doctor.paginator.pageSize
      }));
  
      // Enable sorting for custom fields like user_row_id (extract numeric part)
      this.doctor.sortingDataAccessor = (item, property) => {
        if (property === 'user_row_id') {
          return Number(item.user_row_id?.split('_')[0]); // numeric part
        }
        return item[property];
      };
    } catch (error) {
      console.error("Error fetching doctors:", error);
    }
  }


  viewDoctorDetails(doctor_rowId: string) {
    console.log("viewdata", doctor_rowId)
    this.router.navigate(['researchersDetails', doctor_rowId]);
  }


  filterByQuery(query: string): void {
    const trimmedQuery = query.trim().toLowerCase();

    if (trimmedQuery) {
      this.isSearchActive = true;
      this.doctor.filter = trimmedQuery;

      if (this.doctor.paginator) {
        this.doctor.paginator.firstPage(); // Reset to first page after search
      }
    } else {
      this.isSearchActive = false;
      this.doctor.filter = ''; // Clear filter

      // Reset the paginator and restore original data
      setTimeout(() => {
        this.doctor.paginator = this.paginator;
      });
    }
  }

  exportToExcel(): void {
    const dataToExport = this.doctor.data.map((doctor) => ({
      First_Name: doctor.firstname,
      Last_Name: doctor.lastname,
      Email: doctor.doctor_email,
      Gender: doctor.doctor_gender,
      Phone: doctor.user_contact_number,
      Institution: doctor.institution,
      Password: doctor.user_password,

    }));

    const worksheet = XLSX.utils.json_to_sheet(dataToExport);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Doctors');

    const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    const data = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });

    saveAs(data, 'Doctors_List.xlsx');
  }


  refresh() {
    console.log("refresh----")
    this.mydoctor();
    // window.location.reload();
  }


  visibilitybtn() {
    console.log("visibilitybtn .....")
  }

  deletebtn(patient: any) {

    console.log("doctor --------->", patient)
    const dialogRef = this._matDialog.open(DeldialogComponent, { data: { patient: patient }, });
    // dialogRef.afterClosed().subscribe((result) => {
    //     console.log('dialog was closed!');
    // });

    // dialogRef.afterClosed().subscribe((result: any) => {
    //   console.log("res----------------->", result)
    //   if (result) {
    //     this.mydoctor();

    //   }
    // });

     dialogRef.afterClosed().subscribe((resp: any) => {
          console.log("res----------------->",resp)
            if (resp) {
               if (resp.status === 0) {
         this.mydoctor();

        this._snackBar.open(resp.msg, '', {
          duration: 6000,
          verticalPosition: 'top',
          horizontalPosition: 'center',
        });
      } else {
        this._snackBar.open(resp.msg, '', {
          duration:6000,
          verticalPosition: 'top',
          horizontalPosition: 'center',
        });
      }
            }
        });
  }


  adddoctordialog() {
    const dialogRef = this._matDialog.open(AdddoctordialogComponent, {
      position: { right: '1%' },
      height: '100%',
      width: '600px'
    });

    dialogRef.afterClosed().subscribe((result: any | undefined) => {
      console.log("res", result)
      if (result) {

        this.mydoctor();

      }
    });
  }


  onProfileImageSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      const file = input.files[0];
      const formData = new FormData();
      formData.append('file', file);

      console.log(`upload file path  ${this.config}/common/upload`)
      this.http.post(`${this.config}/common/upload`, formData).subscribe({
        next: async (response: any) => {
          console.log("res", response)
          if (response) {
            this.filepath = response.data.foPa || response.data.filePath; // Ensure correct key name
            this.mediatype = response.data.mimetype;

            console.log('Uploaded File:', this.filepath, this.mediatype);


          } else {
            console.log("Invalid server response")

          }
        },
        error: (error) => {
          console.error('Upload failed:', error);
        },
      });

    }
  }

  async addresearchers(addResearchers:any) {

    if (this.signUpForm.invalid) {
      this.signUpForm.markAllAsTouched(); // Show validation messages
      return;
    }

    const data = {
      "doctor_fname": this.signUpForm.value.doctor_fname,
      "doctor_lname": this.signUpForm.value.doctor_lname,
      "doctor_email": this.signUpForm.value.doctor_email,
      "doctor_phone": this.signUpForm.value.doctor_phone,
      "doctor_password": this.signUpForm.value.doctor_password,
      // "doctor_type":this.signUpForm.value.doctor_type,
      "doctor_gender": this.signUpForm.value.doctor_gender,
      "institution": this.signUpForm.value.institution,
      "photo_path": this.filepath
    }

    console.log("data--->",data.doctor_email)

    const resp = await this.Apicontroller.createdoctor(data);

    if (resp.status === 0) {
      this._snackBar.open(resp.msg, '', {
        duration: 6000, // Duration in milliseconds (3 seconds)
        verticalPosition: 'top', // Position: 'top' | 'bottom'
        horizontalPosition: 'center', // Position: 'start' | 'center' | 'end' | 'left' | 'right'
      });


      this.signUpForm.reset()
      addResearchers.close()


      const email = data.doctor_email;

         console.log()

      console.log("patients email========", email)

      this.http
        .post(`${config.apiBaseURL}/common/auth/email`, {
          email,
        })
        .subscribe({
          next: (res: any) => {
            console.log("res---", res)


          },
          error: (err) => {
            console.log("err---", err)

          },
          complete: () => {
            console.log("rcompletees---",)

          },
        });
      // Close the dialog after successful doctor creation

      // Redirect to View Researchers

      this.mydoctor()
    } else {
      console.log("Error: ", resp.msg);
        this._snackBar.open(resp.msg, '', {
        duration: 6000, // Duration in milliseconds (3 seconds)
        verticalPosition: 'top', // Position: 'top' | 'bottom'
        horizontalPosition: 'center', // Position: 'start' | 'center' | 'end' | 'left' | 'right'
      });
    }
  }


    suspendPatient(patient: any) {
         // this._matDialog.open(SuspendPatientComponent, {
         //     data: { patient: patient },
         // });
 
         const dialogRef = this._matDialog.open(SuspendPatientComponent, {
             data: { patient: patient },
         });
 
 
        //   dialogRef.afterClosed().subscribe((result: any) => {
        //    console.log("res----------------->",result)
        //      if (result) {
                
        //      }
        //  });

             dialogRef.afterClosed().subscribe((resp: any) => {
          console.log("res----------------->",resp)
            if (resp) {
               if (resp.status === 0) {
         this.mydoctor();

        this._snackBar.open(resp.msg, '', {
          duration: 6000,
          verticalPosition: 'top',
          horizontalPosition: 'center',
        });
      } else {
        this._snackBar.open(resp.msg, '', {
          duration:6000,
          verticalPosition: 'top',
          horizontalPosition: 'center',
        });
      }
            }
        });
     }


}
