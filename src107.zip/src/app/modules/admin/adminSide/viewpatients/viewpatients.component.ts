import { Component, inject, ViewChild } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatDialog } from '@angular/material/dialog';
import { DeldialogComponent } from '../../dialog/deldialog/deldialog.component';
import { CommonModule, NgClass, NgStyle } from '@angular/common';
import { MatTooltipModule } from '@angular/material/tooltip';
import { CloumnShowdialogComponent } from '../../dialog/doctor/cloumn-showdialog/cloumn-showdialog.component';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { AddpatientdialogComponent } from '../../dialog/adminSide/addpatientdialog/addpatientdialog.component';
import { FuseDrawerComponent } from '@fuse/components/drawer';
import { FormsModule, ReactiveFormsModule, UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatStepperModule } from '@angular/material/stepper';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { HttpClient } from '@angular/common/http';
import { config } from '../../../../../../config';
import { MatSnackBar } from '@angular/material/snack-bar';

interface Patient {

  patient_age: string;
  patient_email: string;
  patient_gender: string;
  patient_name: string;
  patient_contact: string;
  doctor_name: string;
  doctor_type: string;
  doctor_email: string;
  doctor_gender: string;
  user_row_id: string;

}

interface Doctor {
  doctor_email: string;
  doctor_gender: string;
  firstname: string;
  lastname: string;
  user_contact_number: string;
  user_password: string;
  user_row_id: string;
  photo_path: string;
}

interface Column {
  name: string; // The column name/key (must match MatTable's columnDef)
  label: string; // The displayed label for checkbox and header
  visible: boolean; // Whether this column is currently shown
}

@Component({
  selector: 'app-viewpatients',
  imports: [
    MatTableModule, MatButtonModule,
    MatIconModule, MatInputModule, MatPaginatorModule, NgStyle, MatTooltipModule, CommonModule, MatSortModule,

    FuseDrawerComponent,
    ReactiveFormsModule, MatFormFieldModule,
    MatButtonModule, ReactiveFormsModule, MatFormFieldModule,
    MatInputModule, MatButtonModule, MatIconModule,
    MatProgressSpinnerModule, MatSelectModule, NgStyle,


    FormsModule,

    MatCheckboxModule,

    MatStepperModule,
  ],
  templateUrl: './viewpatients.component.html',
  styleUrl: './viewpatients.component.css'
})
export class ViewpatientsComponent {

  // patient: Patient[] = [];
  signUpForm: UntypedFormGroup;
  doctors: Doctor[];

  private _snackBar = inject(MatSnackBar);

  genders: string[] = ['Male', 'Female', 'Other'];
  passwordFieldType: 'password' | 'text' = 'password';

  get displayedColumns(): string[] {
    return this.columns.filter((c) => c.visible).map((c) => c.name);
  }


  role: any = '';

  isSearchActive = false;
  filepath: any;
  mediatype: any;
  userflag: boolean = false;
  wrongflag: boolean = false;
  config: any;

  userDeatials: Doctor = {
    doctor_email: '',
    doctor_gender: '',
    firstname: '',
    lastname: '',
    user_contact_number: '',
    user_password: '',
    user_row_id: '',
    photo_path: ''
  };

  patient = new MatTableDataSource<Patient>([]); // Use MatTableDataSource for pagination
  @ViewChild(MatSort) sort!: MatSort;


  @ViewChild(MatPaginator) paginator!: MatPaginator;
  profileImagePreview: any;

  


  constructor(
    private Apicontroller: ApicontrollerService,
    private router: Router,
    private _matDialog: MatDialog,
    private _formBuilder: UntypedFormBuilder,
    private http: HttpClient
  ) {

    this.config = config.apiBaseURL

    this.role = localStorage.getItem('role')
    this.userDeatials = JSON.parse(localStorage.getItem("userDeatials"));

    // console.log("my role",this.role)
  }

  ngOnInit(): void {
    this.Patients();
    this.mydoctor()

    this.signUpForm = this._formBuilder.group({
      patient_fname: ['', Validators.required],
      patient_lname: ['', Validators.required],
      patient_email: ['', [Validators.required, Validators.email]],
      patient_number: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
      patient_password: ['', Validators.required],
      patient_age: ['', [Validators.required,
      Validators.pattern(/^\d+$/),  // optional, just digits
      Validators.min(1),
      Validators.max(120)]
      ],
      patient_gender: ['', Validators.required],
      study_name: ['', Validators.required],
      study_arm: ['', Validators.required],
      doctor_id: ['', Validators.required],
      researcher_name: [this.userDeatials.firstname + ' ' + this.userDeatials.lastname, Validators.required],
      researcher_mobile: [this.userDeatials.user_contact_number, Validators.required],
      researcher_email: [this.userDeatials.doctor_email, Validators.required],

    });
  }

  ngAfterViewInit() {
    this.patient.paginator = this.paginator; // Set paginator after view init
    this.patient.sort = this.sort; // Set paginator after view init

  }


  editRowId: number | null = null;

  editRow(rowId: number) {
    this.editRowId = rowId;
  }

  isRowEditing(rowId: any) {
    return this.editRowId === rowId;
  }






  async saveRow(row: any) {
    this.editRowId = null;
    try {
      const resp = await this.Apicontroller.updatePatients('common', row);
      console.log('Patients update data:', resp);
    } catch (error) {
      console.error('Error updating patients:', error);
    }
  }

  cancelEdit() {
    this.editRowId = null;
  }












  page: number = 1; // Default to first page
  async Patients() {
    try {
      const resp = await this.Apicontroller.fetchPatientsByAdmin('common', this.page);
      console.log("Patients---", resp);
      this.patient.data = resp.data as Patient[]; // Type assert to Doctor[]
    } catch (error) {
      console.error("Error fetching doctors:", error);
    }

  }






  filterByQuery(query: string): void {
    const trimmedQuery = query.trim().toLowerCase();

    if (trimmedQuery) {
      this.isSearchActive = true;
      this.patient.filter = trimmedQuery;

      if (this.patient.paginator) {
        this.patient.paginator.firstPage(); // Reset to first page after search
      }
    } else {
      this.isSearchActive = false;
      this.patient.filter = ''; // Clear filter

      // Reset the paginator and restore original data
      setTimeout(() => {
        this.patient.paginator = this.paginator;
      });
    }
  }

  exportToExcel(): void {
    const dataToExport = this.patient.data.map((patient) => ({
      // ID: patient.user_row_id,
      Name: patient.patient_name,
      Email: patient.patient_email,
      Gender: patient.patient_gender,
      Contact: patient.patient_contact,
    }));

    const worksheet = XLSX.utils.json_to_sheet(dataToExport);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Doctors');

    const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    const data = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });

    saveAs(data, 'Patients_List.xlsx');
  }


  refresh() {
    console.log("refresh----")
    this.Patients();
    // window.location.reload();
  }

  addpatientdialog() {
    const dialogRef = this._matDialog.open(AddpatientdialogComponent,
      {
        position: { right: '1%' },
        height: '100%',
        width: '600px'
      });
  }



  deletebtn(patient: any) {

    console.log("user id=============", patient)

    const dialogRef = this._matDialog.open(DeldialogComponent, {
      data: { patient: patient },
    });

    dialogRef.afterClosed().subscribe((result: any) => {
      console.log("res----------------->", result)
      if (result) {
        this.Patients();

      }
    });
  }


  viewpatientDetails(patient_rowId: string) {
    console.log("viewdata", patient_rowId)
    // this.router.navigate(['patientDetails', patient_rowId]);
    this.router.navigate(['patientpanel', patient_rowId]);


  }



  columns: Column[] = [
    { name: 'user_row_id', label: 'Sr.no', visible: true },
    { name: 'patient_firstname', label: 'First Name', visible: true },
    { name: 'patient_lastname', label: 'Last Name', visible: true },

    { name: 'patient_email', label: 'Email', visible: true },
    { name: 'user_contact_number', label: 'Number', visible: true },
    { name: 'patient_age', label: 'Age', visible: true },
    { name: 'qualifications', label: 'Qualifications', visible: true },
    {
      name: 'qualifications_details',
      label: 'Qualification Details',
      visible: true,
    },
    { name: 'actions', label: 'Actions', visible: true },
  ];

  cloumnshow() {
    const dialogRef = this._matDialog.open(CloumnShowdialogComponent, {
      position: { right: '1%' },
      data: { columns: this.columns },
      height: '100%',
      width: '600px'
    });

    dialogRef.afterClosed().subscribe((result: Column[] | undefined) => {
      console.log("res", result)
      if (result) {
        // Update visibility based on dialog result
        result.forEach((colFromDialog) => {
          const col = this.columns.find(
            (c) => c.name === colFromDialog.name
          );
          if (col) {
            col.visible = colFromDialog.visible;
          }
        });
        // The getter will recalc displayedColumns automatically
      }
    });
  }

  togglePasswordVisibility() {
    this.passwordFieldType =
      this.passwordFieldType === 'password' ? 'text' : 'password';
  }

  async finish(stepper: any) {
    stepper.reset();


    this.signUpForm.reset();





    this.ngOnInit()

    this.wrongflag = false;
    this.userflag = false;

    console.log("this.signUpForm.value.researcher_name ", this.signUpForm.value.researcher_name)






  }


  async create() {
    console.log("hello")


    const data = {
      "doctor_id": this.signUpForm.value.doctor_id,
      "patient_fname": this.signUpForm.value.patient_fname,
      "patient_lname": this.signUpForm.value.patient_lname,
      "patient_email": this.signUpForm.value.patient_email,
      "patient_number": this.signUpForm.value.patient_number,
      "patient_password": this.signUpForm.value.patient_password,
      // "doctor_type":this.signUpForm.value.doctor_type,
      "patient_age": this.signUpForm.value.patient_age,
      "patient_gender": this.signUpForm.value.patient_gender,
      "study_name": this.signUpForm.value.study_name,
      // "doctor_type":this.signUpForm.value.doctor_type,
      "study_arm": this.signUpForm.value.study_arm,
      "researcher_name": this.signUpForm.value.researcher_name,
      "researcher_mobile": this.signUpForm.value.researcher_mobile,
      "researcher_email": this.signUpForm.value.researcher_email,

      "photo_path": this.filepath
    }

    const resp = await this.Apicontroller.AddPatients(
      data
    );




    if (resp.status === 0) {

      this.userflag = true;

      this._snackBar.open(resp.msg, '', {
        duration: 3000, // Duration in milliseconds (3 seconds)
        verticalPosition: 'top', // Position: 'top' | 'bottom'
        horizontalPosition: 'center', // Position: 'start' | 'center' | 'end' | 'left' | 'right'
      });


      const email = this.signUpForm.value.patient_email;
      const doc_email = this.signUpForm.value.researcher_email;



      console.log("patients email========", email)

      this.http
        .post(`${config.apiBaseURL}/common/auth/email`, {
          email,
        })
        .subscribe({
          next: (res: any) => {
            console.log("res---", res)


          },
          error: (err) => {
            console.log("err---", err)

          },
          complete: () => {
            console.log("rcompletees---",)

          },
        });


      this.http
        .post(`${config.apiBaseURL}/common/auth/email`, {
          email: doc_email,
        })
        .subscribe({
          next: (res: any) => {
            console.log("res---", res)


          },
          error: (err) => {
            console.log("err---", err)

          },
          complete: () => {
            console.log("rcompletees---",)

          },
        });



    } else {

      this.wrongflag = true

      this._snackBar.open(resp.msg, '', {
        duration: 3000, // Duration in milliseconds (3 seconds)
        verticalPosition: 'top', // Position: 'top' | 'bottom'
        horizontalPosition: 'center', // Position: 'start' | 'center' | 'end' | 'left' | 'right'
      });
    }




  }

  async addPatient() {
    // if (this.signUpForm.invalid) {
    //     this.signUpForm.markAllAsTouched();
    //     return;
    // }

    // const resp = await this.Apicontroller.AddPatients(
    //     this.signUpForm.value
    // );


  }

  onProfileImageSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      const file = input.files[0];
      const formData = new FormData();
      formData.append('file', file);

      console.log(`upload file path  ${this.config}/common/upload`)
      this.http.post(`${this.config}/common/upload`, formData).subscribe({
        next: async (response: any) => {
          console.log("res", response)
          if (response) {
            this.filepath = response.data.foPa || response.data.filePath; // Ensure correct key name
            this.mediatype = response.data.mimetype;

            console.log('Uploaded File:', this.filepath, this.mediatype);


          } else {
            console.log("Invalid server response")

          }
        },
        error: (error) => {
          console.error('Upload failed:', error);
        },
      });

    }
  }

  selectedValue: string = '';
  researcher_mobile: string = ''
  researcher_email: string = ''

  async onSelectionChange(event: Event) {
    // this.selectedValue = (event.target as HTMLSelectElement).value;
    console.log('Selected value:---------', this.selectedValue);

    const resp = await this.Apicontroller.fetchdoctordetails('common', this.selectedValue);
    console.log("resp", resp)
    console.log("resp", resp.data[0].user_contact_number)
    this.researcher_mobile = resp.data[0].user_contact_number;
    // doctor_email
    this.researcher_email = resp.data[0].doctor_email;

    console.log("data", this.researcher_email, this.researcher_mobile)


  }


  async mydoctor() {
    console.log(" mydoctor")

    try {
      const resp = await this.Apicontroller.fetchdoctor('common', this.page);
      console.log("doctor", resp);
      this.doctors = resp.data as Doctor[]; // Type assert to Doctor[]
      console.log("doctors", this.doctors);



    } catch (error) {
      // console.error("Error fetching doctors:", error);
    }

  }

}
