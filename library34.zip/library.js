const connect_db = require("./connect_db/db_connect.js");
const libFunc = require("./functions.js");
const queries = require("./connect_db/queries.js");
const jwt = require("./authentication/auth_config");
const query = require("./connect_db/queries.js");

module.exports = function () {
  this.common_fn = common_fn;
};

let common_fn = {
  // Registration
  cr_ad: createAdmin,

  si_up_doc: signUpDoctor,
  si_up_pat: signUpPatient,
  lo_us: loginUser,
  up_doc: updateDoctor,
  up_pat: updatePatient,

  // lo_pat: loginPatient,

  fe_docs: fetchDoctors,

  fe_pats: fetchPatients,
  fe_pats_by_ad: fetchPatientsByAdmin,

  req_apt: requestAppointment,
  // acc_apt_req
  cr_apt: createAppointment,
  up_apt: updateAppointment,
  fe_apt_pats: fetchAppointmentsForPatients,
  fe_apt_docs: fetchAppointmentsForDoctors,
  up_media: uploadMediaFiles,
  fe_media: fetchMedia,

  // forms builder
  cr_forms: saveforms,
  up_forms: updateforms,
  load_forms: loadforms,
  load_allForms: loadallforms,
  cr_for_ta: crateFormTable,
  sa_forms_data: saveforms_data,
  show_forms_res: showFormsResponse,
  show_forms_res_count: showFormsResponseCount,

  // fetch media
  fe_media_of_user: fetchmediametadatafouser,

  // delete
  del_doc: deletedoctor,
  del_pat: softDeleteOrStatusChangePatients,

  edit_user: editUserProfile,
};

// DB TABLES
const schema = "config";
const usersTable = schema + ".t_users";
const doctorsTable = schema + ".t_doctors";
const patientsTable = schema + ".t_patients";
const appointmentTable = schema + ".t_appointments";
const mediaTable = schema + ".t_media";
const formsSchemaTable = schema + ".t_forms";

function encodeRespData(data) {
  return btoa(encodeURIComponent(JSON.stringify(data)));
}

async function createAdmin(req, res) {
  try {
    const { phone, password, name, email } = req.data;
    const columns = [
      {
        row_id: libFunc.randomid(),
        user_contact_number: phone,
        user_password: password,
        user_type: 0,
      },
    ];
    const returnField = "row_id";
    const resp = await queries.insertQuery(usersTable, columns, returnField);
    console.log(resp);
    if (resp.length > 0) {
      res.status(201).send(encodeRespData({ msg: "Admin Created" }));
    } else {
      res.status(500).send(encodeRespData({ msg: "Something went wrong" }));
    }
  } catch (error) {
    console.log(error);
    res.status(500).send(encodeRespData({ msg: "Something went wrong" }));
  }
}

// Doctors Registration
async function signUpDoctor(req, res) {
  try {
    console.log("user id from token===>", req.user_id);
    const user_row_id = req.user_id;
    const {
      doctor_name,
      doctor_email,
      doctor_phone,
      doctor_password,
      doctor_type,
      doctor_gender,
    } = req.data;
    if (doctor_name && doctor_password) {
      // Check user authority
      const checkAuthorityColumn = ["user_type"];
      const checkAuthorityClause = `row_id = '${user_row_id}'`;
      const checkAuthorityResp = await queries.selectQuery(
        usersTable,
        checkAuthorityColumn,
        checkAuthorityClause
      );
      console.log(checkAuthorityResp);
      if (checkAuthorityResp.length > 0) {
        if (checkAuthorityResp[0].user_type == 0) {
          await connect_db.query("BEGIN TRANSACTION");
          const userTableColumns = [
            {
              row_id: libFunc.randomid(),
              user_contact_number: doctor_phone,
              user_password: doctor_password,
              user_type: 1,
            },
          ];
          const usersTableReturnField = "row_id";
          const userTableResp = await queries.insertQuery(
            usersTable,
            userTableColumns,
            usersTableReturnField
          );
          console.log(userTableResp);
          if (userTableResp.length > 0) {
            const columns = [
              {
                row_id: libFunc.randomid(),
                user_row_id: userTableResp[0].row_id,
                doctor_name,
                doctor_email,
                doctor_type,
                doctor_gender,
              },
            ];

            const returnFields = "row_id";
            const resp = await queries.insertQuery(
              doctorsTable,
              columns,
              returnFields
            );
            console.log(resp);
            if (resp.length > 0) {
              await connect_db.query("COMMIT");
              res
                .status(201)
                .send(
                  encodeRespData({ msg: "Registration successful", status: 0 })
                );
            } else {
              await connect_db.query("ROLLBACK");
              res
                .status(500)
                .send(
                  encodeRespData({ msg: "Something went wrong", status: 1 })
                );
            }
          } else {
            await connect_db.query("ROLLBACK");
            res
              .status(500)
              .send(encodeRespData({ msg: "Something went wrong", status: 1 }));
          }
        } else {
          await connect_db.query("ROLLBACK");
          res.status(403).send(
            encodeRespData({
              msg: "You don't have access for this request",
              status: 1,
            })
          );
        }
      }
    } else {
      await connect_db.query("ROLLBACK");
      res.status(403).send(
        encodeRespData({
          msg: "Please fill all the required fields",
          status: 1,
        })
      );
    }
  } catch (error) {
    await connect_db.query("ROLLBACK");
    console.log(error);
    res
      .status(500)
      .send(encodeRespData({ msg: "Something went wrong", status: 2 }));
  }
}

// Patients Registration
async function signUpPatient(req, res) {
  try {
    console.log("user data===>", req.data);
    const user_row_id = req.user_id;
    const {
      patient_name,
      patient_email,
      patient_number,
      patient_password,
      patient_gender,
      patient_age,
      qualifications,
      qualifications_details,
    } = req.data;
    if (user_row_id && patient_name && patient_password) {
      const checkAuthorityColumn = ["user_type"];
      const checkAuthorityClause = `row_id = '${user_row_id}'`;
      const checkAuthorityResp = await queries.selectQuery(
        usersTable,
        checkAuthorityColumn,
        checkAuthorityClause
      );
      console.log(checkAuthorityResp);
      if (checkAuthorityResp.length > 0) {
        // console.log("auth...",checkAuthorityResp[0].user_type)
        if (
          checkAuthorityResp[0].user_type == 1 ||
          checkAuthorityResp[0].user_type == 0
        ) {
          await connect_db.query("BEGIN TRANSACTION");
          const userTableColumns = [
            {
              row_id: libFunc.randomid(),
              user_contact_number: patient_number,
              user_password: patient_password,
              user_type: 2,
            },
          ];
          const usersTableReturnField = "row_id";
          const onConflict = {
            field: "user_contact_number",
            action: "DO NOTHING",
          };
          const userTableResp = await queries.insertQuery(
            usersTable,
            userTableColumns,
            usersTableReturnField,
            onConflict
          );
          console.log(userTableResp);
          if (userTableResp.length > 0) {
            let columns = [];

            if (checkAuthorityResp[0].user_type == 1) {
              columns = [
                {
                  row_id: libFunc.randomid(),
                  user_row_id: userTableResp[0].row_id,
                  doc_row_id: user_row_id,
                  patient_name,
                  patient_email,
                  patient_gender,
                  patient_age,
                  qualifications,
                  qualifications_details,
                },
              ];
            } else {
              columns = [
                {
                  row_id: libFunc.randomid(),
                  user_row_id: userTableResp[0].row_id,
                  doc_row_id: req.data.doctor_id,
                  patient_name,
                  patient_email,
                  patient_gender,
                  patient_age,
                  admin_row_id: user_row_id,
                },
              ];
            }

            const returnFields = "row_id";
            const resp = await queries.insertQuery(
              patientsTable,
              columns,
              returnFields
            );
            console.log(resp);
            if (resp.length > 0) {
              await connect_db.query("COMMIT");
              res
                .status(201)
                .send(
                  encodeRespData({ msg: "Registration successful", status: 0 })
                );
            } else {
              await connect_db.query("ROLLBACK");
              res
                .status(500)
                .send(
                  encodeRespData({ msg: "Something went wrong", status: 1 })
                );
            }
          } else {
            await connect_db.query("ROLLBACK");
            console.log("User exist====>");
            res.status(500).send(
              encodeRespData({
                msg: "User with this number already exist",
                status: 1,
              })
            );
          }
        } else {
          await connect_db.query("ROLLBACK");
          res.status(403).send(
            encodeRespData({
              msg: "You don't have access for this request",
              status: 1,
            })
          );
        }
      } else {
      }
    } else {
      await connect_db.query("ROLLBACK");
      res.status(403).send(
        encodeRespData({
          msg: "Please fill all the required fields",
          status: 1,
        })
      );
    }
  } catch (error) {
    await connect_db.query("ROLLBACK");

    console.log(error);
    res.status(500).send(
      encodeRespData({
        msg: "User with this contact already exist",
        status: 2,
      })
    );
  }
}

// User Login
async function loginUser(req, res) {
  try {
    const { phone, password } = req.data;
    if (phone && password) {
      const columns = ["row_id", "user_password", "user_type"];
      const clause = `user_contact_number = '${phone}' AND deleted=0 AND active=0`;
      const resp = await queries.selectQuery(usersTable, columns, clause);
      console.log("Login resp===>", resp);
      if (resp.length > 0) {
        let user_details = "";
        // if(resp[0].user_type == "0"){

        // }
        if (resp[0].user_type == "1" || resp[0].user_type == "0") {
          const doc_columns = [
            `${usersTable}.row_id`,
            "doctor_name",
            "doctor_email",
            "user_contact_number",
            "doctor_gender",
          ];

          const doc_clause = `${usersTable}.row_id = '${resp[0].row_id}'`;
          const joins = [
            {
              join_type: "left",
              table1: usersTable,
              table2: doctorsTable,
              table1_col: "row_id",
              table2_col: "user_row_id",
            },
          ];
          const doc_resp = await queries.selectQuery(
            usersTable,
            doc_columns,
            doc_clause,
            joins
          );
          console.log("doc_resp===>", doc_resp);
          user_details = doc_resp[0];
        }

        if (resp[0].user_type == "2") {
          const pat_columns = [
            `${usersTable}.row_id`,
            "patient_name",
            "patient_email",
            "user_contact_number",
            "patient_gender",
            "patient_age",
          ];

          const pat_clause = `${usersTable}.row_id = '${resp[0].row_id}'`;
          const joins = [
            {
              join_type: "left",
              table1: usersTable,
              table2: patientsTable,
              table1_col: "row_id",
              table2_col: "user_row_id",
            },
          ];
          const pat_resp = await queries.selectQuery(
            usersTable,
            pat_columns,
            pat_clause,
            joins
          );
          console.log("pat_resp===>", pat_resp);
          user_details = pat_resp[0];
        }

        if (password.trim() === resp[0].user_password) {
          const token = jwt.generateToken(
            { row_id: resp[0].row_id, user_type: resp[0].user_type },
            "5d"
          );

          console.log("sfa--------------")

            // ✅ Update last login timestamp
  if (resp[0].user_type === "0" || resp[0].user_type === "1") {
    console.log("hjvhgkj------------")
    await queries.updateQuery(
      doctorsTable,
      { last_login_on: new Date() },
      `user_row_id = '${resp[0].row_id}'`
    );
  } else if (resp[0].user_type === "2") {
    await queries.updateQuery(
      patientsTable,
      { last_login_on: new Date() },
      `user_row_id = '${resp[0].row_id}'`
    );
  }


          res.status(200).send(
            encodeRespData({
              msg: "Login successfull",
              token,
              user_type: resp[0].user_type,
              user_details,
              status: 0,
            })
          );
        } else {
          res
            .status(404)
            .send(encodeRespData({ msg: "Invalid credentials", status: 1 }));
        }
      } else {
        res
          .status(404)
          .send(encodeRespData({ msg: "Invalid credentials", status: 1 }));
      }
    } else {
      res.status(403).send(
        encodeRespData({
          msg: "Please fill all the required fields",
          status: 1,
        })
      );
    }
  } catch (error) {
    console.log(error);
    res
      .status(500)
      .send(encodeRespData({ msg: "Something went wrong", status: 2 }));
  }
}

async function updateDoctor(req, res) {
  try {
    console.log("user id from token===>", req.user_id);
    const user_row_id = req.user_id;
    const {
      doc_row_id,
      doctor_name,
      doctor_email,
      doctor_phone,
      doctor_password,
      doctor_gender,
    } = req.data;
    if (doctor_name && doctor_password) {
      // Check user authority
      const checkAuthorityColumn = ["user_type"];
      const checkAuthorityClause = `row_id = '${user_row_id}'`;
      const checkAuthorityResp = await queries.selectQuery(
        usersTable,
        checkAuthorityColumn,
        checkAuthorityClause
      );
      console.log(checkAuthorityResp);
      if (checkAuthorityResp.length > 0) {
        if (checkAuthorityResp[0].user_type == 0) {
          await connect_db.query("BEGIN TRANSACTION");
          const userTableColumns = {
            user_contact_number: doctor_phone,
            user_password: doctor_password,
            user_type: 1,
          };
          const usersTableClaue = `row_id = '${doc_row_id}'`;
          const userTableResp = await queries.updateQuery(
            usersTable,
            userTableColumns,
            usersTableClaue
          );
          console.log(userTableResp);
          if (userTableResp > 0) {
            const columns = {
              doctor_name,
              doctor_email,
              doctor_type,
              doctor_gender,
            };

            const clause = `user_row_id = '${doc_row_id}'`;
            const resp = await queries.updateQuery(
              doctorsTable,
              columns,
              clause
            );
            console.log(resp);
            if (resp > 0) {
              await connect_db.query("COMMIT");
              res
                .status(201)
                .send(
                  encodeRespData({ msg: "Doctor details updated", status: 0 })
                );
            } else {
              await connect_db.query("ROLLBACK");
              res
                .status(500)
                .send(
                  encodeRespData({ msg: "Something went wrong", status: 1 })
                );
            }
          } else {
            await connect_db.query("ROLLBACK");
            res
              .status(500)
              .send(encodeRespData({ msg: "Something went wrong", status: 1 }));
          }
        } else {
          await connect_db.query("ROLLBACK");
          res.status(403).send(
            encodeRespData({
              msg: "You don't have access for this request",
              status: 1,
            })
          );
        }
      }
    } else {
      await connect_db.query("ROLLBACK");
      res.status(403).send(
        encodeRespData({
          msg: "Please fill all the required fields",
          status: 1,
        })
      );
    }
  } catch (error) {
    console.log(error);
    res
      .status(500)
      .send(encodeRespData({ msg: "Something went wrong", status: 2 }));
  }
}

async function updatePatient(req, res) {
  try {
    console.log("user id from token===>", req.user_id);
    const Tokenuser_row_id = req.user_id;
    const {
      patient_email,
      patient_name,
      user_contact_number,
      user_password,
      patient_gender,
      patient_age,
      user_row_id,
    } = req.data;

    console.log("pat id", req.data);

    // console.log("res-->",req.data)
    // console.log("insde ")
    // Check user authority
    const checkAuthorityColumn = ["user_type"];
    const checkAuthorityClause = `row_id = '${Tokenuser_row_id}'`;
    const checkAuthorityResp = await queries.selectQuery(
      usersTable,
      checkAuthorityColumn,
      checkAuthorityClause
    );
    console.log("checkAuthorityResp", checkAuthorityResp);
    if (checkAuthorityResp.length > 0) {
      if (checkAuthorityResp[0].user_type == 1) {
        await connect_db.query("BEGIN TRANSACTION");
        const userTableColumns = {
          user_contact_number: user_contact_number,
          user_password: user_password,
        };
        const usersTableClaue = `row_id = '${user_row_id}'`;
        const userTableResp = await queries.updateQuery(
          usersTable,
          userTableColumns,
          usersTableClaue
        );
        // console.log("userTableRespo",userTableResp);

        if (userTableResp > 0) {
          const columns = {
            patient_name,
            patient_email,
            patient_gender,
            patient_age,
          };

          const clause = `user_row_id = '${user_row_id}'`;
          const resp = await queries.updateQuery(
            patientsTable,
            columns,
            clause
          );
          // console.log("resp-->567",resp);
          // console.log("resp-->1234",resp > 0);

          if (resp > 0) {
            await connect_db.query("COMMIT");
            res
              .status(201)
              .send(
                encodeRespData({ msg: "Patients details updated", status: 0 })
              );
          } else {
            await connect_db.query("ROLLBACK");
            res
              .status(500)
              .send(encodeRespData({ msg: "Something went wrong", status: 1 }));
          }
        } else {
          await connect_db.query("ROLLBACK");
          res
            .status(500)
            .send(encodeRespData({ msg: "Something went wrong", status: 1 }));
        }
      } else {
        await connect_db.query("ROLLBACK");
        res.status(403).send(
          encodeRespData({
            msg: "You don't have access for this request",
            status: 1,
          })
        );
      }
    }
  } catch (error) {
    console.log(error);
    res
      .status(500)
      .send(encodeRespData({ msg: "Something went wrong", status: 2 }));
  }
}

async function fetchDoctors(req, res) {
  try {
    const { row_id = null, doc_name = null, limit = 30, page = 1 } = req.data;
    const columns = [
      `${usersTable}.row_id AS user_row_id`,
      `${usersTable}.user_contact_number`,
      `${usersTable}.user_password`,
      "doctor_name",
      "doctor_email",
      "doctor_gender",
    ];

    let del = 0;
    let clause = `config.t_doctors.deleted = ${del}`;
    if (row_id) {
      clause = `${usersTable}.row_id = '${row_id}'`;
    }

    if (doc_name) {
      if (clause) {
        clause += ` AND doctor_name ILIKE '%${doc_name}%'`;
      } else {
        clause = `doctor_name ILIKE '%${doc_name}%'`;
      }
    }

    const joins = [
      {
        join_type: "right",
        table1: usersTable,
        table2: doctorsTable,
        table1_col: "row_id",
        table2_col: "user_row_id",
      },
    ];

    const offset = (page - 1) * limit;

    const orderBy = "doctor_name";

    const resp = await queries.selectQuery(
      usersTable,
      columns,
      clause,
      joins,
      orderBy,
      offset,
      // null,
      limit
    );
    console.log("Doctors===>", resp);
    if (resp.length > 0) {
      res
        .status(200)
        .send(
          encodeRespData({ msg: "All doctors Fetched", data: resp, status: 0 })
        );
    } else {
      res
        .status(203)
        .send(encodeRespData({ msg: "There are no doctors.", status: 0 }));
    }
  } catch (error) {
    console.log("Fetch Doctors Error===>", error);
    res
      .status(500)
      .send(encodeRespData({ msg: "Something went wrong", status: 2 }));
  }
}

async function fetchPatients(req, res) {
  try {
    const doc_row_id = req.user_id;
    console.log("doc_row_id===>", doc_row_id);
    const {
      row_id = null,
      name = null,
      limit = 10,
      page = 1,
      showDeleted = 0,
    } = req.data;
    const columns = [
      `${usersTable}.row_id AS user_row_id`,
      `${usersTable}.user_contact_number`,
      `${usersTable}.user_password`,
      "patient_name",
      "patient_email",
      "patient_gender",
      "patient_age",
      "qualifications",
      "qualifications_details",
      "active",
    ];
    let clause = `doc_row_id = '${doc_row_id}'`;
    if (row_id) {
      clause += row_id ? ` AND ${usersTable}.row_id = '${row_id}'` : null;
    }
    if (name) {
      clause += ` AND patient_name ILIKE '%${name}%'`;
    }

    if (!showDeleted) {
      clause += `AND deleted = 0`;
    }

    const joins = [
      {
        join_type: "right",
        table1: usersTable,
        table2: patientsTable,
        table1_col: "row_id",
        table2_col: "user_row_id",
      },
    ];
    let offset = (page - 1) * 10;
    const resp = await queries.selectQuery(
      usersTable,
      columns,
      clause,
      joins,
      null,
      offset,
      limit
    );
    // console.log(resp);
    if (resp.length > 0) {
      res.status(200).send(
        encodeRespData({
          msg: "patients Data Fetched",
          data: resp,
          status: 0,
        })
      );
    } else {
      res
        .status(203)
        .send(encodeRespData({ msg: "There are no patiints.", status: 0 }));
    }
  } catch (error) {
    res
      .status(500)
      .send(encodeRespData({ msg: "Something went wrong", status: 2 }));
  }
}

async function fetchPatientsByAdmin(req, res) {
  try {
    const { user_id, user_type } = req; // Assuming middleware sets these
    const { row_id = null, name = null, limit = 10, page = 1 } = req.data;

    const offset = (page - 1) * limit;

    let sql = `
      SELECT
        pt.row_id as patient_row_id,
        pt.patient_name,
        pt.patient_email,
        pt.patient_gender,
        pt.patient_age,
        usr.user_contact_number as patient_contact,
        doc.doctor_name,
        doc.doctor_email,
        doc.doctor_gender,
        doc.doctor_type
      FROM config.t_patients pt
      INNER JOIN config.t_users usr ON pt.user_row_id = usr.row_id
      INNER JOIN config.t_doctors doc ON pt.doc_row_id = doc.user_row_id
      WHERE 1 = 1
    `;

    console.log("user type", user_type);
    // If not admin (user_type !== 1), restrict to doctor’s patients
    if (user_type === 1) {
      sql += ` AND pt.doc_row_id = '${user_id}'`;
    }

    // Optional filters
    // if (row_id) {
    //   sql += ` AND pt.row_id = '${row_id}'`;
    // }

    if (name) {
      sql += ` AND pt.patient_name ILIKE '%${name}%'`;
    }

    // Pagination
    sql += ` ORDER BY pt.cr_on DESC LIMIT ${limit} OFFSET ${offset}`;

    // Execute query (assuming pg client `db`)
    const result = await queries.customQuery(sql);

    // console.log("rsulut-----", result);

    if (result) {
      res.status(200).send(
        encodeRespData({
          msg: "Patients data fetched successfully",
          data: result,
          status: 0,
        })
      );
    } else {
      res
        .status(203)
        .send(encodeRespData({ msg: "No patients found", status: 0 }));
    }
  } catch (error) {
    console.error("fetchPatients error:", error);
    res
      .status(500)
      .send(encodeRespData({ msg: "Something went wrong", status: 2 }));
  }
}

async function requestAppointment(req, res) {
  try {
    const pat_row_id = req.user_id;
    const {
      time_of_apt,
      date_of_apt,
      appt_type,
      virtual_link = null,
      updatedby_row_id,
    } = req.data;

    const docRowIdColumn = ["doc_row_id"];
    const docRowIdClause = `user_row_id = '${pat_row_id}'`;
    const docRowIdResp = await queries.selectQuery(
      patientsTable,
      docRowIdColumn,
      docRowIdClause
    );
    const doc_row_id = docRowIdResp[0].doc_row_id;
    console.log("doc_row_id===>", doc_row_id);

    const d = new Date();

    const date = ("0" + d.getDate()).slice(-2);
    const month = ("0" + (d.getMonth() + 1)).slice(-2);
    const year = d.getFullYear();
    const fullDate = `${date}/${month}/${year}`;

    let hour = d.getHours();
    let mins = ("0" + d.getMinutes()).slice(-2);
    const time = `${hour}:${mins}`;
    console.log(fullDate);
    console.log(time);

    const columns = [
      {
        row_id: libFunc.randomid(),
        doc_row_id,
        pat_row_id,
        date_of_req: fullDate,
        time_of_req: time,
        date_of_apt,
        time_of_apt,
        appointment_details: JSON.stringify({
          appt_type,
          virtual_link,
          appt_status: 0,
          updatedby_row_id: pat_row_id,
        }),
      },
    ];

    const returnField = "row_id";
    const resp = await queries.insertQuery(
      appointmentTable,
      columns,
      returnField
    );
    console.log(resp);
    if (resp.length > 0) {
      res.status(201).send(
        encodeRespData({
          msg: "Appoinment Request sent. Please wait for the request approval and date and time slot.",
          status: 0,
        })
      );
    } else {
      res.status(500).send(
        encodeRespData({
          msg: "Something went wrong",
          status: 1,
        })
      );
    }
  } catch (error) {
    console.log("APT Request Error===>", error);
    res.status(500).send(
      encodeRespData({
        msg: "Something went wrong",
        status: 2,
      })
    );
  }
}

async function createAppointment(req, res) {
  try {
    const doc_row_id = req.user_id;
    const {
      pat_row_id,
      time_of_apt,
      date_of_apt,
      appt_type,
      virtual_link = null,
      updatedby_row_id,
    } = req.data;

    const d = new Date();

    const date = ("0" + d.getDate()).slice(-2);
    const month = ("0" + (d.getMonth() + 1)).slice(-2);
    const year = d.getFullYear();
    const fullDate = `${year}-${month}-${date}`;

    let hour = d.getHours();
    let mins = ("0" + d.getMinutes()).slice(-2);
    const time = `${hour}:${mins}`;
    console.log(fullDate);
    console.log(time);

    const columns = [
      {
        row_id: libFunc.randomid(),
        pat_row_id,
        doc_row_id,
        time_of_req: time,
        date_of_req: fullDate,
        date_of_apt,
        time_of_apt,
        appointment_details: JSON.stringify({
          appt_type,
          virtual_link,
          appt_status: 0,
          updatedby_row_id: doc_row_id,
        }),
      },
    ];
    const returnField = "row_id";
    const resp = await queries.insertQuery(
      appointmentTable,
      columns,
      returnField
    );
    console.log("Appointment ===>", resp);
    if (resp.length > 0) {
      res
        .status(201)
        .send(encodeRespData({ msg: "Appointment scheduled", status: 0 }));
    } else {
      res
        .status(500)
        .send(encodeRespData({ msg: "Something went wrong", status: 1 }));
    }
  } catch (error) {
    console.log("Appointment error===>", error);
    res
      .status(500)
      .send(encodeRespData({ msg: "Something went wrong", status: 2 }));
  }
}

// async function updateAppointment(req, res) {
//   const updatedby_row_id = req.user_id;

//   try {
//     const {
//       row_id,
//       time = null,
//       date = null,
//       appointment_request_status = null,
//     } = req.data;
//     const columns = [];
//     if (time) {
//       columns.push(`time_for_apt = '${time}'`);
//     }
//     if (date) {
//       columns.push(`date_for_apt = '${date}'`);
//     }
//     if (appointment_request_status !== null) {
//       columns.push(
//         `appointment_details = appointment_details || '{"appt_status": ${appointment_request_status}}'`
//       ); //0: pending, 1: complete, 2: cancel
//     }
//     const clause = `row_id = '${row_id}'`;
//     // console.log("columns===>", columns);
//     // console.log("row_id", row_id);
//     // const resp = await queries.updateQuery(appointmentTable, columns, clause);
//     // console.log(resp);

//     let cols = columns.join(", ");
//     console.log(cols);

//     const query = `UPDATE ${appointmentTable} SET up_on = now(), ${cols}  WHERE ${clause}`;
//     console.log(query);
//     const resp = await connect_db.query(query);
//     console.log(resp.rowCount)
//     if (resp.rowCount > 0) {
//       res
//         .status(201)
//         .send(encodeRespData({ msg: "Appointment updated", status: 0 }));
//     } else {
//       res
//         .status(400)
//         .send(encodeRespData({ msg: "Something went wrong", status: 1 }));
//     }
//   } catch (error) {
//     res
//       .status(500)
//       .send(encodeRespData({ msg: "Something went wrong", status: 2 }));
//   }
// }

async function updateAppointment(req, res) {
  const updatedby_row_id = req.user_id;

  try {
    const {
      row_id,
      time = null,
      date = null,
      appointment_request_status = null,
    } = req.data;

    const columns = [];

    if (time) {
      columns.push(`time_for_apt = '${time}'`);
    }

    if (date) {
      columns.push(`date_for_apt = '${date}'`);
    }

    //1. Determine if updater is a doctor or patient
    let userType = null;
    let userName = null;

    const docQuery = `SELECT doctor_name FROM config.t_doctors WHERE user_row_id = '${updatedby_row_id}'`;
    const patQuery = `SELECT patient_name FROM config.t_patients WHERE user_row_id = '${updatedby_row_id}'`;

    const docRes = await connect_db.query(docQuery);
    const patRes = await connect_db.query(patQuery);

    if (docRes.rows.length > 0) {
      userType = "doctor";
      userName = docRes.rows[0].doctor_name;
    } else if (patRes.rows.length > 0) {
      userType = "patient";
      userName = patRes.rows[0].patient_name;
    } else {
      return res.status(404).send(
        encodeRespData({
          msg: "User not found in doctor or patient records",
          status: 3,
        })
      );
    }

    // 2. Add appointment_details update
    if (appointment_request_status !== null) {
      const detailsPatch = {
        appt_status: appointment_request_status,
        updatedby_row_id,
        updatedby_user_name: userName,
        updatedby_user_type: userType,
      };

      columns.push(
        `appointment_details = appointment_details || '${JSON.stringify(
          detailsPatch
        )}'`
      );
    }

    // 3. Build and execute query
    const clause = `row_id = '${row_id}'`;
    const cols = columns.join(", ");
    const query = `UPDATE config.t_appointments SET up_on = now(), ${cols} WHERE ${clause}`;

    console.log("Query:", query);
    const resp = await connect_db.query(query);

    if (resp.rowCount > 0) {
      res.status(201).send(
        encodeRespData({
          msg: "Appointment updated",
          status: 0,
        })
      );
    } else {
      res.status(400).send(
        encodeRespData({
          msg: "Update failed",
          status: 1,
        })
      );
    }
  } catch (error) {
    console.error("Error in updateAppointment:", error);
    res.status(500).send(
      encodeRespData({
        msg: "Something went wrong",
        status: 2,
      })
    );
  }
}

async function fetchAppointmentsForPatients(req, res) {
  try {
    const pat_row_id = req.user_id;
    console.log("YES");
    const columns = [
      `${appointmentTable}.row_id AS apt_row_id`,
      "doctor_name",
      `${usersTable}.user_contact_number`,
      "date_of_req",
      "time_of_req",
      "date_of_apt",
      "time_of_apt",
      "appointment_details",
    ];
    const clause = `${appointmentTable}.pat_row_id = '${pat_row_id}' AND appointment_details ->> 'appt_status' != '4'`;
    const join = [
      {
        join_type: "left",
        table1: appointmentTable,
        table2: doctorsTable,
        table1_col: "doc_row_id",
        table2_col: "user_row_id",
      },
      {
        join_type: "left",
        table1: appointmentTable,
        table2: usersTable,
        table1_col: "doc_row_id",
        table2_col: "row_id",
      },
    ];
    const orderBy = "date_of_req, time_of_req DESC";
    const resp = await queries.selectQuery(
      appointmentTable,
      columns,
      clause,
      join,
      orderBy
    );
    // console.log(resp);
    if (resp.length > 0) {
      res
        .status(200)
        .send(
          encodeRespData({ msg: "Appointments Fetched", data: resp, status: 0 })
        );
    } else {
      res
        .status(203)
        .send(encodeRespData({ msg: "No Appointments. Make one", status: 0 }));
    }
  } catch (error) {
    console.log("fetch patients appointments", error);
    res
      .status(500)
      .send(encodeRespData({ msg: "Something went wrong", status: 2 }));
  }
}

async function fetchAppointmentsForDoctors(req, res) {
  try {
    const doc_row_id = req.user_id;
    const { pat_row_id } = req.data;
    // console.log("YES Doctors");

    const columns = [
      `${appointmentTable}.row_id AS apt_row_id`,
      `${usersTable}.user_contact_number AS pat_cont_no`,
      "patient_name",
      "date_of_req",
      "time_of_req",
      "date_of_apt",
      "time_of_apt",
      "appointment_details",
    ];
    //  0: pending, 1: accept, 2: reject, 3: complete, 4: cancel, 5:reschedule
    let clause = `${appointmentTable}.doc_row_id = '${doc_row_id}' AND appointment_details ->> 'appt_status' != '4'`;
    if (pat_row_id) {
      clause += ` AND pat_row_id = '${pat_row_id}'`;
    }
    const join = [
      {
        join_type: "left",
        table1: appointmentTable,
        table2: patientsTable,
        table1_col: "pat_row_id",
        table2_col: "user_row_id",
      },
      {
        join_type: "left",
        table1: appointmentTable,
        table2: usersTable,
        table1_col: "pat_row_id",
        table2_col: "row_id",
      },
    ];
    const resp = await queries.selectQuery(
      appointmentTable,
      columns,
      clause,
      join
    );
    // console.log(resp);
    if (resp.length > 0) {
      res
        .status(200)
        .send(
          encodeRespData({ msg: "Appointments Fetched", data: resp, status: 0 })
        );
    } else {
      res
        .status(203)
        .send(encodeRespData({ msg: "No Appointments.", status: 0 }));
    }
  } catch (error) {
    console.log("fetch doctors appointments error", error);
    res
      .status(500)
      .send(encodeRespData({ msg: "Something went wrong", status: 2 }));
  }
}

async function fetchMedia(req, res) {
  try {
    // FOr doctors pat_row_id is mandatory but for patients row_id is being taken from token itself
    const user_row_id = req.user_id;
    const { pat_row_id = null, media_type } = req.data;
    // console.log(req.data);
    const user_type = await getUserType(user_row_id);
    console.log("user_type===>", user_type);
    const columns = [
      `${mediaTable}.row_id AS media_row_id`,
      "patient_name",
      "doctor_name",
      "date",
      "time",
      "media_name",
      "media_link",
      "media_type",
      "sender",
      "filename",
      "description",
      "filesize",
    ];
    let clause = `media_type = '${media_type}' AND status = '0'`;
    if (user_type == 1) {
      clause += ` AND ${mediaTable}.doc_row_id = '${user_row_id}'`;
      if (pat_row_id) {
        clause += ` AND pat_row_id = '${pat_row_id}'`;
      }
    } else if (user_type == 2) {
      clause += ` AND pat_row_id = '${user_row_id}'`;
    }
    const join = [
      {
        join_type: "left",
        table1: mediaTable,
        table2: patientsTable,
        table1_col: "pat_row_id",
        table2_col: "user_row_id",
      },

      {
        join_type: "left",
        table1: mediaTable,
        table2: doctorsTable,
        table1_col: "doc_row_id",
        table2_col: "user_row_id",
      },
    ];
    const resp = await queries.selectQuery(mediaTable, columns, clause, join);
    console.log(resp);
    if (resp.length > 0) {
      res
        .status(200)
        .send(encodeRespData({ msg: "Media Fetched", data: resp, status: 0 }));
    } else {
      res
        .status(203)
        .send(
          encodeRespData({ msg: "No Appointments.", data: resp, status: 0 })
        );
    }
  } catch (error) {
    console.log(error);
  }
}

async function uploadMediaFiles(req, res) {
  try {
    const sender = req.user_id;
    console.log("sender===>", sender);
    let {
      receiver_row_id = null,
      file_name,
      file_path,
      media_type,
      filename,
      description,
      filesize,
    } = req.data;
    console.log("req.data", req.data);
    const user_type = await getUserType(sender);
    console.log(user_type);
    const d = new Date();

    const date = ("0" + d.getDate()).slice(-2);
    const month = ("0" + (d.getMonth() + 1)).slice(-2);
    const year = d.getFullYear();
    const fullDate = `${year}-${month}-${date}`;

    let hour = d.getHours();
    let mins = ("0" + d.getMinutes()).slice(-2);
    const time = `${hour}:${mins}`;

    let receiverColumn;
    let receiverClause;
    let receiverResp;

    // if (senderResponse[0].user_type == 1) {
    //   receiverColumn = ["user_row_id"];
    //   receiverClause = `doc_row_id = '${sender}'`;
    //   receiverResp = await queries.selectQuery(
    //     patientsTable,
    //     receiverColumn,
    //     receiverClause
    //   );
    // } else
    if (user_type == 2) {
      receiverColumn = ["doc_row_id"];
      receiverClause = `user_row_id = '${sender}'`;
      receiverResp = await queries.selectQuery(
        patientsTable,
        receiverColumn,
        receiverClause
      );
      receiver_row_id = receiverResp[0].doc_row_id;
    }

    // const docColumn = ["doc_row_id"];
    // const docClause = `user_row_id = '${sender}'`;
    // const docResp = await queries.selectQuery(
    //   patientsTable,
    //   docColumn,
    //   docClause
    // );
    // console.log("Doc row id===>", docResp);

    const columns = [
      {
        row_id: libFunc.randomid(),
        pat_row_id: user_type == 2 ? sender : receiver_row_id,
        doc_row_id: user_type == 1 ? sender : receiver_row_id,
        time,
        date: fullDate,
        media_name: file_name,
        media_link: file_path,
        media_type,
        status: 0,
        sender,
        filename,
        description,
        filesize,
      },
    ];
    const returnField = "row_id";
    const resp = await queries.insertQuery(mediaTable, columns, returnField);
    console.log("media uploaded RESP====>", resp);
    if (resp.length > 0) {
      res
        .status(201)
        .send(encodeRespData({ msg: "Media uploaded", status: 0 }));
    } else {
      res
        .status(500)
        .send(encodeRespData({ msg: "Something went wrong", status: 1 }));
    }
  } catch (error) {
    console.log(error);
    res
      .status(500)
      .send(encodeRespData({ msg: "Something went wrong", status: 2 }));
  }
}

async function getUserType(row_id) {
  try {
    const columns = ["user_type"];
    const clause = `row_id = '${row_id}'`;
    const resp = await queries.selectQuery(usersTable, columns, clause);
    return resp[0].user_type;
  } catch (error) {}
}

// /uploads/videos/1730798151244_LONG DRIVE Bollywood Mix - Arijit Singh _ Full Album _ 2 Hour Nonstop _ Apna Bana Le, Zaalima & More.mp4
// /uploads/videos/1730798151244_SUNIYAN SUNIYAN (Official Video) Juss x MixSingh.mp3
// /uploads/videos/1730798151244_Numb (Official Music Video) [4K UPGRADE] – Linkin Park.mp3

// forms builder api

function saveforms(req, res) {
  var row_id = libFunc.randomid();
  var formsSchema = req.data;
  console.log("req", req);
  const column = {
    row_id: row_id,
    form_data: JSON.stringify(formsSchema),
  };
  //   console.log("cloumn data", column)

  var data = query.insertData(formsSchemaTable, column);

  const resp = {
    status: 0,
    msg: "forms sechema created successfully",
    data: data,
    row_id: row_id,
  };

  console.log("response", resp.data);
  libFunc.sendResponse(res, resp);
}

function updateforms(req, res) {
  const column = {
    tablename: req.data[0],
  };
  const cond = {
    row_id: req.data[1],
  };

  var data = query.updateData(formsSchemaTable, column, cond);

  const resp = {
    status: 0,
    msg: "Updated successfully",
    data: data,
  };

  // console.log("response", resp)
  libFunc.sendResponse(res, resp);
}

async function loadforms(req, res) {
  const cond = {
    tablename: req.data.row_id,
  };

  var resp = await query.fetchData(formsSchemaTable, cond);
  console.log("fetch res", resp);
  libFunc.sendResponse(res, resp);
}

async function loadallforms(req, res) {
  var resp = await query.fetchData(formsSchemaTable);
  console.log("fetch res", resp);
  libFunc.sendResponse(res, resp);
}

function crateFormTable(req, res) {
  var table_name = req.data;

  var data = [{ id: "form_data", fdtype: "jsonb", required: true }];

  var data = query.createTable(schema, table_name, data);

  const resp = {
    status: 0,
    msg: "table created successfully",
  };

  console.log("response", resp);
  libFunc.sendResponse(res, resp);
}

function saveforms_data(req, res) {
  var row_id = libFunc.randomid();
  var formsData = req.data[0];
  var sumb_info = schema + "." + req.data[1];
  var mediaData = req.data[2];

  console.log("sumb_info", sumb_info);
  console.log("formsdata", req.data[0]);

  console.log("req", req);

  const column = {
    row_id: row_id,
    form_data: JSON.stringify(formsData),
    others_details: JSON.stringify(mediaData),
  };

  var data = query.insertData(sumb_info, column);

  const resp = {
    status: 0,
    msg: "forms data saved successfully",
  };

  console.log("response", resp);
  libFunc.sendResponse(res, resp);
}

async function showFormsResponseCount(req, res) {
  console.log("request", req.data);
  const cond = {
    form_id: req.data.form_id,
  };

  var table_name = schema + "." + req.data.form_id;

  var resp = await query.count(table_name);
  console.log("fetch res -->", resp);
  libFunc.sendResponse(res, resp);
}

async function showFormsResponse(req, res) {
  console.log("request", req.data.row_id);
  // const cond = {
  //   form_id: req.data.form_id
  // }

  var table_name = schema + "." + req.data.form_id;

  var resp = await query.fetchData(table_name);
  console.log("fetch res -->", resp);
  libFunc.sendResponse(res, resp);
}

async function fetchmediametadatafouser(req, res) {
  console.log("req", req);
  const cond = {
    AND: {
      pat_row_id: req.data.pat_row_id.row_id,
      media_type: req.data.pat_row_id.media_type,
    },
  };

  var resp = await query.fetchData(mediaTable, cond);

  console.log("resp-->", resp);
  libFunc.sendResponse(res, resp);
}

async function deletedoctor(req, res) {
  console.log("req--->", req);

  const column = {
    deleted: req.data.delvalue.updatevalue,
  };
  const cond = {
    user_row_id: req.data.delvalue.doc_row_id,
  };

  var data = await query.updateData(doctorsTable, column, cond);

  const column1 = {
    deleted: req.data.delvalue.updatevalue,
  };
  const cond1 = {
    row_id: req.data.delvalue.doc_row_id,
  };

  var data = await query.updateData(usersTable, column1, cond1);

  const resp = {
    status: 0,
    msg: "deleted successfully",
    data: data,
  };

  // console.log("response", resp)
  libFunc.sendResponse(res, resp);
}

async function softDeleteOrStatusChangePatients(req, res) {
  try {
    const { row_id, deleted, active } = req.data.delvalue;

    console.log("backend side data req", req.data);

    // if (!row_id) {
    //   const resp = {
    //     status: 1,
    //     msg: "row_id is required",
    //   };

    //   // console.log("resp", resp);
    //   return libFunc.sendResponse(res, resp);
    // }

    const updateData = {
      up_on: new Date().toISOString(),
    };

    let messages = [];

    if (typeof deleted !== "undefined") {
      updateData.deleted = deleted;
      if (deleted) {
        messages.push("student soft-deleted successfully");
      } else {
        messages.push("student restored successfully");
      }
    }

    if (typeof active !== "undefined") {
      updateData.active = active;
      if (active) {
        messages.push("student deactivated successfully");
      } else {
        messages.push("student activated successfully");
      }
    }

    console.log("updatedata", updateData);

    if (Object.keys(updateData).length === 1) {
      const resp = {
        status: 1,
        msg: "Nothing to update. Provide deleted or active.",
      };

      // console.log("resp", resp);
      // Only up_on exists
      return libFunc.sendResponse(res, resp);
    }

    // Update branch
    await query.updateData(usersTable, updateData, { row_id: row_id });

    const response = {
      status: 0,
      msg: messages.join(" & "), // Join messages if both updated
    };

    // console.log("Response:", response);
    libFunc.sendResponse(res, response);
  } catch (error) {
    // console.error("Error updating student:", error);
    libFunc.sendResponse(res, {
      status: 1,
      msg: "An error occurred while Patients",
      error: error.message,
    });
  }
  // console.log("resp", resp);
  // return libFunc.sendResponse(res, resp);
}

async function editUserProfile(req, res) {
  try {
  } catch (error) {}
}
