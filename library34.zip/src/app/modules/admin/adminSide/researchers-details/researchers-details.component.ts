import { AsyncPipe, CommonModule, NgStyle } from '@angular/common';
import { Component, inject, OnInit, ViewEncapsulation } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { AuthService } from 'app/Services/auth.service';
import { config } from '../../../../../../config';
import { SuspendPatientComponent } from '../../dialog/suspend-patient/suspend-patient.component';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { DeldialogComponent } from '../../dialog/deldialog/deldialog.component';
import { MatSnackBar } from '@angular/material/snack-bar';


interface Doctor {
  doctor_email: string;
  doctor_gender: string;
  doctor_name: string;
  user_contact_number:string;
  user_password:string;
  // user_row_id:string;
  firstname:string;
  lastname:string;
  institution:string;
  cr_on:string;
  system_data:any;
  row_id:string;
  last_login_on:any;
  suspension_on:any;
}

  interface Admin{
  firstname: string;
  email:string;
  lastname: string;
  gender: string;
  photo_path: string;
  user_contact_number: string;
  row_id:string;
}
 

@Component({
  selector: 'app-researchers-details',
  imports:[   
   // AsyncPipe,
   MatButtonModule,
    MatIconModule,
   CommonModule,
   MatTableModule,MatIconModule,FormsModule,
   MatDialogModule,MatIconModule,

       MatInputModule, 
       NgStyle, 
       ReactiveFormsModule, MatFormFieldModule,
       MatProgressSpinnerModule, MatSelectModule, 
  ],
  templateUrl: './researchers-details.component.html'
})
export class ResearchersDetailsComponent {
researchersId!: string | null; // Holds the researchersId ID from the route

  doctor: Doctor[] = [];
 role:any;
  displayedColumns: string[] = [
    // 'user_row_id',
    'doctor_name',
    'doctor_email',
    'user_contact_number',
    'doctor_gender',
    'user_password'
  ];


    AdminDeatials: Admin = {
        firstname: '',
      lastname: '',
      email:'',
      gender: '',
      photo_path: '',
      user_contact_number: '',
      row_id:''
      };

config:any;
    private _snackBar = inject(MatSnackBar);

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private apiController: ApicontrollerService,
    private authService: AuthService,
        private _matDialog: MatDialog,
    
  ) {
            this.config = config.apiBaseURL
    
  }

  ngOnInit() {
    this.researchersId = this.route.snapshot.paramMap.get('id');
    console.log("researchersId",this.researchersId)
        this.role = Number(localStorage.getItem('role')) || 0; // Convert role to a number

 this.AdminDeatials = JSON.parse(localStorage.getItem("userDeatials"));
 this.userdata()
    this.fetchdoctor();


  }


  async fetchdoctor(): Promise<void> {
    try {
      const response = await this.apiController.fetchSefesficdoctor(this.researchersId);
      console.log("doctor----", response.data)
      this.doctor = response.data || []; // Ensure `data` exists in the API response
    } catch (error) {
      // console.error('Error fetching clients:', error);
    }
  }


  goback(){
    // console.log("click this button")
    this.router.navigate(['/Viewresearchers'])
  }
  isEditMode = false;
  originalDoctorData: any = {};

  toggleEditMode() {
    console.log('Before Edit:', this.doctor[0]?.firstname); // should show value like "Abhishek"
    this.originalDoctorData = JSON.parse(JSON.stringify(this.doctor[0]));
    this.isEditMode = true;
  }
  

  cancelEdit() {
    this.doctor[0] = JSON.parse(JSON.stringify(this.originalDoctorData)); // restore original
    this.isEditMode = false;
  }

 async saveResearcherInfo() {
    // Add API call here if needed
    console.log('Saving doctor:', this.doctor[0]);
    this.isEditMode = false;

     try {
      const resp = await this.apiController.updateDoctors('common', this.doctor[0]);
      console.log('doctors update data:', resp);

       if (resp.status === 0) {
        this._snackBar.open(resp.msg, '', {
          duration: 6000,
          verticalPosition: 'top',
          horizontalPosition: 'center',
        });
      } else {
        this._snackBar.open(resp.msg, '', {
          duration:6000,
          verticalPosition: 'top',
          horizontalPosition: 'center',
        });
      }
    } catch (error) {
      console.error('Error updating doctors:', error);
    }

  }

      dashboard(){
    this.router.navigate(['/dashboard'])
}

goResearcher(){
    this.router.navigate(['/Viewresearchers'])

}

admindata:any;
profile_path:any;

 async userdata(){
      const resp = await this.apiController.fetchadmindetails('common/registration', this.AdminDeatials.row_id);
           this.admindata = resp.data as Admin
             this.profile_path = this.admindata[0].photo_path
           console.log("this.firstname --------",this.admindata )

    
    }


    

 async suspendPatient() {
             // this._matDialog.open(SuspendPatientComponent, {
             //     data: { patient: patient },
             // });
       


    const resp = await this.apiController.fetchdoctordetails('common/registration',this.researchersId)
    console.log("resp---->",resp)

          const data = {
      "user_row_id":this.researchersId,
      "active":resp.data[0].active
    }
     console.log("clicked ======")
             const dialogRef = this._matDialog.open(SuspendPatientComponent, {
                 data: { patient: data },
             });
     
     
               dialogRef.afterClosed().subscribe((resp: any) => {
          console.log("res----------------->",resp)
            if (resp) {
               if (resp.status === 0) {
        this._snackBar.open(resp.msg, '', {
          duration: 6000,
          verticalPosition: 'top',
          horizontalPosition: 'center',
        });
      } else {
        this._snackBar.open(resp.msg, '', {
          duration:6000,
          verticalPosition: 'top',
          horizontalPosition: 'center',
        });
      }
            }
        });
             
         }

 async deletebtn() {
  
     const resp = await this.apiController.fetchdoctordetails('common/registration',this.researchersId)
    console.log("resp---->",resp)

          const data = {
      "user_row_id":this.researchersId,
      "active":resp.data[0].active
    }

      const dialogRef = this._matDialog.open(DeldialogComponent, { data: { patient: data  }, });
      // dialogRef.afterClosed().subscribe((result) => {
      //     console.log('dialog was closed!');
      // });
  
         dialogRef.afterClosed().subscribe((resp: any) => {
          console.log("res----------------->",resp)
            if (resp) {
               if (resp.status === 0) {
        this._snackBar.open(resp.msg, '', {
          duration: 6000,
          verticalPosition: 'top',
          horizontalPosition: 'center',
        });
      } else {
        this._snackBar.open(resp.msg, '', {
          duration:6000,
          verticalPosition: 'top',
          horizontalPosition: 'center',
        });
      }
            }
        });
      
    }

    refresh(){
      this.fetchdoctor();
    }

}
