import { Component, Inject, inject, ViewChild } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { DeldialogComponent } from '../../dialog/deldialog/deldialog.component';
import { MatDialog } from '@angular/material/dialog';
import { AdddoctordialogComponent } from '../../dialog/adddoctordialog/adddoctordialog.component';

interface Doctor {
  doctor_email: string;
  doctor_gender: string;
  doctor_name: string;
  user_contact_number:string;
  user_password:string;
  user_row_id:string;
  
}
 

@Component({
  selector: 'app-viewresearchers',
  imports: [MatTableModule,MatPaginatorModule,MatButtonModule,
    MatIconModule,
    MatInputModule],
  templateUrl: './viewresearchers.component.html',
  styleUrl:'./viewresearchers.component.css'
})
export class ViewresearchersComponent { 
  role :any ='';
  // doctor: Doctor[] = [];

  doctor = new MatTableDataSource<Doctor>([]); // Use MatTableDataSource for pagination

  isSearchActive = false;
  isempty = false;

  @ViewChild(MatPaginator) paginator!: MatPaginator;

  // readonly dialogRef = inject(MatDialogRef<ViewresearchersComponent>);
  
  displayedColumns: string[] = [
      'user_row_id', 
      'doctor_name', 
      'doctor_email', 
      'doctor_gender', 
      'user_contact_number',
      'user_password',

      'user_contact_number1',
       'user_contact_number2',
       'user_contact_number3',
       'user_contact_number4',
       'user_contact_number5',
       'user_contact_number6',
       'user_contact_number7',

      


      'actions'
  ];
  constructor(
    private Apicontroller: ApicontrollerService,
    private router: Router,
    private _matDialog: MatDialog
   
  ) { 

    this.role=  localStorage.getItem('role')

    // console.log("my role",this.role)
  }

  ngOnInit(): void {
    console.log(" ngOnInit")

    this.mydoctor();
  }
  
  ngAfterViewInit() {
    console.log(" ngAfterViewInit")
    this.doctor.paginator = this.paginator; // Set paginator after view init
  }

  page: number = 1; // Default to first page

  async mydoctor() {
    console.log(" mydoctor")

    try {
      const resp = await this.Apicontroller.fetchdoctor('common',this.page);
      // console.log("doctor", resp);
      this.doctor.data = resp.data as Doctor[]; // Type assert to Doctor[]
    } catch (error) {
      // console.error("Error fetching doctors:", error);
    }

  }


  viewDoctorDetails(doctor_rowId: string) {
    console.log("viewdata",doctor_rowId)
    this.router.navigate(['researchersDetails', doctor_rowId]);
  }


  filterByQuery(query: string): void {
    const trimmedQuery = query.trim().toLowerCase();

    if (trimmedQuery) {
        this.isSearchActive = true;
        this.doctor.filter = trimmedQuery;

        if (this.doctor.paginator) {
            this.doctor.paginator.firstPage(); // Reset to first page after search
        }
    } else {
        this.isSearchActive = false;
        this.doctor.filter = ''; // Clear filter

        // Reset the paginator and restore original data
        setTimeout(() => {
            this.doctor.paginator = this.paginator;
        });
    }
}

  exportToExcel(): void {
    const dataToExport = this.doctor.data.map((doctor) => ({
      ID: doctor.user_row_id,
      Name: doctor.doctor_name,
      Email: doctor.doctor_email,
      Gender: doctor.doctor_gender,
      Contact: doctor.user_contact_number,
    }));

    const worksheet = XLSX.utils.json_to_sheet(dataToExport);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Doctors');

    const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    const data = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    
    saveAs(data, 'Doctors_List.xlsx');
  }


  refresh(){
    console.log("refresh----")
    this.mydoctor();
    // window.location.reload();
  }


  visibilitybtn(){
    console.log("visibilitybtn .....")
  }
  
  deletebtn(user_row_id:any){

    const dialogRef = this._matDialog.open(DeldialogComponent,{ data: { doctordata: user_row_id  } });
    // dialogRef.afterClosed().subscribe((result) => {
    //     console.log('dialog was closed!');
    // });

    console.log("delete.....")
  }

  
  adddoctordialog(){
    const dialogRef = this._matDialog.open(AdddoctordialogComponent);
  }

 
  
}
