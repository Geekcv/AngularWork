import { Component, ViewChild } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { AddpatientdialogComponent } from '../../dialog/doctor/addpatientdialog/addpatientdialog.component';
import { MatDialog } from '@angular/material/dialog';
import { DeldialogComponent } from '../../dialog/deldialog/deldialog.component';

interface Patient {
 
  patient_age: string;
  patient_email: string;
  patient_gender: string;
  patient_name:string;
  patient_contact:string;
  doctor_name:string;
  doctor_type:string;
  doctor_email:string;
  doctor_gender:string;

  }
   

@Component({
  selector: 'app-viewpatients',
imports: [MatTableModule, MatButtonModule,
  MatIconModule,MatInputModule,MatPaginatorModule],
  templateUrl: './viewpatients.component.html',
  styleUrl:'./viewpatients.component.css'
})
export class ViewpatientsComponent {

  // patient: Patient[] = [];
   
    displayedColumns: string[] = [
      'user_row_id',
      'patient_name',
      'patient_email',
      'patient_contact',
      // 'patient_gender',

      'patient_gender',
      'patient_age',
      'doctor_name',
      'doctor_type',
      'doctor_email',
      'doctor_gender',

      'patient_contact1',
      'patient_contact2',
      'patient_contact3',
      'patient_contact4',
      'patient_contact5',


      'actions'
    ];
  

   role :any ='';

   isSearchActive = false;

    patient = new MatTableDataSource<Patient>([]); // Use MatTableDataSource for pagination

    
      @ViewChild(MatPaginator) paginator!: MatPaginator;

   constructor(
     private Apicontroller: ApicontrollerService,
     private router: Router,
       private _matDialog: MatDialog
   ) { 

    this.role=  localStorage.getItem('role')

  // console.log("my role",this.role)
   }
 
   ngOnInit(): void {
     this.Patients();
   }

   ngAfterViewInit() {
    this.patient.paginator = this.paginator; // Set paginator after view init
  }

   page: number = 1; // Default to first page
   async Patients() {
     try {
       const resp = await this.Apicontroller.fetchPatientsByAdmin('common',this.page);
       console.log("Patients---", resp);
       this.patient.data = resp.data as Patient[]; // Type assert to Doctor[]
     } catch (error) {
       console.error("Error fetching doctors:", error);
     }
 
   }
 
 
   viewDoctorDetails(patient: Patient) {
    //  this.router.navigate(['patientDetails', patient.user_row_id]);
   }




  filterByQuery(query: string): void {
    const trimmedQuery = query.trim().toLowerCase();

    if (trimmedQuery) {
        this.isSearchActive = true;
        this.patient.filter = trimmedQuery;

        if (this.patient.paginator) {
            this.patient.paginator.firstPage(); // Reset to first page after search
        }
    } else {
        this.isSearchActive = false;
        this.patient.filter = ''; // Clear filter

        // Reset the paginator and restore original data
        setTimeout(() => {
            this.patient.paginator = this.paginator;
        });
    }
}

  exportToExcel(): void {
      const dataToExport = this.patient.data.map((patient) => ({
        // ID: patient.user_row_id,
        Name: patient.patient_name,
        Email: patient.patient_email,
        Gender: patient.patient_gender,
        Contact: patient.patient_contact,
      }));
  
      const worksheet = XLSX.utils.json_to_sheet(dataToExport);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Doctors');
  
      const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
      const data = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      
      saveAs(data, 'Patients_List.xlsx');
    }


    refresh(){
      console.log("refresh----")
      this.Patients();
      // window.location.reload();
    }
  
    addpatientdialog(){
        const dialogRef = this._matDialog.open(AddpatientdialogComponent);
      }



      deletebtn(user_row_id:any){
      
          // const dialogRef = this._matDialog.open(DeldialogComponent);
          // dialogRef.afterClosed().subscribe((result) => {
          //     console.log('dialog was closed!');
          // });
      
          console.log("delete.....")
        }


        viewpatientDetails(patient_rowId: string) {
          console.log("viewdata",patient_rowId)
          // this.router.navigate(['patientDetails', patient_rowId]);
          this.router.navigate(['patientpanel', patient_rowId]);

          
        }
      
}
