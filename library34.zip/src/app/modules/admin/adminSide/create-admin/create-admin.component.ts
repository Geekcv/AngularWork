import { Component, inject, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import {
    FormsModule,
    NgForm,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { Router, RouterLink } from '@angular/router';
import { fuseAnimations } from '@fuse/animations';
import { FuseAlertComponent, FuseAlertType } from '@fuse/components/alert';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { AuthService } from 'app/core/auth/auth.service';
import {MatSnackBar} from '@angular/material/snack-bar';
import { HttpClient } from '@angular/common/http';
import { config } from '../../../../../../config';

@Component({
  selector: 'app-create-admin',
  imports: [
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatCheckboxModule,
    MatProgressSpinnerModule,MatSelectModule
  ],
  templateUrl: './create-admin.component.html',
  styleUrl: './create-admin.component.scss'
})
export class CreateAdminComponent {
@ViewChild('signUpNgForm') signUpNgForm: NgForm;

    alert: { type: FuseAlertType; message: string } = {
        type: 'success',
        message: '',
    };
    signUpForm: UntypedFormGroup;
    showAlert: boolean = false;
    role :any ='';

    config:any ;
  filepath:any;
mediatype:any;

    genders: string[] = ['Male', 'Female', 'Other']; // List of genders
    doctorType:string[]=['Dermatologist','Neurologist','Cardiologist','Psychiatrist','Gastroenterologist','Family medicine']
    /**
     * Constructor
     */
    constructor(
        private _authService: AuthService,
        private _formBuilder: UntypedFormBuilder,
        private _router: Router,
        private Apicontroller: ApicontrollerService,private router: Router,private http: HttpClient
    ) {
   this.config = config.apiBaseURL
      this.role=  localStorage.getItem('role')

      // console.log("my role",this.role)
    }

    private _snackBar = inject(MatSnackBar);

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void {
        // Create the form
        this.signUpForm = this._formBuilder.group({
          firstname: ['', Validators.required],
          lastname: ['', Validators.required],
          email: ['', [Validators.required, Validators.email]],
          phone: ['', Validators.required],
          password: ['', Validators.required],
          // doctor_type: ['', Validators.required],
          gender: ['', Validators.required],


            //company: [''],
            //agreements: ['', Validators.requiredTrue],
        });
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * Sign up
     */
 

    async addresearchers(){

      console.log("requesting9999-->",)

       const data = {
        "firstname":this.signUpForm.value.firstname,
        "lastname":this.signUpForm.value.lastname,
        "email":this.signUpForm.value.email,
        "phone":this.signUpForm.value.phone,
        "password":this.signUpForm.value.password,
        // "doctor_type":this.signUpForm.value.doctor_type,
        "gender":this.signUpForm.value.gender,
        "photo_path":this.filepath
      }

     const resp = await this.Apicontroller.createAdmin(data);




    
      if (resp.status === 0) {
      

      
        
        
        this._snackBar.open(resp.msg, '', {
          duration: 3000, // Duration in milliseconds (3 seconds)
          verticalPosition: 'top', // Position: 'top' | 'bottom'
          horizontalPosition: 'center', // Position: 'start' | 'center' | 'end' | 'left' | 'right'
        });

        // this._router.navigate(['/Viewresearchers'])
        this.signUpNgForm.reset()


      }else{
       // this.messageService.add({ severity: 'error', summary: 'Error', detail: resp.msg });
       console.log("error ")
      } 
    }


     onProfileImageSelected(event: Event): void {
   const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      const file = input.files[0];
      const formData = new FormData();
      formData.append('file', file);
  
      console.log(`upload file path  ${this.config}/common/upload`)
    this.http.post(`${this.config}/common/upload`, formData).subscribe({
      next: async (response: any) => {
        console.log("res",response)
        if (response) {
          this.filepath = response.data.foPa || response.data.filePath; // Ensure correct key name
          this.mediatype = response.data.mimetype;

          console.log('Uploaded File:',this.filepath, this.mediatype);         
         
          
        } else {
          console.log("Invalid server response")

        }
      },
      error: (error) => {
        console.error('Upload failed:', error);
      },
    });

    }
}
}
