import { CommonModule } from '@angular/common';
import { Component, Inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import {
    MAT_DIALOG_DATA,
    MatDialogModule,
    MatDialogRef,
} from '@angular/material/dialog';
import { MatRadioModule } from '@angular/material/radio';

interface Column {
    name: string;
    label: string;
    visible: boolean;
}

@Component({
    selector: 'app-cloumn-showdialog',

    imports: [
        MatDialogModule,
        MatRadioModule,
        MatCheckboxModule,
        CommonModule,
        FormsModule,MatButtonModule
    ],
    templateUrl: './cloumn-showdialog.component.html',
    styleUrl: './cloumn-showdialog.component.scss',
})
export class CloumnShowdialogComponent {
    columns: Column[];

    constructor(
        @Inject(MAT_DIALOG_DATA) public data: { columns: Column[] },
        private dialogRef: MatDialogRef<CloumnShowdialogComponent>
    ) {
        // Clone the columns array to avoid modifying parent data directly until save
        this.columns = data.columns.map((c) => ({ ...c }));
    }

    onToggleVisibility(col: Column) {
        col.visible = !col.visible;
    }

    onSave() {
        // Send the updated columns back to parent
        this.dialogRef.close(this.columns);
    }

    onCancel() {
        this.dialogRef.close();
    }

    exitbtn() {
      this.dialogRef.close();
  }

}
