import { CommonModule, NgStyle } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatTimepickerModule } from '@angular/material/timepicker';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

  interface Patient{
    patient_age: string;
    patient_email: string;
    patient_gender: string;
    patient_name: string;
    user_password: string;
    user_contact_number: string;
  }

  interface appointment {
  apt_row_id: string;
  date_of_apt: string;
  // date_of_req:string;
  doctor_name: string;
  user_contact_number: string;
  time_of_apt: string;
  // time_of_req:string;
  appointment_details: any;
  // appointment_details:{appt_status:any,appt_type:any,virtual_link:any};
  // updatedby_user_name:any
}

@Component({
  selector: 'app-addopdsession',
   imports: [MatDialogModule,MatButtonModule,MatIconModule,MatSelectModule,FormsModule
    ,MatDatepickerModule,NgStyle,MatTimepickerModule,CommonModule
  ],
  templateUrl: './addopdsession.component.html',
  styleUrl: './addopdsession.component.scss'
})

export class AddopdsessionComponent {

  selectedvalue:any;
  patients: Patient[] = [];
  selectedDate:any;
  app_type: string = '';
  appointmentdata: appointment[] = [];
  selectedTime: string;
  patientsId!: string | null; // Holds the patientsId ID from the route


    timeSlots: string[] = [ '09:00 AM',
        '10:00 AM',
        '11:00 AM',
        '12:00 PM',
        '01:00 PM',
        '02:00 PM',
        '03:00 PM',
        '04:00 PM']; // Ensure this has values

  availableslot: string[] = ['Physical', 'Virtual'];


  constructor(private apiController: ApicontrollerService,       
     private dialogRef: MatDialogRef<AddopdsessionComponent>
  ){
      this.mypatients()
  }

    selectTime(slot: string) {
    console.log('Selected Slot:', slot,this.selectedDate);
    this.selectedTime = slot;
  }



    async mypatients() {
        try {
          const resp = await this.apiController.fetchPatients();

        
          //console.log("doctor", resp);
          this.patients = resp.data as Patient[]; // Type assert to Doctor[]
        } catch (error) {
          console.error("Error fetching doctors:", error);
        }
    
      }

      async requestAppointment(){
    // console.log("time value-",this.timevalue.toTimeString().split(' ')[0], "date value-",this.datevalue.toDateString())

    console.log("selected patients",this.selectedvalue)

    var data ={
      pat_row_id:this.selectedvalue,
      time_of_apt:this.selectedTime,
      date_of_apt:this.selectedDate,
      appt_type:this.app_type
    }

    console.log("before appointment data",data)
    const resp = await this.apiController.opdAppointment(data);
    console.log("response--->",data)
   
    this.refresh();
        this.dialogRef.close(resp);


  }

    refresh() {
    console.log("refresh----")
    this.viewappointment();
    // window.location.reload();
  }

    async viewappointment() {
    const resp1 = await this.apiController.fetchappointmentdoctor(this.patientsId);
    this.appointmentdata = resp1.data || []


    console.log("view patients appointments resp ",resp1)
  }

  
    exitbtn() {
        this.dialogRef.close();
    }

}