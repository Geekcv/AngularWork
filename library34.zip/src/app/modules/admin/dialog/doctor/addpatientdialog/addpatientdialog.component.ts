import { Component, OnInit, ViewChild } from '@angular/core';
import {
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatDrawer, MatSidenavModule } from '@angular/material/sidenav';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatStepperModule } from '@angular/material/stepper';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

@Component({
    selector: 'app-addpatientdialog',
    imports: [
        MatSelectModule,
        MatStepperModule,
        MatFormFieldModule,
        MatInputModule,
        ReactiveFormsModule,
        MatButtonModule,
        MatDialogModule,MatSidenavModule,        MatIconModule
    ],
    templateUrl: './addpatientdialog.component.html',
    styleUrls: ['./addpatientdialog.component.scss'],
})
export class AddpatientdialogComponent implements OnInit {
    signUpForm: UntypedFormGroup;
    genders: string[] = ['Male', 'Female', 'Other'];
    passwordFieldType: 'password' | 'text' = 'password';
    @ViewChild('drawer') drawer: MatDrawer;
    drawerMode: 'over' | 'side' = 'side';
    drawerOpened: boolean = true;

    constructor(
        private _formBuilder: UntypedFormBuilder,
        private _router: Router,
        private _snackBar: MatSnackBar,
        private _apiController: ApicontrollerService,
        private dialogRef: MatDialogRef<AddpatientdialogComponent>
    ) {}

    ngOnInit(): void {
        this.signUpForm = this._formBuilder.group({
            patient_name: ['', Validators.required],
            patient_email: ['', [Validators.required, Validators.email]],
            patient_number: ['', Validators.required],
            patient_password: ['', Validators.required],
            patient_age: ['', Validators.required],
            patient_gender: ['', Validators.required],
        });
    }

    togglePasswordVisibility() {
        this.passwordFieldType =
            this.passwordFieldType === 'password' ? 'text' : 'password';
    }

    exitbtn() {
        this.dialogRef.close();
    }

    async addPatient() {
        if (this.signUpForm.invalid) {
            this.signUpForm.markAllAsTouched();
            return;
        }

        const resp = await this._apiController.AddPatients(
            this.signUpForm.value
        );

        // if (resp.status === 0) {
        //     this._snackBar.open(resp.msg, '', {
        //         duration: 3000,
        //         verticalPosition: 'top',
        //         horizontalPosition: 'center',
        //     });

        //     // this.dialogRef.close();
        //     // this._router.navigate(['/Viewpatients']);
        // } else {
        //     this._snackBar.open('Error creating patient account.', '', {
        //         duration: 3000,
        //         verticalPosition: 'top',
        //         horizontalPosition: 'center',
        //     });
        // }
    }

    finish() {
        if (this.signUpForm.valid) {
            // Call your addPatient logic or API

            // Optionally, show a confirmation message or close dialog
            this.dialogRef.close('Patient created successfully!'); // If using MatDialog
        }
    }
}
