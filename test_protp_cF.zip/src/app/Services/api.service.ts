import { Injectable } from '@angular/core';
import axios from 'axios';
import * as protobuf from 'protobufjs';
import { config } from '../../../config';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private root!: protobuf.Root;
  private CommonRequest!: protobuf.Type;
  private CommonResponse!: protobuf.Type;

  async loadProto(): Promise<void> {
    if (!this.root) {
      this.root = await protobuf.load('images/education.proto'); // Path in Angular assets
      this.CommonRequest = this.root.lookupType('education.CommonRequest');
      this.CommonResponse = this.root.lookupType('education.CommonResponse');
      console.log('Proto loaded in Angular');
    }
  }

  encodeRequest(data: any): Uint8Array {
    const message = this.CommonRequest.create(data);
    return this.CommonRequest.encode(message).finish();
  }

  decodeResponse(buffer: ArrayBuffer): any {
    const message = this.CommonResponse.decode(new Uint8Array(buffer));
    return this.CommonResponse.toObject(message, { enums: String, longs: String });
  }

  private buildHeaders() {
    return {
      'Content-Type': 'application/octet-stream',
      'Accept': 'application/octet-stream'
    };
  }

  async postUrl(data: any, url: string) {
    await this.loadProto();
    console.log("Angular Payload:", data);

    const payload = this.encodeRequest(data);
    console.log("Encoded buffer length:", payload.length);

    const resp = await axios.post(
      `${config.apiBaseURL}/${url}`,
      payload,
      {
        headers: this.buildHeaders(),
        responseType: 'arraybuffer',
        transformRequest: [(data) => data] // Prevent JSON transformation
      }
    );

    return this.decodeResponse(resp.data);
  }
}
