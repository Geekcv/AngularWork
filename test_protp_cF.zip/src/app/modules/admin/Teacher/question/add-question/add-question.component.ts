import { Component, inject, ViewChild } from '@angular/core';
import {
    FormsModule,
    NgForm,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { config } from '../../../../../../../config';

interface chapterdata {
  chapter_id: string;
  chapter_name: string;
}

interface Teacher {
    email: string;
    name: string;
    row_id: string;
    role: string;
}

@Component({
    selector: 'app-add-mcq',
    imports: [
        FormsModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatInputModule,
        MatButtonModule,
        MatIconModule,
        MatCheckboxModule,
        MatProgressSpinnerModule,
        MatSelectModule,
    ],
    templateUrl: './add-question.component.html',
    styleUrl: './add-question.component.scss',
})
export class AddMCQComponent {
    @ViewChild('mcqNgForm') mcqNgForm: NgForm;

    mcqForm: UntypedFormGroup;
    showAlert = false;
    role: any = '';
    config: any;

    subjectList = [];
    chapterList = [];

    TeacherDeatials: Teacher = {
        email: '',
        name: '',
        row_id: '',
        role: '',
    };

    constructor(
        private _formBuilder: UntypedFormBuilder,
        private _router: Router,
        private api: ApicontrollerService
    ) {
        this.config = config.apiBaseURL;
        this.role = localStorage.getItem('role');
        this.TeacherDeatials = JSON.parse(localStorage.getItem('userDeatials'));

        this.fetchcompltedChapter();
    }

    private _snackBar = inject(MatSnackBar);

    ngOnInit(): void {
        this.mcqForm = this._formBuilder.group({
            chapter_id: ['', Validators.required],
            question: ['', Validators.required],
            option_a: ['', Validators.required],
            option_b: ['', Validators.required],
            option_c: ['', Validators.required],
            option_d: ['', Validators.required],
            correct_option: ['', Validators.required],
        });
    }

    // boardList = [
    //     { row_id: '1729833318838_Ir5A', name: 'CBSE' },
    //     { row_id: '1729862517377_iMzd', name: 'RBSE' },
    // ];

    async submitMcq(): Promise<void> {
        if (this.mcqForm.invalid) {
            this.mcqForm.markAllAsTouched();
            return;
        }

        const payload = {
            ...this.mcqForm.value,
        };

        // const resp = await this.api.addMcq(payload);

        // if (resp.status === 0) {
        //     this._snackBar.open(resp.msg, '', {
        //         duration: 3000,
        //         verticalPosition: 'top',
        //         horizontalPosition: 'center',
        //     });

        //     this.mcqNgForm.resetForm();
        // } else {
        //     this._snackBar.open(resp.msg || 'Failed to add chapter', '', {
        //         duration: 3000,
        //         verticalPosition: 'top',
        //         horizontalPosition: 'center',
        //     });
        // }
    }

    selectedValuechapter: any;
    async fetchcompltedChapter() {
        //
        const resp = await this.api.fetchAllcompletedChapter(
            'common',
            this.TeacherDeatials.row_id
        );
        console.log('resp-----------', resp);
        this.chapterList = resp.data as chapterdata[]
    }

    //
}
