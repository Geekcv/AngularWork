import { HttpClient } from '@angular/common/http';
import { Component, inject, ViewChild } from '@angular/core';
import {
    FormsModule,
    NgForm,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { config } from '../../../../../../../config';
import { FuseDrawerComponent } from '@fuse/components/drawer';
import { CommonModule, NgStyle } from '@angular/common';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSort, MatSortModule } from '@angular/material/sort';

interface board {
 row_id:string;
  name:string;
}

  interface Column {
  name: string; // The column name/key (must match MatTable's columnDef)
  label: string; // The displayed label for checkbox and header
  visible: boolean; // Whether this column is currently shown
}

  interface School {
  row_id: string; 
  name: string;
  email:string;
  phone:string;
  address:string;
  board_name:string
}

@Component({
  selector: 'app-add-school',
  imports: [
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatCheckboxModule,
    MatProgressSpinnerModule,
    MatSelectModule,
     FuseDrawerComponent,
                        NgStyle,

                          MatTableModule,
                                        MatPaginatorModule,
                                     
                                         MatTooltipModule, MatSortModule,
                                      
                                            CommonModule,
  ],
  templateUrl: './add-school.component.html',
  styleUrl: './add-school.component.scss'
})
export class AddSchoolComponent {
  @ViewChild('schoolNgForm') schoolNgForm: NgForm;

  schoolForm: UntypedFormGroup;
  showAlert = false;
  role: any = '';
  config: any;


   isSearchActive = false;
          schoolData = new MatTableDataSource<School>([]); // Use MatTableDataSource for pagination
           @ViewChild(MatPaginator) paginator!: MatPaginator;
             @ViewChild(MatSort) sort!: MatSort;
  

  constructor(
      private _formBuilder: UntypedFormBuilder,
      private _router: Router,
      private api: ApicontrollerService,
  ) {
      this.config = config.apiBaseURL;
      this.role = localStorage.getItem('role');
      this.fetchallboard()
      this.fetchallschool()
  }

  private _snackBar = inject(MatSnackBar);

   get displayedColumns(): string[] {
    return this.columns.filter((c) => c.visible).map((c) => c.name);
  }

  ngOnInit(): void {
      this.schoolForm = this._formBuilder.group({
          name: ['', Validators.required],
          email: ['', [Validators.required, Validators.email]],
          phone: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
          address: ['', Validators.required],
          board_id: ['', Validators.required], 
          password: ['', Validators.required],
          is_active: [true],
      });
  }

//   boardList = [
//       { row_id: '1729833318838_Ir5A', name: 'CBSE' },
//       { row_id: '1729862517377_iMzd', name: 'RBSE' },
//   ];

  async addSchool(addschool:any): Promise<void> {
      if (this.schoolForm.invalid) {
          this.schoolForm.markAllAsTouched();
          return;
      }

      const payload = {
          ...this.schoolForm.value,
          created_by: localStorage.getItem('row_id') || '', // optional
      };

      const resp = await this.api.createschool(payload);

      if (resp.status === 0) {
          this._snackBar.open(resp.msg, '', {
              duration: 3000,
              verticalPosition: 'top',
              horizontalPosition: 'center',
          });

          this.schoolNgForm.resetForm();
          addschool.close()
      this.fetchallschool()

      } else {
          this._snackBar.open(resp.msg || 'Failed to add school', '', {
              duration: 3000,
              verticalPosition: 'top',
              horizontalPosition: 'center',
          });
      }
  }

  boardList = []
   async fetchallboard(){
    // 
      const resp = await this.api.fetchallBoard();
      console.log("res---------",resp)
      this.boardList = resp as board[]

  }



           columns: Column[] = [
    { name: 'sr_no', label: 'Sr.No', visible: true },
    { name: 'name', label: 'School Name', visible: true },   
    { name: 'email', label: 'Email', visible: true },
    { name: 'phone', label: 'Phone Number', visible: true },
    { name: 'address', label: 'Address', visible: true },
    // { name: 'board_name', label: 'Board Name', visible: true },
    // { name: 'actions', label: 'Actions', visible: true },

  ];

   editRowId: number | null = null;

  editRow(rowId: number) {
    this.editRowId = rowId;
  }

  isRowEditing(rowId: any) {
    return this.editRowId === rowId;
  }

     async saveRow(row: any) {
    console.log("row-----", row)
    this.editRowId = null;

   
  }

  cancelEdit() {
    this.editRowId = null;
  }

     async fetchallschool() {
    console.log(" before data")

    try {
     const resp = await this.api.fetchAllSchool('common');

      const data = resp as School[];

      console.log("school data",data)

      // Add sr_no for each row (based on pagination if needed)
      this.schoolData.data = data.map((item, index) => ({
        ...item,
        sr_no: index + 1 + this.schoolData.paginator.pageIndex * this.schoolData.paginator.pageSize
      }));

      console.log("class.data ------------------>", this.schoolData.data);


      // Enable sorting for custom fields like user_row_id (extract numeric part)
      this.schoolData.sortingDataAccessor = (item, property) => {
        if (property === 'row_id') {
          return Number(item.row_id?.split('_')[0]); // numeric part
        }
        return item[property];
      };



    } catch (error) {
      // console.error("Error fetching doctors:", error);
    }

  }

   ngAfterViewInit() {
    // console.log(" ngAfterViewInit")
    this.schoolData.paginator = this.paginator; // Set paginator after view init
    this.schoolData.sort = this.sort

  }

   filterByQuery(query: string): void {
    const trimmedQuery = query.trim().toLowerCase();

    if (trimmedQuery) {
      this.isSearchActive = true;
      this.schoolData.filter = trimmedQuery;

      if (this.schoolData.paginator) {
        this.schoolData.paginator.firstPage(); // Reset to first page after search
      }
    } else {
      this.isSearchActive = false;
      this.schoolData.filter = ''; // Clear filter

      // Reset the paginator and restore original data
      setTimeout(() => {
        this.schoolData.paginator = this.paginator;
      });
    }
  }
}


