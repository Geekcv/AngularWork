import { Routes } from '@angular/router';
import { ShowClassComponent } from './show-class.component';

export default [
    {
        path: '',
        component: ShowClassComponent,
    },
] as Routes;
