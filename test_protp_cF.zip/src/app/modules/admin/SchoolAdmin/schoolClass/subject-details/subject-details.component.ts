import { CommonModule, NgIf, NgStyle } from '@angular/common';
import { Component, inject, ViewChild } from '@angular/core';
import { FormsModule, NgForm, ReactiveFormsModule, UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatTooltipModule } from '@angular/material/tooltip';
import { ActivatedRoute, Router } from '@angular/router';
import { FuseDrawerComponent } from '@fuse/components/drawer';
import { FuseNavigationService, FuseVerticalNavigationComponent } from '@fuse/components/navigation';
import { ApicontrollerService } from 'app/controller/apicontroller.service';



interface Chapter {
  row_id: string;
  name: string;
  subject_name:string;
}


interface Column {
  name: string; // The column name/key (must match MatTable's columnDef)
  label: string; // The displayed label for checkbox and header
  visible: boolean; // Whether this column is currently shown
}

  interface Teacher{
    email: string;
    name:string;
    row_id:string;
    role:string;
  }

  interface SuperAdmin{
  name: string;
  email:string;
  user_type:string;
  row_id:string;
}

interface Student {
    email: string;
    role: string;
    name: string;
    row_id: string;
  }


interface SchoolAdmin {
  email: string;
  role: string;
  name: string;
  row_id: string;
  school_id: string;
}


@Component({
  selector: 'app-subject-details',
  imports: [
    MatTableModule,
    MatPaginatorModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    NgStyle, MatTooltipModule, MatSortModule,
    ReactiveFormsModule, MatFormFieldModule,
    MatSelectModule, CommonModule,
    FormsModule, NgIf, FuseDrawerComponent,
  ],
  templateUrl: './subject-details.component.html',
  styleUrl: './subject-details.component.scss'
})
export class SubjectDetailsComponent {
  ChapterData = new MatTableDataSource<Chapter>([]); // Use MatTableDataSource for pagination
  @ViewChild(MatPaginator) paginator!: MatPaginator;

  @ViewChild('addchapterNgForm') addchapterNgForm: NgForm;

  @ViewChild(MatSort) sort!: MatSort;

  private _snackBar = inject(MatSnackBar);

  addchapterForm: UntypedFormGroup;



  // classData:any;
  isSearchActive = false;
  classId: any;
  subjectID: any
  role:any;


  SchoolAdminDeatials: SchoolAdmin = {
    email: '',
    name: '',
    role: '',
    row_id: '',
    school_id: ''
  };

  fnames :any = '';
    lnames :any = '';
    name:any = '';

   
    
      TeacherDeatials: Teacher = {
      email: '',
      name:'',
      row_id:'',
      role:''
      };

      SuperAdminDeatials: SuperAdmin = {
       name: '',
      email:'',
      user_type:'',
      row_id:''
      };

      StudentDeatials: Student = {
         name: '',
      email:'',
      role:'',
      row_id:''
      }

  constructor(
    private Apicontroller: ApicontrollerService,
    private router: Router,
    private route: ActivatedRoute,
    private _formBuilder: UntypedFormBuilder,
                private _fuseNavigationService: FuseNavigationService,
    



  ) {
        this.role = Number(localStorage.getItem('role')) || 0; // Convert role to a number

    this.classId = this.route.snapshot.paramMap.get('classid');
    this.subjectID = this.route.snapshot.paramMap.get('id');

    this.SchoolAdminDeatials = JSON.parse(localStorage.getItem("userDeatials"));

    this.fetchchapter(this.subjectID)


     if(this.role==3){
      this.TeacherDeatials = JSON.parse(localStorage.getItem("userDeatials"));

      this.fnames = this.TeacherDeatials.name

    }else if (this.role==2){
      
      this.SchoolAdminDeatials = JSON.parse(localStorage.getItem("userDeatials"));

      this.fnames = this.SchoolAdminDeatials.name
    
    }else if (this.role==1){
      
      this.SuperAdminDeatials = JSON.parse(localStorage.getItem("userDeatials"));
      this.fnames = this.SuperAdminDeatials.name    
    } else if (this.role == 4){
        this.StudentDeatials = JSON.parse(localStorage.getItem("userDeatials"));

      this.fnames = this.StudentDeatials.name
    }
  }

  ngOnInit(): void {
    this.addchapterForm = this._formBuilder.group({
      chaptername: ['', Validators.required],
    });
  }




  get displayedColumns(): string[] {
    return this.columns.filter((c) => c.visible).map((c) => c.name);
  }


  columns: Column[] = [
    { name: 'sr_no', label: 'Sr.No', visible: true },
    { name: 'name', label: 'Chapter Name', visible: true },
    { name: 'actions', label: 'Actions', visible: true },


  ];


  editRowId: number | null = null;

  editRow(rowId: number) {
    this.editRowId = rowId;
  }

  isRowEditing(rowId: any) {
    return this.editRowId === rowId;
  }






  async saveRow(row: any) {
    console.log("row-----", row)
    this.editRowId = null;

     const isValid =
    row.name?.trim();

  if (!isValid) {
     this.fetchchapter(this.subjectID)
    return;
  }

    try {
      const resp = await this.Apicontroller.createorEditSchoolOwnSubjectofChapter(row, 'common');
      // console.log('doctors update data:', resp);
      if (resp.status === 0) {
        this._snackBar.open(resp.msg, '', {
          duration: 3000,
          verticalPosition: 'top',
          horizontalPosition: 'center',
        });
      } else {
        this._snackBar.open(resp.msg, '', {
          duration: 4000,
          verticalPosition: 'top',
          horizontalPosition: 'center',
        });
      }
    } catch (error) {
      console.error('Error updating chapter:', error);
    }
  }

  cancelEdit() {
    this.editRowId = null;
  }


  ngAfterViewInit() {
    // console.log(" ngAfterViewInit")
    this.ChapterData.paginator = this.paginator; // Set paginator after view init
    this.ChapterData.sort = this.sort

  }



  goback() {
    this.router.navigate(['/classdetails', this.classId])
  }



  viewSubjectbtn(rowId: string) {
    this.router.navigate(['subjectdetails', rowId]);

  }


subject_name:any
  async fetchchapter(subjectId: any) {
    try {
      console.log("inside fetch chpater", subjectId)

      const resp = await this.Apicontroller.fetchSubjectChapter('common', subjectId);
      //  this.classData.data = resp
      console.log("chapter data ------------------>", resp);



      const data = resp as Chapter[];

     console.log("subject name ----",data[0].subject_name)
     this.subject_name = data[0].subject_name



      this.ChapterData.data = data.map((item, index) => ({
        ...item,
        sr_no: index + 1 + this.ChapterData.paginator.pageIndex * this.ChapterData.paginator.pageSize
      }));

      console.log("chapter-----", this.ChapterData)

      // Enable sorting for custom fields like user_row_id (extract numeric part)
      this.ChapterData.sortingDataAccessor = (item, property) => {
        if (property === 'row_id') {
          return Number(item.row_id?.split('_')[0]); // numeric part
        }
        return item[property];
      };



    } catch (error) {
      // console.error("Error fetching doctors:", error);
    }
  }

  async addOwnchapter(addchapter: any) {

    const school_id = this.SchoolAdminDeatials.school_id


    if (this.addchapterForm.invalid) {
      this.addchapterForm.markAllAsTouched();
      return;
    }

    const payload = {
      name: this.addchapterForm.value.chaptername,
      school_id,
      subject_id: this.subjectID
    };

    // console.log("payload------------",payload)

    const resp = await this.Apicontroller.createorEditSchoolOwnSubjectofChapter(payload);

    if (resp.status === 0) {
      this._snackBar.open(resp.msg, '', {
        duration: 3000,
        verticalPosition: 'top',
        horizontalPosition: 'center',
      });

      this.addchapterNgForm.resetForm();
      this.refresh()
    } else {
      this._snackBar.open(resp.msg || 'Failed to add chapter', '', {
        duration: 3000,
        verticalPosition: 'top',
        horizontalPosition: 'center',
      });

    }

    addchapter.close()
  }

  refresh() {
    this.fetchchapter(this.subjectID)

  }


dashboard(){
    this.router.navigate(['/dashboard'])

}


allclass(){
     this.router.navigate(['/showclass'])

}

allSubject(){
    this.router.navigate(['/classdetails', this.classId])

}


filterByQuery(query: string): void {
    const trimmedQuery = query.trim().toLowerCase();

    if (trimmedQuery) {
      this.isSearchActive = true;
      this.ChapterData.filter = trimmedQuery;

      if (this.ChapterData.paginator) {
        this.ChapterData.paginator.firstPage(); // Reset to first page after search
      }
    } else {
      this.isSearchActive = false;
      this.ChapterData.filter = ''; // Clear filter

      // Reset the paginator and restore original data
      setTimeout(() => {
        this.ChapterData.paginator = this.paginator;
      });
    }
  }

    toggleNavigation(name: string): void {
            // Get the navigation
            const navigation =
                this._fuseNavigationService.getComponent<FuseVerticalNavigationComponent>(
                    name
                );
    
            if (navigation) {
                // Toggle the opened status
                navigation.toggle();
            }
        }

}
