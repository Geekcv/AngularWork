import { HttpClient } from '@angular/common/http';
import { Component, inject, ViewChild } from '@angular/core';
import {
    FormsModule,
    NgForm,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { config } from '../../../../../../../config';

interface classData{
  row_id:string;
  name:string
}

interface subjectData{
  row_id:string;
  name:string
}

interface Teacher{
  row_id:string;
  name:string
  user_row_id:string
}


interface SchoolAdmin {
  email: string;
  role: string;
  name: string;
  row_id: string;
  school_id: string;
}


@Component({
  selector: 'app-assign-subject',
  imports: [
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatCheckboxModule,
    MatProgressSpinnerModule,
    MatSelectModule,
  ],
  templateUrl: './assign-subject.component.html',
  styleUrl: './assign-subject.component.scss'
})
export class AssignSubjectComponent {

  @ViewChild('assignSubjectNgForm') assignSubjectNgForm: NgForm;

  assignSubjectForm: UntypedFormGroup;
  showAlert = false;
  role: any = '';
  config: any;

  subjectList = []
  classList = []
  teacherList = []

  SchoolAdminDeatials: SchoolAdmin = {
    email: '',
    name: '',
    role: '',
    row_id: '',
    school_id: ''
  };

  constructor(
      private _formBuilder: UntypedFormBuilder,
      private _router: Router,
      private api: ApicontrollerService,
  ) {
      this.config = config.apiBaseURL;
      this.role = localStorage.getItem('role');
      this.SchoolAdminDeatials = JSON.parse(localStorage.getItem("userDeatials"));
      this.fetchclassdata()
      this.fetchallTeacher()

  }

  private _snackBar = inject(MatSnackBar);

  ngOnInit(): void {
      this.assignSubjectForm = this._formBuilder.group({
        class_id :['',Validators.required],
          subject_id:['',Validators.required],
          teacher_id:['',Validators.required]
          
      });
  }

  


  async addSubject(): Promise<void> {
      if (this.assignSubjectForm.invalid) {
          this.assignSubjectForm.markAllAsTouched();
          return;
      }

      const payload = {
          ...this.assignSubjectForm.value,
      };

      // const resp = await this.api.assignSubject(payload);

      // if (resp.status === 0) {
      //     this._snackBar.open(resp.msg, '', {
      //         duration: 3000,
      //         verticalPosition: 'top',
      //         horizontalPosition: 'center',
      //     });

      //     this.assignSubjectNgForm.resetForm();
      // } else {
      //     this._snackBar.open(resp.msg || 'Failed to add Assign Subject', '', {
      //         duration: 3000,
      //         verticalPosition: 'top',
      //         horizontalPosition: 'center',
      //     });
      // }
  }


    async fetchclassdata(){
        // this.selectedValue = (event.target as HTMLSelectElement).value;

        const resp = await this.api.fetchSchoolclass('common', this.SchoolAdminDeatials.school_id);
        console.log("resp",resp)
        this.classList = resp as classData[]
       

      }

      async fetchallTeacher(){
    
      const resp = await this.api.fetchallSchoolownTeacher('common',this.SchoolAdminDeatials.school_id);
      console.log("teacher data",resp)
      this.teacherList = resp as Teacher[]

  }

  // 

  selectedValueclass:any;

    async onSelectionChangeclass(event: Event){
        // this.selectedValue = (event.target as HTMLSelectElement).value;
        console.log('Selected  value:---------', this.selectedValueclass);

        // const resp = await this.api.fetchAllsubjectOfclass('common', this.selectedValueclass);
        const resp = await this.api.fetchClassSubject('common', this.selectedValueclass);

        console.log("resp",resp)
        this.subjectList = resp as subjectData[]
       

      }
}
