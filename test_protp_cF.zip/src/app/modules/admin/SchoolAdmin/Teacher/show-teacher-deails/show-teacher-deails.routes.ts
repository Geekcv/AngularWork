import { Routes } from '@angular/router';
import { ShowTeacherDeailsComponent } from './show-teacher-deails.component';

export default [
    {
        path: '',
        component: ShowTeacherDeailsComponent,
    },
] as Routes;
