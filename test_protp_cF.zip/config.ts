export const config = {
    
    apiBaseURL : 'http://192.168.114.1:3002', 

    // apiBaseURL:'http://aiclassroom.ftisindia.com',

    appVersion: '1.2.0'
}

