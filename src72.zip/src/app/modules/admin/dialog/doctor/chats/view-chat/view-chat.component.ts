import { Component, Inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-view-chat',
  imports: [MatDialogModule,MatButtonModule],
  templateUrl: './view-chat.component.html',
  styleUrl: './view-chat.component.scss'
})
export class ViewChatComponent {

  constructor(
      @Inject(MAT_DIALOG_DATA) public data: {patient: string},
          private dialogRef: MatDialogRef<ViewChatComponent> // Inject MatDialogRef
      
  ){

  }

  exitbtn(){

    this.dialogRef.close();

  }

}
