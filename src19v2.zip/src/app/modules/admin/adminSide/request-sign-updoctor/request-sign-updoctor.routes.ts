import { Routes } from '@angular/router';
import { RequestSignUpdoctorComponent } from './request-sign-updoctor.component';

export default [
    {
        path: '',
        component: RequestSignUpdoctorComponent,
    },
] as Routes;
