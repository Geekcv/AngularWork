import { Routes } from '@angular/router';
import { CreateAdminComponent } from './create-admin.component';

export default [
    {
        path: '',
        component: CreateAdminComponent,
    },
] as Routes;
