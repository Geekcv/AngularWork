import { Routes } from '@angular/router';
import { DashboardComponent } from 'app/modules/admin/dashboard/dashboard.component';

export default [
    {
        path: '',
        component: DashboardComponent,
    },
] as Routes;
