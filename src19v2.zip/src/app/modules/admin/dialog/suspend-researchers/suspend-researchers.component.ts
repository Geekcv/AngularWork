import { Component, Inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import {
  MatDialog,
  MatDialogActions,
  MatDialogClose,
  MatDialogContent,
  MatDialogRef,
  MatDialogTitle,
} from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

interface Patient {
 
  patient_age: string;
  patient_email: string;
  patient_gender: string;
  patient_name:string;
  user_contact_number:string;
  user_password:string;
  row_id:string;
  }
@Component({
  selector: 'app-suspend-researchers',
 imports: [MatDialogModule,MatButtonModule,MatIconModule],
  templateUrl: './suspend-researchers.component.html',
  styleUrl: './suspend-researchers.component.scss'
})
export class SuspendResearchersComponent {
 ID:any;
  status:any;
  patient: Patient[] = [];


  constructor(
     @Inject(MAT_DIALOG_DATA) public data: {patient: any},
                private dialogRef: MatDialogRef<SuspendResearchersComponent>, // Inject MatDialogRef   ,
                    private Apicontroller: ApicontrollerService,
                    
                
  ){
      console.log("doctor id",data.patient)
      this.ID = data.patient.user_row_id;
      this.status = data.patient.active;

  }

  async  suspendResponse(){
    console.log("status this patiens ",this.status)  
    

    if(this.status===0)
    var data ={
      row_id:this.ID,
      active:1
    }

    if (this.status ===1) {
      var data ={
        row_id:this.ID,
        active:0
      }
    }

    console.log("data-->",data)

    const resp = await this.Apicontroller.softdelPatient(data);

    console.log("resp------->",resp)

       this.dialogRef.close(this.ID);


  }

  async fetchSefesficpatients(): Promise<void> {
    try {
      const response = await this.Apicontroller.fetchSefesficpatients(this.ID);
      this.patient = response.data || []; // Ensure `data` exists in the API response
    } catch (error) {
      // console.error('Error fetching clients:', error);
    }
  }

    exitbtn() {
      this.dialogRef.close();
  }

}
