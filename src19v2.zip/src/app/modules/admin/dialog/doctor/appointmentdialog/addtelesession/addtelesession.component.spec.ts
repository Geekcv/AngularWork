import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddtelesessionComponent } from './addtelesession.component';

describe('AddtelesessionComponent', () => {
  let component: AddtelesessionComponent;
  let fixture: ComponentFixture<AddtelesessionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddtelesessionComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddtelesessionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
