import { Component, Inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import {
  MatDialog,
  MatDialogActions,
  MatDialogClose,
  MatDialogContent,
  MatDialogRef,
  MatDialogTitle,
} from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

@Component({
  selector: 'app-deltelesessions',
  imports: [MatDialogModule,MatButtonModule,MatIconModule],
  templateUrl: './deltelesessions.component.html',
  styleUrl: './deltelesessions.component.scss'
})
export class DeltelesessionsComponent {

  ID:any;


  constructor(
     @Inject(MAT_DIALOG_DATA) public data: {appointment: any},
                private dialogRef: MatDialogRef<DeltelesessionsComponent>, // Inject MatDialogRef   ,
                    private Apicontroller: ApicontrollerService
                
  ){
      console.log("appointment id",data.appointment.apt_row_id)
      this.ID = data.appointment.apt_row_id;

  }

async  deleteresponse(){
    console.log("delete this patiens ",this.ID)

    var data ={
      row_id:this.ID,
      deleted:1
    }

    console.log("data-->",data)

    const resp = await this.Apicontroller.softdelTeleSession(data);



     this.dialogRef.close(this.ID);
  }

   exitbtn() {
      this.dialogRef.close();
  }

}
