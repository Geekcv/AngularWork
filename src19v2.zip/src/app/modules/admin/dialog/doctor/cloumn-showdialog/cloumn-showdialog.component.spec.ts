import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CloumnShowdialogComponent } from './cloumn-showdialog.component';

describe('CloumnShowdialogComponent', () => {
  let component: CloumnShowdialogComponent;
  let fixture: ComponentFixture<CloumnShowdialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CloumnShowdialogComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CloumnShowdialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
