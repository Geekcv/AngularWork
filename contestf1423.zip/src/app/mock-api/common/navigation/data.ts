


/* eslint-disable */
import { FuseNavigationItem } from '@fuse/components/navigation';

export const defaultNavigation = (role: any): FuseNavigationItem[] => {
    const navigation: FuseNavigationItem[] = [];

    if (role === 0) { // Super Admin - Full Access
        navigation.push(
            {
                id: 'dashboard',
                title: 'Dashboard',
                type: 'basic',
                icon: 'mat_solid:dashboard',
                link: '/dashboard',
            },
            {
                id: 'Viewresearchers',
                title: 'View Researchers',
                type: 'basic',
                icon: 'heroicons_mini:user-group',
                link: '/Viewresearchers'
            },
            
            {
                id: 'Viewpatients',
                title: 'View Participants',
                type: 'basic',
                icon: 'heroicons_outline:users',
                link: '/viewpatients'
            },
           
             {
                id:'formsdesign',
                title:'Forms Design',
                type:'basic',
                icon:'heroicons_outline:code-bracket',
                link:'formsdesign'
             },
          
             {
               id:'request',
               title:'Request',
               type:'basic',
               icon:'heroicons_outline:arrow-trending-up',
               link:'rquestSignUpdoctor'
            },
             {
                id:'settings',
                title:'Settings',
                type:'basic',
                icon:'feather:settings',
                link:'settings'
             },     
        );
    } else if (role === 1) { // Admin - Limited Access
        navigation.push(
            {
                id: 'dashboard',
                title: 'Dashboard',
                type: 'basic',
                icon: 'mat_solid:dashboard',
                link: '/dashboard',
            },
            {
                id: 'Viewpatients',
                title: 'View Participants ',
                type: 'basic',
                icon: 'heroicons_outline:user',
                link: '/Viewpatients',
                customClass: 'view-patients-highlight', // custom CSS class
            
            },
          
            {
                id: 'audionotes',
                title: 'Audio Notes',
                type: 'basic',
                icon: 'mat_outline:audiotrack',
                link: '/audionotestable'
            },
            {
                id: 'videonotes',
                title: 'Video Notes',
                type: 'basic',
                icon: 'heroicons_outline:video-camera',
                link: '/videonotestable'
            },
            {
                id: 'telesessions',
                title: 'Tele Sessions',
                type: 'basic',
                icon: 'mat_solid:voice_chat',
                link: '/telesessionstable'
            },
            {
                id: 'opdsessions',
                title: 'Opd Sessions',
                type: 'basic',
                icon: 'mat_solid:medication',
                link: '/opdsessionstable'
            },
           
           
            {
               id:'request',
               title:'Request',
               type:'basic',
               icon:'heroicons_outline:arrow-trending-up',
               link:'rquestSignUpPatients'
            },
           
             {
               id:'settings',
               title:'Settings',
               type:'basic',
               icon:'feather:settings',
               link:'settings'
            },
            
        );
    } else if (role === 2) { // User - Minimum Access
        navigation.push(
            {
                id: 'dashboard',
                title: 'Dashboard',
                type: 'basic',
                icon: 'mat_solid:dashboard',
                link: '/dashboard',
            },
            {
                id: 'selfrating',
                title: 'Self Rating',
                type: 'basic',
                icon: 'star_rate',
                link: '/selfrating'
            },           
            
            {
                id: 'audionotes',
                title: 'Audio Notes',
                type: 'basic',
                icon: 'mat_outline:audiotrack',
                link: '/audionotes'
            },
            {
                id: 'videonotes',
                title: 'Video Notes',
                type: 'basic',
                icon: 'heroicons_outline:video-camera',
                link: '/videonotes'
            },
            {
                id: 'telesessions',
                title: 'Tele Sessions',
                type: 'basic',
                icon: 'mat_solid:voice_chat',
                link: '/telesessions'
            },
            {
                id: 'opdsessions',
                title: 'Opd Sessions',
                type: 'basic',
                icon: 'mat_solid:medication',
                link: '/opdsessions'
            },
                      
            {
                id:'settings',
                title:'Settings',
                type:'basic',
                icon:'feather:settings',
                link:'settings'
             },
           

            
        );
    } else if (role === 3){
         
        navigation.push(
           
            {
                id: 'addAdmin',
                title: 'Add Admin',
                type: 'basic',
                icon: 'heroicons_mini:user-plus',
                link: '/addAdmin'
            },
          
        )
    
    }

    return navigation;
};
