import { Component, OnDestroy, OnInit, Pipe, ViewEncapsulation } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { ActivatedRoute, Router, RouterOutlet } from '@angular/router';
import { FuseFullscreenComponent } from '@fuse/components/fullscreen';
import { FuseLoadingBarComponent } from '@fuse/components/loading-bar';
import {
    FuseNavigationService,
    FuseVerticalNavigationComponent,
} from '@fuse/components/navigation';
import { FuseMediaWatcherService } from '@fuse/services/media-watcher';
import { NavigationService } from 'app/core/navigation/navigation.service';
import { Navigation } from 'app/core/navigation/navigation.types';
import { UserService } from 'app/core/user/user.service';
import { User } from 'app/core/user/user.types';
import { LanguagesComponent } from 'app/layout/common/languages/languages.component';
import { MessagesComponent } from 'app/layout/common/messages/messages.component';
import { NotificationsComponent } from 'app/layout/common/notifications/notifications.component';
import { QuickChatComponent } from 'app/layout/common/quick-chat/quick-chat.component';
import { SearchComponent } from 'app/layout/common/search/search.component';
import { ShortcutsComponent } from 'app/layout/common/shortcuts/shortcuts.component';
import { UserComponent } from 'app/layout/common/user/user.component';
import { pipe, Subject, takeUntil } from 'rxjs';
import { config } from '../../../../../../config';
import { SidebarService } from 'app/core/services/sidebar.service';
import { ApicontrollerService } from 'app/controller/apicontroller.service';


interface Doctor {
    doctor_email: string;
    doctor_gender: string;
    firstname: string;
    lastname:string;
    user_contact_number: string;
    user_password: string;
    row_id: string;
    photo_path:string;
  }
  
  interface Patient{
    patient_age: string;
    patient_email: string;
    patient_gender: string;
    patient_firstname:string;
    patient_lastname: string;
    user_password: string;
    user_contact_number: string;
    patient_name:string;
    photo_path:string;
    row_id:string;
  }

  interface Admin{
  firstname: string;
  email:string;
  lastname: string;
  gender: string;
  photo_path: string;
  user_contact_number: string;
  row_id:string;
}

@Component({
    selector: 'classy-layout',
    templateUrl: './classy.component.html',
    encapsulation: ViewEncapsulation.None,
    imports: [
        FuseLoadingBarComponent,
        FuseVerticalNavigationComponent,
        //NotificationsComponent,
        // UserComponent,
        MatIconModule,
        MatButtonModule,
       // LanguagesComponent,
        //FuseFullscreenComponent,
       // SearchComponent,
     //   ShortcutsComponent,
       // MessagesComponent,
        RouterOutlet,
        //QuickChatComponent,
           FuseLoadingBarComponent,
        MatButtonModule,
        MatIconModule,
       
        RouterOutlet,
        // QuickChatComponent,
        FuseVerticalNavigationComponent
    ],
})
export class ClassyLayoutComponent implements OnInit, OnDestroy {

    userDeatials: Doctor = {
        doctor_email: '',
        doctor_gender: '',
        firstname: '',
        lastname:'',
        user_contact_number: '',
        user_password: '',
        row_id: '',
        photo_path:''
      };
      role :any ='';
    
      patientDeatials: Patient = {
        patient_age: '',
      patient_email: '',
      patient_gender: '',
      patient_firstname:'',
      patient_lastname: '',
      user_password: '',
      user_contact_number: '',
      patient_name:'',
      photo_path:'',
      row_id:''
      };

           AdminDeatials: Admin = {
        firstname: '',
      lastname: '',
      email:'',
      gender: '',
      photo_path: '',
      user_contact_number: '',
      row_id:''
      };
      fnames :any = '';
      lnames :any = '';
      name:any = '';

    isScreenSmall: boolean;
    navigation: Navigation;
    user: User;
    private _unsubscribeAll: Subject<any> = new Subject<any>();

    urlSegments:any;
    profile_path:any;
    config:any;
    collapse:any = false;
researchersId:any;
    /**
     * Constructor
     */
    constructor(
        private _activatedRoute: ActivatedRoute,
        private _router: Router,
        private _navigationService: NavigationService,
        private _userService: UserService,
        private _fuseMediaWatcherService: FuseMediaWatcherService,
        private _fuseNavigationService: FuseNavigationService,
         public sidebarService: SidebarService,
            private route: ActivatedRoute,private Apicontroller: ApicontrollerService

         
     

    ) {

    this.researchersId = this.route.snapshot.paramMap.get('id');
        
        this.role = Number(localStorage.getItem('role')) || 0; // Convert role to a number
        this.collapse=  localStorage.getItem('collapse')

        this.config = config.apiBaseURL

    if(this.role==2){
      this.patientDeatials = JSON.parse(localStorage.getItem("userDeatials"));

      this.fnames = this.patientDeatials.patient_firstname
      this.lnames = this.patientDeatials.patient_lastname
      this.name = this.patientDeatials.patient_name
            this.profile_path = this.patientDeatials.photo_path
            this.userdata()

      
     

      //console.log("name--",name)

    }else if (this.role==1){
      
      this.userDeatials = JSON.parse(localStorage.getItem("userDeatials"));

      if ( this.userDeatials) {
        
            // this.fnames = this.userDeatials.firstname
            // this.lnames = this.userDeatials.lastname

            // this.profile_path = this.userDeatials.photo_path
            this.userdata()

      }else{
          this.fnames = localStorage.getItem("name")
      }
    
    }else if (this.role==0){
      
      this.AdminDeatials = JSON.parse(localStorage.getItem("userDeatials"));

      if ( this.AdminDeatials) {
        
            // this.fnames = this.AdminDeatials.firstname
            // this.lnames = this.AdminDeatials.lastname

            // this.profile_path = this.AdminDeatials.photo_path
            this.userdata()

      }else{
          this.fnames = localStorage.getItem("name")
      }
    
    }
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Accessors
    // -----------------------------------------------------------------------------------------------------

    /**
     * Getter for current year
     */
    get currentYear(): number {
        return new Date().getFullYear();
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void {
        // Subscribe to navigation data
        
               const savedCollapse = localStorage.getItem('sidebarCollapse');
        this.collapse = savedCollapse === 'true'; // Convert string to boolean

        this._navigationService.navigation$
            .pipe(takeUntil(this._unsubscribeAll))
            .subscribe((navigation: Navigation) => {
                this.navigation = navigation;
            });

        // Subscribe to the user service
        this._userService.user$
            .pipe(takeUntil(this._unsubscribeAll))
            .subscribe((user: User) => {
                this.user = user;
            });

        // Subscribe to media changes
        this._fuseMediaWatcherService.onMediaChange$
            .pipe(takeUntil(this._unsubscribeAll))
            .subscribe(({ matchingAliases }) => {
                // Check if the screen is small
                this.isScreenSmall = !matchingAliases.includes('md');
            });

           
            this.urlSegments = this._activatedRoute.snapshot.routeConfig.children[0].path;
            //  console.log('URL Segments:', this.urlSegments);
             
    }

    /**
     * On destroy
     */
    ngOnDestroy(): void {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next(null);
        this._unsubscribeAll.complete();
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * Toggle navigation
     *
     * @param name
     */
    toggleNavigation(name: string): void {
        // Get the navigation
        const navigation =
            this._fuseNavigationService.getComponent<FuseVerticalNavigationComponent>(
                name
            );

        if (navigation) {
            // Toggle the opened status
            navigation.toggle();
        }
    }

    logout(){
        this._router.navigate(['/sign-out']);

    }

    dashboard(){
    this._router.navigate(['/dashboard'])
}
Collapse(){
    this.collapse = !this.collapse;
    localStorage.setItem('sidebarCollapse', String(this.collapse));
    this.sidebarService.toggleCollapse();

 }

 admindata:any;

 async userdata(){

    if (this.role === 0) {
        const resp = await this.Apicontroller.fetchadmindetails('common/registration', this.AdminDeatials.row_id);
           this.admindata = resp.data as Admin
           this.profile_path = this.admindata[0].photo_path
             this.fnames = this.admindata[0].firstname
           this.lnames = this.admindata[0].lastname
        //    console.log("this.firstname --------",this.admindata )
    } else if(this.role === 1) {
         const resp = await this.Apicontroller.fetchResearcherdetails('common/registration', this.userDeatials.row_id);
           this.admindata = resp.data as Doctor
           this.profile_path = this.admindata[0].photo_path
           this.fnames = this.admindata[0].firstname
           this.lnames = this.admindata[0].lastname

           
        //    console.log("this.firstname -user_row_id-------",this.admindata )
    } else if(this.role === 2){
  const resp = await this.Apicontroller.fetchparticipatedetails('common', this.patientDeatials.row_id);
           this.admindata = resp.data as Patient
        //    console.log("data----",this.admindata,this.patientDeatials.row_id)
           this.profile_path = this.admindata[0].photo_path
           this.fnames = this.admindata[0].patient_firstname
           this.lnames = this.admindata[0].patient_lastname
    }
      
    
    }
}

