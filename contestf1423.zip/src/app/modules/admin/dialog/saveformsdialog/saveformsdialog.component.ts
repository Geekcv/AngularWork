import { Component, inject, Inject } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

@Component({
  selector: 'app-saveformsdialog',
  imports: [MatDialogModule,
    MatButtonModule, MatFormFieldModule, FormsModule,
        ReactiveFormsModule, MatInputModule, MatSelectModule,
        MatIconModule
  ],  templateUrl: './saveformsdialog.component.html',
  styleUrl: './saveformsdialog.component.scss'
})
export class SaveformsdialogComponent {

  private _snackBar = inject(MatSnackBar);

  formsname_value:any;
  row_id:any;
  tablename:any;
  formsID1:any
  formItems:any


  


 

  constructor(
    private Apicontroller: ApicontrollerService,
    @Inject(MAT_DIALOG_DATA) public data: {formItems:any},
        private dialogRef: MatDialogRef<SaveformsdialogComponent> // Inject MatDialogRef    
){


  // this.formsID1 = data.formsID
  this.formItems = data.formItems
}


// update forms table 


async saveforms(){

  const resp = await this.Apicontroller.createForms(this.formItems);
  var table_name = this.formsname_value


    const  table_name_resp = await this.Apicontroller.createTable(table_name);

    // console.log("table_name",table_name_resp)


  var data =[
    this.tablename = this.formsname_value,
    this.row_id = resp.row_id
  ]
  
  // console.log("d",data)
  
  const  update_formdata_resp = await this.Apicontroller.updateForms(data);
  
  // console.log("update forms",update_formdata_resp)

  if (update_formdata_resp.status === 0) {

    this._snackBar.open('Forms Saved', '', {
      duration: 3000, // Duration in milliseconds (3 seconds)
      verticalPosition: 'top', // Position: 'top' | 'bottom'
      horizontalPosition: 'center', // Position: 'start' | 'center' | 'end' | 'left' | 'right'
    });

    this.dialogRef.close();

    
  }
  
}


 

}
