// import { HttpClient } from '@angular/common/http';
// import { Component, Inject } from '@angular/core';
// import { FormsModule } from '@angular/forms';
// import { MatButtonModule } from '@angular/material/button';
// import { MatCardModule } from '@angular/material/card';
// import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
// import { MatIconModule } from '@angular/material/icon';
// import { MatInputModule } from '@angular/material/input';
// import { ApicontrollerService } from 'app/controller/apicontroller.service';
// import { config } from '../../../../../../../../config';
// import { ActivatedRoute, Router } from '@angular/router';

// interface Doctor {
//     doctor_email: string;
//     doctor_gender: string;
//     doctor_name: string;
//     user_contact_number: string;
//     user_password: string;
//     user_row_id: string;
//   }
  
//   interface Patient{
//     patient_age: string;
//     patient_email: string;
//     patient_gender: string;
//     patient_name: string;
//     user_password: string;
//     user_contact_number: string;
//   }



// @Component({
//   selector: 'app-upload',
//   imports: [MatDialogModule,
//     MatDialogModule,MatButtonModule
//         ,MatIconModule,MatInputModule,MatCardModule,FormsModule
//   ],
//   templateUrl: './upload.component.html',
//   styleUrl: './upload.component.scss'
// })
// export class UploadComponent {
//       file: any;
//   size: string = '';
//   file_name: any;
//   file_description: any;
//   patientsId!: string | null; 
//       names :any = '';

//      videodata: any;
//           media_link: any;
//           filename: string = '';
//           filepath: string = '';
//           mediatype: string = '';
//           config: string = config.apiBaseURL;
//           userDetails: Doctor | null = null;
//           patientDetails: Patient | null = null;

//               userDeatials: Doctor = {
//         doctor_email: '',
//         doctor_gender: '',
//         doctor_name: '',
//         user_contact_number: '',
//         user_password: '',
//         user_row_id: ''
//       };
//       role :any ='';
    
//       patientDeatials: Patient = {
//         patient_age: '',
//       patient_email: '',
//       patient_gender: '',
//       patient_name: '',
//       user_password: '',
//       user_contact_number: ''
//       };

//  constructor(
//         @Inject(MAT_DIALOG_DATA) public data: {medialink: string,mediadata:any},
//             private dialogRef: MatDialogRef<UploadComponent>, 
//     private http: HttpClient, private apiController: ApicontrollerService,private router: Router,  private route: ActivatedRoute, 

        
//     ){
//       console.log("mediadata",data.mediadata.pat_row_id)

// this.patientsId = data.mediadata.pat_row_id;

//       this.role=  localStorage.getItem('role')

//     if(this.role==2){
//       this.patientDeatials = JSON.parse(localStorage.getItem("userDeatials"));

//       this.names = this.patientDeatials.patient_name

     

//     }else{
      
//       this.userDeatials = JSON.parse(localStorage.getItem("userDeatials"));

//       this.names = this.userDeatials.doctor_name
//     }
     
//     }

//    onFileSelected(event: Event): void {
    
//     const input = event.target as HTMLInputElement;
//     if (input.files && input.files.length > 0) {

//       const files = Array.from(input.files); 

//       files.forEach((files) => {
//         this.file = input.files[0];
//         const formData = new FormData();
//         formData.append('file', this.file);

//         console.log("selected file", this.file)

//         this.file_name = this.file.name

//         input.value = ''

//       })


//     }
//     else {
//       console.warn('No files selected.');
//     }
//   }
//     exitbtn(){
//       this.dialogRef.close();
//     }

//      delaudiobtn() {
//     this.file = 0;
//     this.file_name = ''

//   }

  
//   uploadaudio() {

//     const formData = new FormData();
//     formData.append('file', this.file);

//     this.http.post(`${this.config}/common/upload`, formData).subscribe({
//       next: async (response: any) => {
//         if (response) {
//           this.filename = response.data.name;
//           this.filepath = response.data.foPa || response.data.filePath; 
//           this.mediatype = response.data.mimetype;
//           this.size = response.data.size;

//           console.log('Uploaded File:', this.filename, this.filepath, this.mediatype);

         
//           const data = {
//               receiver_row_id: this.patientsId,
//              file_name: this.filename,
//             file_path: this.filepath,
//             media_type: this.mediatype,
//             filename: this.file_name,
//             description: this.file_description,
//             filesize: this.size
//             };
//           try {
//             console.log("click this event before upload api hit 2",data)

//             const resp = await this.apiController.uploadmedia(data);
//             console.log("resp==",resp)

//             this.file_name = " ";
//             this.file_description = " "
//             this.file = 0

//             console.log("Upload Response:", resp);

//          this.dialogRef.close(resp.status);

           

//           } catch (error) {
//             console.error("Upload failed:", error);

//           }
//         } else {
//           console.log("Invalid server response")

//         }
//       },
//       error: (error) => {
//         console.error('Upload failed:', error);
//       },
//     });



//   }
// }


import { HttpClient } from '@angular/common/http';
import { Component, Inject } from '@angular/core';
import { FormsModule, ReactiveFormsModule, UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { config } from '../../../../../../../../config';
import { ActivatedRoute, Router } from '@angular/router';
import { MatSelectModule } from '@angular/material/select';
import { CommonModule, NgStyle } from '@angular/common';

interface Doctor {
    doctor_email: string;
    doctor_gender: string;
    doctor_name: string;
    user_contact_number: string;
    user_password: string;
    user_row_id: string;
  }
  
  interface Patient{
    patient_age: string;
    patient_email: string;
    patient_gender: string;
    patient_name: string;
    user_password: string;
    user_contact_number: string;
    patient_firstname:string;
    patient_lastname:string;
  }



@Component({
  selector: 'app-upload',
  imports: [MatDialogModule,
    MatDialogModule,MatButtonModule
        ,MatIconModule,MatInputModule,MatCardModule,FormsModule,MatSelectModule,NgStyle,ReactiveFormsModule
  ],
  templateUrl: './upload.component.html',
  styleUrl: './upload.component.scss'
})
export class UploadComponent {
      file: any;
  size: string = '';
  file_name: any;
  file_description: any;
  patientsId!: string | null; 
      names :any = '';
 signUpForm: UntypedFormGroup;
     videodata: any;
          media_link: any;
          filename: string = '';
          filepath: string = '';
          mediatype: string = '';
          config: string = config.apiBaseURL;
          userDetails: Doctor | null = null;
          patientDetails: Patient | null = null;

              userDeatials: Doctor = {
        doctor_email: '',
        doctor_gender: '',
        doctor_name: '',
        user_contact_number: '',
        user_password: '',
        user_row_id: ''
      };
      role :any ='';
    
      patientDeatials: Patient = {
        patient_age: '',
      patient_email: '',
      patient_gender: '',
      patient_name: '',
      user_password: '',
      user_contact_number: '',
      patient_firstname:'',
      patient_lastname:''
      };

  patients: Patient[] = [];
  selectedvalue:any;

 constructor(
            private dialogRef: MatDialogRef<UploadComponent>, 
    private http: HttpClient, private apiController: ApicontrollerService,private router: Router,  private route: ActivatedRoute, 
     private _formBuilder: UntypedFormBuilder

        
    ){
      // console.log("mediadata",data.mediadata.pat_row_id)

// this.patientsId = data.mediadata.pat_row_id;

this.mypatients()

      this.role=  localStorage.getItem('role')

    if(this.role==2){
      this.patientDeatials = JSON.parse(localStorage.getItem("userDeatials"));

      this.names = this.patientDeatials.patient_name

     

    }else{
      
      this.userDeatials = JSON.parse(localStorage.getItem("userDeatials"));

      this.names = this.userDeatials.doctor_name
    }
     
    }



  ngOnInit(): void {
       // Create the form
       this.signUpForm = this._formBuilder.group({
         participant:['',Validators.required],
        
       
       });
   }

    async mypatients() {
        try {
          const resp = await this.apiController.fetchPatients();

        
          //console.log("doctor", resp);
          this.patients = resp.data as Patient[]; // Type assert to Doctor[]
        } catch (error) {
          console.error("Error fetching doctors:", error);
        }
    
      }

   onFileSelected(event: Event): void {
    
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {

      const files = Array.from(input.files); 

      files.forEach((files) => {
        this.file = input.files[0];
        const formData = new FormData();
        formData.append('file', this.file);

        console.log("selected file", this.file)

        this.file_name = this.file.name

        input.value = ''

      })


    }
    else {
      console.warn('No files selected.');
    }
  }
    exitbtn(){
      this.dialogRef.close();
    }

     delaudiobtn() {
    this.file = 0;
    this.file_name = ''

  }

  
  uploadaudio() {

     if (this.signUpForm.invalid) {
        this.signUpForm.markAllAsTouched(); // Show validation messages
        return;
      }

    const formData = new FormData();
    formData.append('file', this.file);

    this.http.post(`${this.config}/common/upload`, formData).subscribe({
      next: async (response: any) => {
        if (response) {
          this.filename = response.data.name;
          this.filepath = response.data.foPa || response.data.filePath; 
          this.mediatype = response.data.mimetype;
          this.size = response.data.size;

          console.log('Uploaded File:', this.filename, this.filepath, this.mediatype);

         
          const data = {
              receiver_row_id: this.selectedvalue,
             file_name: this.filename,
            file_path: this.filepath,
            media_type: this.mediatype.slice(0,5),
            filename: this.file_name,
            description: this.file_description,
            filesize: this.size
            };
          try {
            console.log("click this event before upload api hit 2",data)

            const resp = await this.apiController.uploadmedia(data);
            console.log("resp==",resp)

            this.file_name = " ";
            this.file_description = " "
            this.file = 0

            console.log("Upload Response:", resp);

         this.dialogRef.close(resp.status);

           

          } catch (error) {
            console.error("Upload failed:", error);

          }
        } else {
          console.log("Invalid server response")

        }
      },
      error: (error) => {
        console.error('Upload failed:', error);
      },
    });



  }
}
