import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAudioComponent } from './view-audio.component';

describe('ViewChatComponent', () => {
  let component: ViewAudioComponent;
  let fixture: ComponentFixture<ViewAudioComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ViewAudioComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewAudioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
