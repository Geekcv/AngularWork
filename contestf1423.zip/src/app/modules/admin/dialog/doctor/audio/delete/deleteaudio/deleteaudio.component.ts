import { Component, Inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { DeldialogComponent } from 'app/modules/admin/dialog/deldialog/deldialog.component';

@Component({
  selector: 'app-deleteaudio',
  imports: [MatDialogModule,MatButtonModule,MatIconModule],
  templateUrl: './deleteaudio.component.html',
  styleUrl: './deleteaudio.component.scss'
})


export class DeleteaudioComponent {

  ID:any;


  constructor(
     @Inject(MAT_DIALOG_DATA) public data: {mediaData: any},
                private dialogRef: MatDialogRef<DeldialogComponent>, // Inject MatDialogRef   ,
                    private Apicontroller: ApicontrollerService
                
  ){
      console.log("media---",data.mediaData.media_row_id)
      this.ID = data.mediaData.media_row_id;

  }

async  deleteresponse(){
    console.log("delete this media ",this.ID)

    var data ={
      row_id:this.ID,
      deleted:1
    }

    console.log("data-->",data)

    const resp = await this.Apicontroller.softdelMedia(data);

    // console.log("resp------->",resp)


     this.dialogRef.close(resp);
    //  this.dialogRef.close();
  }

   exitbtn() {
      this.dialogRef.close();
  }

}