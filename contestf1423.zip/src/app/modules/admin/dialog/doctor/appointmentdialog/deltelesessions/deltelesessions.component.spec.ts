import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeltelesessionsComponent } from './deltelesessions.component';

describe('DeltelesessionsComponent', () => {
  let component: DeltelesessionsComponent;
  let fixture: ComponentFixture<DeltelesessionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DeltelesessionsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DeltelesessionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
