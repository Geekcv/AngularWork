import { Component, Inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { config } from '../../../../../../../../config';
import { NgStyle } from '@angular/common';

@Component({
  selector: 'app-view-chat',
   imports: [MatDialogModule,MatButtonModule,NgStyle],
  templateUrl: './view-video.component.html',
  styleUrl: './view-video.component.scss'
})
export class ViewVideoComponent {

  config: string = config.apiBaseURL;

 media_data:any;

  description:any;
  filename:any;
  time:any;
  filesize:any;
  media_link:any
  

 constructor(
         @Inject(MAT_DIALOG_DATA) public data: {medialink: string,mediadata:string},
             private dialogRef: MatDialogRef<ViewVideoComponent>, // Inject MatDialogRef   ,
     private Apicontroller: ApicontrollerService
 
         
     ){
     
      this.media_data = data.mediadata
      this.media_link = data.medialink

      console.log("media_link---------",data.medialink)
 
       this.description =this.media_data.description
        this.filename = this.media_data.filename
        this.time = this.media_data.time
        this.filesize = this.media_data.filesize
 
        console.log("media data----",data.mediadata)
     }

   exitbtn(){
  
      this.dialogRef.close();
  
    }

}
