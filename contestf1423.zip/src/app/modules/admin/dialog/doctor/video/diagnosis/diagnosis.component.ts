import { Component, Inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { config } from '../../../../../../../../config';
import { FormPreviewComponent } from 'app/modules/admin/formBuilder/components/form-preview/form-preview.component';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { NgStyle } from '@angular/common';

interface FormElement {
  type: string;
  label: string;
  placeholder?: string;
  rows?: any;
  cols?: any
  min?: any
  max?: any
  optionsdropdown?: Array<{ label: string, value: string }>;// Dropdown options,
  optionsradio?: Array<{ label: string, value: string }>;
  optionscheckbox?: Array<{ label: string, value: string }>
  layout?: 'vertical' | 'horizontal';
  required?: boolean;
  address?:any[];
  accept?:string;
  key?:any;
  searchText?:any;
  filteredOptions?:any;
    


}

interface FormsSchemaData {
  // forms_row_id:any;
  form_link: any;
}

@Component({
  selector: 'app-diagnosis',
  imports: [ MatDialogModule,MatButtonModule,FormPreviewComponent,NgStyle],
  templateUrl: './diagnosis.component.html',
  styleUrl: './diagnosis.component.scss'
})
export class DiagnosisComponent {

     formItems: FormElement[] = [];
      formsdata: FormsSchemaData[];
    
    
      tablename:string;
         config: string = config.apiBaseURL;
      
    media_data:any

      description:any;
  filename:any;
  time:any;
  filesize:any;
    
     constructor(
          @Inject(MAT_DIALOG_DATA) public data: {medialink: string,mediadata:any},
              private dialogRef: MatDialogRef<DiagnosisComponent>, // Inject MatDialogRef
                        private Apicontroller: ApicontrollerService
          
      ){
        this.showforms()
        this.media_data = data.mediadata

         this.filename = this.media_data.filename
       this.time = this.media_data.time
       this.filesize = this.media_data.filesize
    
      }
    
      exitbtn(){
    
        this.dialogRef.close();
    
      }
    
      async showforms(){
        console.log('show forms data');
    
        const resp = await this.Apicontroller.loadForms('diagnosisforms');
        console.log("resp", resp[0].form_data)
        this.formItems = resp[0].form_data;
    
      }
}
