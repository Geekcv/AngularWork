import { Component, Inject, inject, ViewChild } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { DeldialogComponent } from '../../dialog/deldialog/deldialog.component';
import { MatDialog } from '@angular/material/dialog';
import { AdddoctordialogComponent } from '../../dialog/adddoctordialog/adddoctordialog.component';
import { ActivePatientsComponent } from '../../dialog/active-patients/active-patients.component';
import { CommonModule, NgStyle } from '@angular/common';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { FormsModule } from '@angular/forms';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSnackBar } from '@angular/material/snack-bar';

interface Doctor {
  doctor_email: string;
  doctor_gender: string;
  firstname: string;
  lastname: string;
  user_contact_number:string;
  user_password:string;
  user_row_id:string;
  
}

interface Column {
  name: string; // The column name/key (must match MatTable's columnDef)
  label: string; // The displayed label for checkbox and header
  visible: boolean; // Whether this column is currently shown
}

 
@Component({
  selector: 'app-request-sign-updoctor',
 imports: [MatTableModule,MatPaginatorModule,MatButtonModule,
    MatIconModule,MatSortModule,
    MatInputModule,NgStyle,FormsModule,CommonModule,MatTooltipModule],
  templateUrl: './request-sign-updoctor.component.html',
  styleUrl: './request-sign-updoctor.component.scss'
})

export class RequestSignUpdoctorComponent { 
  role :any ='';
  // doctor: Doctor[] = [];

  doctor = new MatTableDataSource<Doctor>([]); // Use MatTableDataSource for pagination

  isSearchActive = false;
  isempty = false;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
      @ViewChild(MatSort) sort!: MatSort;

  // readonly dialogRef = inject(MatDialogRef<ViewresearchersComponent>);
  
    get displayedColumns(): string[] {
        return this.columns.filter((c) => c.visible).map((c) => c.name);
    }

  constructor(
    private Apicontroller: ApicontrollerService,
    private router: Router,
    private _matDialog: MatDialog
   
  ) { 

    this.role=  localStorage.getItem('role')

    // console.log("my role",this.role)
  }


    columns: Column[] = [
    { name: 'sr_no', label: 'Sr.No', visible: true },
    { name: 'firstname', label: 'First Name', visible: true },
    { name: 'lastname', label: 'Last Name', visible: true },

    { name: 'doctor_email', label: 'Email', visible: true },
    { name: 'user_contact_number', label: 'Phone', visible: true },
    
    { name: 'actions', label: 'Actions', visible: true },
  ];


  editRowId: number | null = null;

  editRow(rowId: number) {
    this.editRowId = rowId;
  }

  isRowEditing(rowId: any) {
    return this.editRowId === rowId;
  }






  async saveRow(row: any) {
    this.editRowId = null;
    try {
      const resp = await this.Apicontroller.updateDoctors('common', row);
      // console.log('doctors update data:', resp);
    } catch (error) {
      console.error('Error updating doctors:', error);
    }
  }

  cancelEdit() {
    this.editRowId = null;
  }

  ngOnInit(): void {
    // console.log(" ngOnInit")

    this.mydoctor();
  }
  
  ngAfterViewInit() {
    // console.log(" ngAfterViewInit")
    this.doctor.paginator = this.paginator; // Set paginator after view init
    this.doctor.sort = this.sort; // Set paginator after view init

  }

  page: number = 1; // Default to first page

  async mydoctor() {
    // console.log(" mydoctor")

    try {
      const resp = await this.Apicontroller.fetchDeactivedoctor('common',this.page);
      // console.log("doctor", resp);
      const data = resp.data as Doctor[];

       this.doctor.data = data.map((item, index) => ({
        ...item,
        sr_no: index + 1 + this.doctor.paginator.pageIndex * this.doctor.paginator.pageSize
      }));
  
      // Enable sorting for custom fields like user_row_id (extract numeric part)
      this.doctor.sortingDataAccessor = (item, property) => {
        if (property === 'user_row_id') {
          return Number(item.user_row_id?.split('_')[0]); // numeric part
        }
        return item[property];
      };
    } catch (error) {
      // console.error("Error fetching doctors:", error);
    }

  }


  viewDoctorDetails(doctor_rowId: string) {
    // console.log("viewdata",doctor_rowId)
    this.router.navigate(['researchersDetails', doctor_rowId]);
  }




  refresh(){
    // console.log("refresh----")
    this.mydoctor();
    // window.location.reload();
  }


  visibilitybtn(){
    // console.log("visibilitybtn .....")
  }
  

            private _snackBar = inject(MatSnackBar);
  
  approvebtn(user_row_id:any){

    
    const dialogRef = this._matDialog.open(ActivePatientsComponent,{ data: { patient: user_row_id  } });





        dialogRef.afterClosed().subscribe((result: any) => {
          console.log("res----------------->",result)
             if (result) {
                 this.mydoctor();            
               if (result.status === 0) {

        this._snackBar.open(result.msg, '', {
          duration: 4000,
          verticalPosition: 'top',
          horizontalPosition: 'center',
        });
      } else {
        this._snackBar.open(result.msg, '', {
          duration:4000,
          verticalPosition: 'top',
          horizontalPosition: 'center',
        });
      }
            }
        });

    
    // console.log("delete.....")
  }

  filterByQuery(query: string): void {
    const trimmedQuery = query.trim().toLowerCase();

    if (trimmedQuery) {
      this.isSearchActive = true;
      this.doctor.filter = trimmedQuery;

      if (this.doctor.paginator) {
        this.doctor.paginator.firstPage(); // Reset to first page after search
      }
    } else {
      this.isSearchActive = false;
      this.doctor.filter = ''; // Clear filter

      // Reset the paginator and restore original data
      setTimeout(() => {
        this.doctor.paginator = this.paginator;
      });
    }
  }


  
  
 
  
}