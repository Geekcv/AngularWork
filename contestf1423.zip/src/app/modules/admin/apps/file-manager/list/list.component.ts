import {
    ChangeDetectionStrategy,
    ChangeDetectorRef,
    Component,
    OnDestroy,
    OnInit,
    ViewChild,
    ViewEncapsulation,
} from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDrawer, MatSidenavModule } from '@angular/material/sidenav';
import { MatTooltipModule } from '@angular/material/tooltip';
import {
    ActivatedRoute,
    Router,
    RouterLink,
    RouterOutlet,
} from '@angular/router';
import { FuseMediaWatcherService } from '@fuse/services/media-watcher';
import { FileManagerService } from 'app/modules/admin/apps/file-manager/file-manager.service';
import {
    Item,
    Items,
} from 'app/modules/admin/apps/file-manager/file-manager.types';
import { Subject, takeUntil } from 'rxjs';

import { MatInputModule } from '@angular/material/input';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatDialog } from '@angular/material/dialog';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { DeleteaudioComponent } from 'app/modules/admin/dialog/doctor/audio/delete/deleteaudio/deleteaudio.component';
import { HistoryComponent } from 'app/modules/admin/dialog/doctor/audio/history/history.component';
import { FormulationComponent } from 'app/modules/admin/dialog/doctor/audio/formulation/formulation.component';
import { DiagnosisComponent } from 'app/modules/admin/dialog/doctor/audio/diagnosis/diagnosis.component';
import { RateComponent } from 'app/modules/admin/dialog/doctor/audio/rate/rate.component';
import { UploadComponent } from 'app/modules/admin/dialog/doctor/audio/upload/upload.component';

interface Patient {

  patient_age: string;
  patient_email: string;
  patient_gender: string;
  patient_name: string;
  user_contact_number: string;
  user_password: string;
  user_row_id: string;
}


interface mediaMetadata {
  date: string;
  description: string;
  doctor_name: string;
  filename: string;
  filesize: string;
  time: string;
  media_link: string;
  media_type: string;
  patient_name: string;
}

@Component({
    selector: 'file-manager-list',
    templateUrl: './list.component.html',
    encapsulation: ViewEncapsulation.None,
    changeDetection: ChangeDetectionStrategy.OnPush,
    imports: [
        MatSidenavModule,
        RouterOutlet,
        RouterLink,
        MatButtonModule,
        MatIconModule,
        MatTooltipModule,
        MatTableModule, MatButtonModule,
    MatIconModule, MatInputModule, MatPaginatorModule,MatSortModule,MatTooltipModule
    ],
})
export class FileManagerListComponent implements OnInit, OnDestroy {

    @ViewChild('matDrawer', { static: true }) matDrawer: MatDrawer;
    drawerMode: 'side' | 'over';
    selectedItem: Item;
    items: Items;
    private _unsubscribeAll: Subject<any> = new Subject<any>();

    /**
     * Constructor
     */

        
      
    constructor(
        private _activatedRoute: ActivatedRoute,
        private _changeDetectorRef: ChangeDetectorRef,
        private _router: Router,
        private _fileManagerService: FileManagerService,
        private _fuseMediaWatcherService: FuseMediaWatcherService,
          private Apicontroller: ApicontrollerService,
        private router: Router,
        private _matDialog: MatDialog
    ) {
          this.role = localStorage.getItem('role')
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void {
        // Get the items
          this.FetchAudioMedia();
        this._fileManagerService.items$
            .pipe(takeUntil(this._unsubscribeAll))
            .subscribe((items: Items) => {
                this.items = items;

                // Mark for check
                this._changeDetectorRef.markForCheck();
            });

        // Get the item
        this._fileManagerService.item$
            .pipe(takeUntil(this._unsubscribeAll))
            .subscribe((item: Item) => {
                this.selectedItem = item;

                // Mark for check
                this._changeDetectorRef.markForCheck();
            });

        // Subscribe to media query change
        this._fuseMediaWatcherService
            .onMediaQueryChange$('(min-width: 1440px)')
            .pipe(takeUntil(this._unsubscribeAll))
            .subscribe((state) => {
                // Calculate the drawer mode
                this.drawerMode = state.matches ? 'side' : 'over';

                // Mark for check
                this._changeDetectorRef.markForCheck();
            });
    }

    /**
     * On destroy
     */
    ngOnDestroy(): void {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next(null);
        this._unsubscribeAll.complete();
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * On backdrop clicked
     */
    onBackdropClicked(): void {
        // Go back to the list
        this._router.navigate(['./'], { relativeTo: this._activatedRoute });

        // Mark for check
        this._changeDetectorRef.markForCheck();
    }

    /**
     * Track by function for ngFor loops
     *
     * @param index
     * @param item
     */
    trackByFn(index: number, item: any): any {
        return item.id || index;
    }




     // patient: Patient[] = [];
      userrowId: any;
      audiomediadata: mediaMetadata[] = [];
    
      displayedColumns: string[] = [
        'user_row_id',
        'filename',
        'description',
        'filesize',
        'date',
        // 'doctor_name',
        'media_type',
        'patient_name',
        'actions'
      ];
    
    
      role: any = '';
    
      isSearchActive = false;
    
      audiodata = new MatTableDataSource<mediaMetadata>([]); // Use MatTableDataSource for pagination
    
    
      @ViewChild(MatPaginator) paginator!: MatPaginator;
          @ViewChild(MatSort) sort!: MatSort;
    
  
    
      ngAfterViewInit() {
        this.audiodata.paginator = this.paginator; // Set paginator after view init
        this.audiodata.sort = this.sort; // Set paginator after view init
    
      }
    
      page: number = 1; // Default to first page
      async FetchAudioMedia() {
        try {
          const data = {
            row_id: this.userrowId,
            media_type: 'audio/mpeg',
          };
    
          console.log("data",data)
    
          const resp = await this.Apicontroller.fetchmedia(data);
          console.log("audio media", resp);
          this.audiodata.data = resp.data as mediaMetadata[]; // Type assert to Doctor[]
        } catch (error) {
          console.error("Error fetching audio media:", error);
        }
    
      }
    
    
    
    
    
    
      filterByQuery(query: string): void {
        const trimmedQuery = query.trim().toLowerCase();
    
        if (trimmedQuery) {
          this.isSearchActive = true;
          this.audiodata.filter = trimmedQuery;
    
          if (this.audiodata.paginator) {
            this.audiodata.paginator.firstPage(); // Reset to first page after search
          }
        } else {
          this.isSearchActive = false;
          this.audiodata.filter = ''; // Clear filter
    
          // Reset the paginator and restore original data
          setTimeout(() => {
            this.audiodata.paginator = this.paginator;
          });
        }
      }
    
      exportToExcel(): void {
        const dataToExport = this.audiodata.data.map((audiodata) => ({
          Filename: audiodata.filename,
          Description: audiodata.description,
          Filesize: audiodata.filesize,
          Mediatype: audiodata.media_type,
          PatientName: audiodata.patient_name,
        }));
    
        const worksheet = XLSX.utils.json_to_sheet(dataToExport);
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, 'Doctors');
    
        const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
        const data = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    
        saveAs(data, 'Patients_List.xlsx');
      }
    
    
      refresh() {
        console.log("refresh----")
        this.FetchAudioMedia();
        // window.location.reload();
      }
    
      addpatientdialog() {
        // const dialogRef = this._matDialog.open(AddpatientdialogComponent);
      }
    
    
    
      deletebtn(media:any) {
        console.log("media id",media.media_row_id)
         const dialogRef = this._matDialog.open(DeleteaudioComponent, {
                data: { mediaData: media },
            });
        
    
        console.log("delete.....")
    
          dialogRef.afterClosed().subscribe((result: any) => {
              console.log("res----------------->",result)
                if (result) {
                this.FetchAudioMedia();
                   
                }
            });
      }
    
    
      viewaudioDetails(media_link: string) {
        console.log("viewAudiodetails----------", media_link)
        this.router.navigate(['viewAudiodetails', media_link]);
        // this.router.navigate(['patientpanel', patient_rowId]);          
      }
    
        historychatsdialogboxbtn(media:any) {
              const dialogRef = this._matDialog.open(HistoryComponent, { data: { medialink: media.media_link,mediadata:media } });
          
             }
    
             formulationdialogboxbtn(media:any) {
                 const dialogRef = this._matDialog.open(FormulationComponent, { data: { medialink: media.media_link,mediadata:media } });
             
               }
    
    
                diagnosisdialogboxbtn(media:any) {
                   const dialogRef = this._matDialog.open(DiagnosisComponent, { data: { medialink: media.media_link,mediadata:media } });
               
                 }
               
                 ratedialogboxbtn(media:any) {
                   const dialogRef = this._matDialog.open(RateComponent, { data: { medialink: media.media_link,mediadata:media } });
               
                 }
    
            //       uploadmediabtn(media:any) {
            //        const dialogRef = this._matDialog.open(UploadComponent, { data: { medialink: media.media_link,mediadata:media } });
    
            //            dialogRef.afterClosed().subscribe((result: any) => {
            //   console.log("res----------------->",result)
            //     if (result===0) {
            // this.FetchAudioMedia()               
            //     }
            // });
               
            //      }
    
                  uploadmediabtn() {
                //    const dialogRef = this._matDialog.open(UploadComponent,{position: { right: '1%' }});
    
            //            dialogRef.afterClosed().subscribe((result: any) => {
            //   console.log("res----------------->",result)
            //     if (result===0) {
            // this.FetchAudioMedia()               
            //     }
            // });
               
                 }
    
}
