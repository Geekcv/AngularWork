import { Injectable } from '@angular/core';
import { ApiService } from '../Services/api.service';

@Injectable({
  providedIn: 'root'
})
export class ApicontrollerService {

  constructor(private apiService: ApiService) { }

  async loginuser(logindata: any, url: string = 'common/registration') {
    const data = {
      "fn": "common_fn",
      "se": "lo_us",
      "data": logindata
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }

    async loginwithemail(email:any,url: string = 'common/registration') {
    const data = {
      "fn": "common_fn",
      "se": "log_with_email",
      "data": email
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }


  async createClient(clientdata: any, url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "cr_up",
      "data": clientdata
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }


  async fetchdoctor(url: string = 'common/registration',page: number = 1) {
    const data = {
      "fn": "common_fn",
      "se": "fe_docs",
      "data": {
        "limit": 100,
        page
      }
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }

    async fetchgroupdetails(url: string = 'common/registration',page: number = 1) {
    const data = {
      "fn": "common_fn",
      "se": "fe_docs",
      "data": {
        "limit": 100,
        page
      }
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }

    async fetchdoctordetails(url: string = 'common/registration',patientsrrow_id:any) {
    const data = {
      "fn": "common_fn",
      "se": "fe_sepefic_doc",
      "data": {row_id:patientsrrow_id}
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }
   async fetchDeactivedoctor(url: string = 'common',page: number = 1) {
    const data = {
      "fn": "common_fn",
      "se": "fe_docs_deactive",
      "data": {
        "limit": 100,
        page
      }
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }

  async createdoctor(doctordata: any,url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "si_up_doc",
      "data": doctordata
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }


    async createAdmin(admindata: any,url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "cr_admins",
      "data": admindata
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }

    async creategroup(groupdata: any,url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "cr_grop",
      "data": groupdata
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }

    async SignUpSelfdoctor(doctordata: any,url: string = 'common/registration') {
    const data = {
      "fn": "common_fn",
      "se": "si_up_doc_self",
      "data": doctordata
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }


  async fetchSefesficdoctor(doctorrow_id:string ,url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "fe_docs",
      "data": {row_id:doctorrow_id}
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }




  async fetchPatients(url: string = 'common',page: number = 1) {
    const data = {
      "fn": "common_fn",
      "se": "fe_pats",
      "data": {
        "limit": 100,
        page
      }
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
   // console.log(resp);
    return resp;
  }

   async fetchDeactivePatients(url: string = 'common',page: number = 1) {
    const data = {
      "fn": "common_fn",
      "se": "fe_pats_deactive",
      "data": {
        "limit": 100,
        page
      }
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
   // console.log(resp);
    return resp;
  }


  async AddPatients(Patientsdata: any,url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "si_up_pat",
      "data": Patientsdata
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }


   async updatePatients(url: string = 'common',Patientsdata: any) {
    const data = {
      "fn": "common_fn",
      "se": "up_pat",
      "data": Patientsdata
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }

     async updateDoctors(url: string = 'common',doctordata: any) {
    const data = {
      "fn": "common_fn",
      "se": "up_doc_data",
      "data": doctordata
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }



  
  async SignUpSelfPatients(Patientsdata: any,url: string = 'common/registration') {
    const data = {
      "fn": "common_fn",
      "se": "si_up_pat_self",
      "data": Patientsdata
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }

  

  async fetchSefesficpatients(patientsrrow_id:string ,url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "fe_pats",
      "data": {row_id:patientsrrow_id}
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }


  async fetchpatientsdetails(patientsrrow_id:string ,url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "fe_spefic_pats",
      "data": {row_id:patientsrrow_id}
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }

  async appointment(appointmentdata: any,url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "cr_apt",
      "data": appointmentdata
    };

   // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
   // console.log(resp);
    return resp;
  }

  async opdAppointment(appointmentdata:any,url:string ='common'){
    const data ={
      "fn":"common_fn",
      "se":"cr_opd",
      "data":appointmentdata
    };

    const resp:any = await this.apiService.postUrl(data,url)
    return resp;
  }

  // async opdappointment(appointmentdata: any,url: string = 'common') {
  //   const data = {
  //     "fn": "common_fn",
  //     "se": "cr_opd_apt",
  //     "data": appointmentdata
  //   };

  //  // console.log(data)
  //   const resp: any = await this.apiService.postUrl(data, url);
  //  // console.log(resp);
  //   return resp;
  // }
  


  async fetchappointment(url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "fe_apt_pats",
      "data": ""
    };

  //  console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
  //  console.log(resp);
    return resp;
  }

    async fetchTeleappointment(url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "fe_tele_apoint",
      "data": ""
    };

  //  console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
  //  console.log(resp);
    return resp;
  }

  async requestappintment(appointmentdata:any,url:string='common'){
    const data = {
      "fn": "common_fn",
      "se": "req_apt",
      "data": appointmentdata
    };

  //  console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
  //  console.log(resp);
    return resp;
  }

  async requestOpdappintment(appointmentdata:any,url:string='common'){
    const data = {
      "fn": "common_fn",
      "se": "req_opd_apt",
      "data": appointmentdata
    };

  //  console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
  //  console.log(resp);
    return resp;
  }


  async fetchappointmentdoctor(appdata:any,url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "fe_apt_docs",
      "data": {pat_row_id:appdata}
    };

   // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
   // console.log(resp);
    return resp;
  }

   async fetchOpdappointmentdoctor(appdata:any,url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "fe_opd_apt_docs",
      "data": {pat_row_id:appdata}
    };

   // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
   // console.log(resp);
    return resp;
  }

    async fetchopdappointmentPatients(url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "fe_opd_apt",
      "data": ""
    };

   // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
   // console.log(resp);
    return resp;
  }

     async fetchopdappointment(url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "fe_opd_docs",
      "data": ""
    };

   // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
   // console.log(resp);
    return resp;
  }


  async uploadmedia(mediadata:any,url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "up_media",
      "data": mediadata
    };

    //console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    //console.log(resp);
    return resp;
  }

    async fetchmedia(mediadata:any,url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "fe_media",
      "data": mediadata
    };

    //console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    //console.log(resp);
    return resp;
  }

   async uploadmediatelepsychiatrySessions(mediadata:any,url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "up_tel_ses",
      "data": mediadata
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }

    async uploadmediaInpersonSessions(mediadata:any,url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "up_inperson",
      "data": mediadata
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }


  
  async updateAppointment(statusdata:any,url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "up_apt",
      "data": statusdata
    };

    //console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    //console.log(resp);
    return resp;
  }

  async updateOpdAppointment(statusdata:any,url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": " up_opd_apt",
      "data": statusdata
    };

    //console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    //console.log(resp);
    return resp;
  }

  async showFormresponseCount(formsId: any, url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "show_forms_res_count",
      "data": formsId
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }


  async showFormresponse(formdata: any, url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "show_forms_res",
      "data": formdata
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }

  

  async createTable(tablename: any, url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "cr_for_ta",
      "data": tablename
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }

  async createForms(formsSchema: any, url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "cr_forms",
      "data": formsSchema
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }


  async updateForms(updateforms: any, url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": " up_forms",
      "data": updateforms
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }


  async SaveForms(formsdata: any, url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "sa_forms_data",
      "data": formsdata
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }


  async loadForms(formsId: any, url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": "load_forms",
      "data": {row_id:formsId}
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }



  async loadallForms(url: string = 'common') {
    const data = {
      "fn": "common_fn",
      "se": " load_allForms",
      "data": ""
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }


  async fetchuserMedia(pat_row_id:any,url:string= 'common'){
    const data ={
      "fn":"common_fn",
      "se":"fe_media_of_user",
      "data":{pat_row_id}
    }

    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }

    async fetchMediadata(mediaData:any,url:string= 'common'){
    const data ={
      "fn":"common_fn",
      "se":"fe_mediadata",
      "data":{mediaData}
    }

    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }

   async fetchteleSessionMedia(pat_row_id:any,url:string= 'common'){
    const data ={
      "fn":"common_fn",
      "se":"fe_tel_ses",
      "data":{pat_row_id}
    }

    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }

    async fetchInpersonSessionMedia(pat_row_id:any,url:string= 'common'){
    const data ={
      "fn":"common_fn",
      "se":"fe_inperson",
      "data":{pat_row_id}
    }

    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }


  async deletedoctor(delvalue:any,url:string ='common'){
    const data ={
      "fn":"common_fn",
      "se":" del_doc",
      "data":{delvalue}
    }

    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }

  

  async fetchPatientsByAdmin(url: string = 'common',page: number = 1) {
    const data = {
      "fn": "common_fn",
      "se": "fe_pats_by_ad",
      "data": {
        "limit": 100,
        page
      }
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
   // console.log(resp);
    return resp;
  }


  async softdelPatient(delvalue:any,url:string ='common'){
   const data ={
    "fn":"common_fn",
    "se":"del_pat",
    "data":{
      delvalue
    }
   }

  //  console.log("data befor",data);
   const resp:any = await this.apiService.postUrl(data,url)
  //  console.log("data after",data);

   return resp;
  }

  async softdelMedia(delvalue:any,url:string ='common'){
   const data ={
    "fn":"common_fn",
    "se":"del_media",
    "data":{
      delvalue
    }
   }

  //  console.log("data befor",data);
   const resp:any = await this.apiService.postUrl(data,url)
  //  console.log("data after",data);

   return resp;
  }

  async softdelTeleSession(delvalue:any,url:string ='common'){
   const data ={
    "fn":"common_fn",
    "se":"del_teleappoint",
    "data":{
      delvalue
    }
   }

  //  console.log("data befor",data);
   const resp:any = await this.apiService.postUrl(data,url)
  //  console.log("data after",data);

   return resp;
  }

    async softdelOpdSession(delvalue:any,url:string ='common'){
   const data ={
    "fn":"common_fn",
    "se":"del_opdappoint",
    "data":{
      delvalue
    }
   }

  //  console.log("data befor",data);
   const resp:any = await this.apiService.postUrl(data,url)
  //  console.log("data after",data);

   return resp;
  }
  async updatePatientProfile(profiledata:any,url:string='common'){
    const data = {
      "fn": "common_fn",
      "se": "up_pat",
      "data": profiledata
    };

    //console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    //console.log(resp);
    return resp;
  }

   async updateDoctorProfile(profiledata:any,url:string='common'){
    const data = {
      "fn": "common_fn",
      "se": "up_doc",
      "data": profiledata
    };

    //console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    //console.log(resp);
    return resp;
  }

     async updateAdminProfile(profiledata:any,url:string='common'){
    const data = {
      "fn": "common_fn",
      "se": "up_admin_profile",
      "data": profiledata
    };

    //console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    //console.log(resp);
    return resp;
  }

   async updateResearcherProfile(profiledata:any,url:string='common'){
    const data = {
      "fn": "common_fn",
      "se": "up_researchers_profile",
      "data": profiledata
    };

    //console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    //console.log(resp);
    return resp;
  }

     async updateParticipantProfile(profiledata:any,url:string='common'){
    const data = {
      "fn": "common_fn",
      "se": "up_participate_profile",
      "data": profiledata
    };

    //console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    //console.log(resp);
    return resp;
  }


    async fetchadmindetails(url: string = 'common/registration',patientsrrow_id:any) {
    const data = {
      "fn": "common_fn",
      "se": "fe_sepefic_Admin",
      "data": {row_id:patientsrrow_id}
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }

     async fetchResearcherdetails(url: string = 'common/registration',patientsrrow_id:any) {
    const data = {
      "fn": "common_fn",
      "se": "fe_sepefic_researchers",
      "data": {row_id:patientsrrow_id}
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }

      async fetchparticipatedetails(url: string = 'common',patientsrrow_id:any) {
    const data = {
      "fn": "common_fn",
      "se": "fe_sepefic_participate",
      "data": {row_id:patientsrrow_id}
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }

     async chnagePassword(userdata:any,url:string='common'){
    const data = {
      "fn": "common_fn",
      "se": " ch_pass",
      "data": userdata
    };

    // console.log(data)
    const resp: any = await this.apiService.postUrl(data, url);
    // console.log(resp);
    return resp;
  }

}


