import { CommonModule, NgIf, NgStyle } from '@angular/common';
import { Component, inject, ViewChild } from '@angular/core';
import {
    FormsModule,
    NgForm,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatTooltipModule } from '@angular/material/tooltip';
import { ActivatedRoute, Router } from '@angular/router';
import { FuseDrawerComponent } from '@fuse/components/drawer';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

interface Chapter {
    row_id: string;
    name: string;
}

interface Column {
    name: string; // The column name/key (must match MatTable's columnDef)
    label: string; // The displayed label for checkbox and header
    visible: boolean; // Whether this column is currently shown
}

interface SchoolAdmin {
    email: string;
    role: string;
    name: string;
    row_id: string;
    school_id: string;
}

@Component({
    selector: 'app-subject-details',
    imports: [
        MatTableModule,
        MatPaginatorModule,
        MatButtonModule,
        MatIconModule,
        MatInputModule,
        NgStyle,
        MatTooltipModule,
        MatSortModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatSelectModule,
        CommonModule,
        FormsModule,
        NgIf,
        //FuseDrawerComponent,
    ],
    templateUrl: './subject-details.component.html',
    styleUrl: './subject-details.component.scss',
})
export class SubjectDetailsComponent {
    ChapterData = new MatTableDataSource<Chapter>([]); // Use MatTableDataSource for pagination
    @ViewChild(MatPaginator) paginator!: MatPaginator;

    @ViewChild('addchapterNgForm') addchapterNgForm: NgForm;

    @ViewChild(MatSort) sort!: MatSort;

    private _snackBar = inject(MatSnackBar);

    addchapterForm: UntypedFormGroup;

    // classData:any;
    isSearchActive = false;
    classId: any;
    subjectID: any;

    SchoolAdminDeatials: SchoolAdmin = {
        email: '',
        name: '',
        role: '',
        row_id: '',
        school_id: '',
    };

    constructor(
        private Apicontroller: ApicontrollerService,
        private router: Router,
        private route: ActivatedRoute,
        private _formBuilder: UntypedFormBuilder
    ) {
        this.classId = this.route.snapshot.paramMap.get('classid');
        this.subjectID = this.route.snapshot.paramMap.get('id');

        this.SchoolAdminDeatials = JSON.parse(
            localStorage.getItem('userDeatials')
        );

        this.fetchchapter(this.subjectID);
    }

    ngOnInit(): void {
        this.addchapterForm = this._formBuilder.group({
            chaptername: ['', Validators.required],
        });
    }

    get displayedColumns(): string[] {
        return this.columns.filter((c) => c.visible).map((c) => c.name);
    }

    columns: Column[] = [
        { name: 'sr_no', label: 'Sr.No', visible: true },
        { name: 'name', label: 'Chapter Name', visible: true },
        { name: 'actions', label: 'Actions', visible: true },
    ];

    editRowId: number | null = null;

    editRow(rowId: number) {
        this.editRowId = rowId;
    }

    isRowEditing(rowId: any) {
        return this.editRowId === rowId;
    }

    async completedbtn(row: any) {
      try {
          const updatedChapter = {
              row_id: row.row_id,
              name: row.name,
              is_completed: !row.is_completed, //  Mark as completed
              completed_by: null
          };
  
          const resp = await this.Apicontroller.createorEditSchoolOwnSubjectofChapter(
              updatedChapter,
              'common'
          );
  
          const msg = resp?.msg || 'Unknown response';
  
          this._snackBar.open(msg, '', {
              duration: 3000,
              verticalPosition: 'top',
              horizontalPosition: 'center',
            });
        this.fetchchapter(this.subjectID);

  
      } catch (error) {
          console.error('Error marking chapter completed:', error);
          this._snackBar.open('Something went wrong!', '', {
              duration: 4000,
              verticalPosition: 'top',
              horizontalPosition: 'center',
          });
      }
  }
  

    cancelEdit() {
        this.editRowId = null;
    }

    ngAfterViewInit() {
        // console.log(" ngAfterViewInit")
        this.ChapterData.paginator = this.paginator; // Set paginator after view init
        this.ChapterData.sort = this.sort;
    }

    goback() {
        this.router.navigate(['/myclassdetails', this.classId]);
    }

    viewSubjectbtn(rowId: string) {
        this.router.navigate(['mysubjectdetails', rowId]);
    }

    async fetchchapter(subjectId: any) {
        try {
            console.log('inside fetch chpater', subjectId);

            const resp = await this.Apicontroller.fetchSubjectChapter(
                'common',
                subjectId
            );
            //  this.classData.data = resp
            console.log('chapter data ------------------>', resp);

            const data = resp as Chapter[];

            this.ChapterData.data = data.map((item, index) => ({
                ...item,
                sr_no:
                    index +
                    1 +
                    this.ChapterData.paginator.pageIndex *
                        this.ChapterData.paginator.pageSize,
            }));

            console.log('chapter-----', this.ChapterData);

            // Enable sorting for custom fields like user_row_id (extract numeric part)
            this.ChapterData.sortingDataAccessor = (item, property) => {
                if (property === 'row_id') {
                    return Number(item.row_id?.split('_')[0]); // numeric part
                }
                return item[property];
            };
        } catch (error) {
            // console.error("Error fetching doctors:", error);
        }
    }

    refresh() {
        this.fetchchapter(this.subjectID);
    }
}
