import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

@Component({
  selector: 'app-show-chapter',
  imports: [],
  templateUrl: './show-chapter.component.html',
  styleUrl: './show-chapter.component.scss'
})
export class ShowChapterComponent {

    page: number = 1;

     constructor(
        private Apicontroller: ApicontrollerService,
        private router: Router,

    ) {
      this.fetchschooldata()
    }

    async  fetchschooldata() {
     console.log(" before data")
 
     try {
       const resp = await this.Apicontroller.fetchSchoolData('common',this.page);
       console.log("school data ------------------>", resp);
     
 
 
     } catch (error) {
       // console.error("Error fetching doctors:", error);
     }
 
   }

}
