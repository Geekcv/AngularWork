import { Routes } from '@angular/router';
import { AddQuestionComponent } from './add-question.component';

export default [
    {
        path: '',
        component: AddQuestionComponent,
    },
] as Routes;
