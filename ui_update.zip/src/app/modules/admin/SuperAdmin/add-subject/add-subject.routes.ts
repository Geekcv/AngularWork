import { Routes } from '@angular/router';
import { AddSubjectComponent } from './add-subject.component';

export default [
    {
        path: '',
        component: AddSubjectComponent,
    },
] as Routes;
