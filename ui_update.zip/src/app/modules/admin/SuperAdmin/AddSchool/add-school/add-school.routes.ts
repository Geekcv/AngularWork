import { Routes } from '@angular/router';
import { AddSchoolComponent } from './add-school.component';

export default [
    {
        path: '',
        component: AddSchoolComponent,
    },
] as Routes;
