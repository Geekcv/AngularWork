import { HttpClient } from '@angular/common/http';
import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatDialogModule } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatDrawerToggleResult } from '@angular/material/sidenav';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { FileManagerService } from 'app/modules/admin/apps/file-manager/file-manager.service';
import { Item } from 'app/modules/admin/apps/file-manager/file-manager.types';
import { FileManagerListComponent } from 'app/modules/admin/apps/file-manager/list/list.component';
import { Subject } from 'rxjs';
import { config } from '../../../../../../../config';

interface Doctor {
    doctor_email: string;
    doctor_gender: string;
    doctor_name: string;
    user_contact_number: string;
    user_password: string;
    user_row_id: string;
}

interface Patient {
    patient_age: string;
    patient_email: string;
    patient_gender: string;
    patient_name: string;
    user_password: string;
    user_contact_number: string;
}

interface mediaMetadata {
    date: string;
    description: string;
    doctor_name: string;
    filename: string;
    filesize: string;
    time: string;
    media_link: string;
    media_type: string;
    patient_name: string;
}

@Component({
    selector: 'file-manager-details',
    templateUrl: './details.component.html',
    // encapsulation: ViewEncapsulation.None,
    // changeDetection: ChangeDetectionStrategy.OnPush,
    imports: [
        MatButtonModule,
        RouterLink,
        MatIconModule,
        MatDialogModule,
        MatDialogModule,
        MatButtonModule,
        MatIconModule,
        MatInputModule,
        MatCardModule,
        FormsModule,
        MatSelectModule,
    ],
})
export class FileManagerDetailsComponent implements OnInit, OnDestroy {
    item: Item;
    private _unsubscribeAll: Subject<any> = new Subject<any>();
    userrowId: any;

    /**
     * Constructor
     */

    constructor(
        private http: HttpClient,
        private apiController: ApicontrollerService,
        private router: Router,
        private route: ActivatedRoute,
        private _changeDetectorRef: ChangeDetectorRef,
        private _fileManagerListComponent: FileManagerListComponent,
        private _fileManagerService: FileManagerService,
        private Apicontroller: ApicontrollerService
    ) {
        // console.log("mediadata",data.mediadata.pat_row_id)

        // this.patientsId = data.mediadata.pat_row_id;

        this.mypatients();

        this.role = localStorage.getItem('role');

        if (this.role == 2) {
            this.patientDeatials = JSON.parse(
                localStorage.getItem('userDeatials')
            );

            this.names = this.patientDeatials.patient_name;
        } else {
            this.userDeatials = JSON.parse(
                localStorage.getItem('userDeatials')
            );

            this.names = this.userDeatials.doctor_name;
        }
    }
    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void {
        // Open the drawer
        this._fileManagerListComponent.matDrawer.open();

        // Get the item
    }

    /**
     * On destroy
     */
    ngOnDestroy(): void {
        // Unsubscribe from all subscriptions
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * Close the drawer
     */
    closeDrawer(): Promise<MatDrawerToggleResult> {
        return this._fileManagerListComponent.matDrawer.close();
    }

    /**
     * Track by function for ngFor loops
     *
     * @param index
     * @param item
     */
    trackByFn(index: number, item: any): any {
        return item.id || index;
    }

    audiodata = new MatTableDataSource<mediaMetadata>([]); // Use MatTableDataSource for pagination

    file: any;
    size: string = '';
    file_name: any;
    file_description: any;
    patientsId!: string | null;
    names: any = '';

    videodata: any;
    media_link: any;
    filename: string = '';
    filepath: string = '';
    mediatype: string = '';
    config: string = config.apiBaseURL;
    userDetails: Doctor | null = null;
    patientDetails: Patient | null = null;

    userDeatials: Doctor = {
        doctor_email: '',
        doctor_gender: '',
        doctor_name: '',
        user_contact_number: '',
        user_password: '',
        user_row_id: '',
    };
    role: any = '';

    patientDeatials: Patient = {
        patient_age: '',
        patient_email: '',
        patient_gender: '',
        patient_name: '',
        user_password: '',
        user_contact_number: '',
    };

    patients: Patient[] = [];
    selectedvalue: any;

    async FetchAudioMedia() {
        try {
            const data = {
                row_id: this.userrowId,
                media_type: 'audio/mpeg',
            };

            console.log('data', data);

            const resp = await this.Apicontroller.fetchmedia(data);
            console.log('audio media', resp);
            this.audiodata.data = resp.data as mediaMetadata[]; // Type assert to Doctor[]
        } catch (error) {
            console.error('Error fetching audio media:', error);
        }
    }

    async mypatients() {
        try {
            const resp = await this.apiController.fetchPatients();

            //console.log("doctor", resp);
            this.patients = resp.data as Patient[]; // Type assert to Doctor[]
        } catch (error) {
            console.error('Error fetching doctors:', error);
        }
    }

    selectedFiles: { file: File; customName: string }[] = [];

    onFileSelected(event: Event): void {
        const input = event.target as HTMLInputElement;
        if (input.files && input.files.length > 0) {
            const newFiles = Array.from(input.files).map((file) => ({
                file,
                customName: '' // default blank, user will edit
            }));
            this.selectedFiles.push(...newFiles);
            input.value = '';
        } else {
            console.warn('No files selected.');
        }
    }
    
    exitbtn() {}

    delaudiobtn() {
        this.file = 0;
        this.file_name = '';
    }

    removeFile(index: number): void {
      this.selectedFiles.splice(index, 1);
  }
  
  uploadaudio(): void {
    if (!this.selectedFiles.length) {
        alert('Please select audio file(s).');
        return;
    }

    if (!this.selectedvalue) {
        alert('Please select a patient.');
        return;
    }

    const formData = new FormData();
    this.selectedFiles.forEach((item) => {
        formData.append('files', item.file);
    });

    this.http.post(`${this.config}/common/upload`, formData).subscribe({
        next: async (response: any) => {
            if (response?.data?.length) {
                for (let i = 0; i < response.data.length; i++) {
                    const fileResp = response.data[i];
                    const uploadedFile = this.selectedFiles[i];

                    // ✅ Use customName if provided, else use original file name
                    const finalFileName = uploadedFile.customName?.trim()
                        ? uploadedFile.customName.trim()
                        : uploadedFile.file.name;

                    const mediaData = {
                        receiver_row_id: this.selectedvalue,
                        file_name: finalFileName,
                        file_path: fileResp.foPa || fileResp.filePath,
                        media_type: fileResp.mimetype,
                        filename: finalFileName,
                        description: this.file_description || '',
                        filesize: fileResp.size,
                    };

                    try {
                        await this.apiController.uploadmedia(mediaData);
                    } catch (error) {
                        console.error('Metadata upload failed:', error);
                    }
                }

                this.selectedFiles = [];
                this.file_description = '';
                this._fileManagerListComponent.FetchAudioMedia();
                alert('All audio files uploaded successfully!');
            } else {
                console.error('Unexpected response:', response);
            }
        },
        error: (err) => {
            console.error('Upload error:', err);
            alert('Upload failed');
        },
    });
}

    
}
