import { Component, Inject, inject, ViewChild } from '@angular/core';
import { NgForm, ReactiveFormsModule, UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { FuseAlertType } from '@fuse/components/alert';
import { ApicontrollerService } from 'app/controller/apicontroller.service';


@Component({
  selector: 'app-edit-patients-info',
  imports: [
      MatDialogModule, MatButtonModule, ReactiveFormsModule, MatFormFieldModule,
        MatInputModule, MatButtonModule, MatIconModule, MatCheckboxModule,
        MatProgressSpinnerModule, MatSelectModule
  ],
  templateUrl: './edit-patients-info.component.html',
  styleUrl: './edit-patients-info.component.scss'
})
export class EditPatientsInfoComponent {
  @ViewChild('signUpNgForm') signUpNgForm: NgForm;
  
  alert: { type: FuseAlertType; message: string } = {
    type: 'success',
    message: '',
  };

  signUpForm: UntypedFormGroup;
  showAlert: boolean = false;
  role: any = '';
  patientsId:any;
  patients:any

  genders: string[] = ['Male', 'Female', 'Other']; // List of genders

  private _snackBar = inject(MatSnackBar);

  constructor(
    private _formBuilder: UntypedFormBuilder,
    private _router: Router,
    private Apicontroller: ApicontrollerService,
      @Inject(MAT_DIALOG_DATA) public data: {patient: any},
    private dialogRef: MatDialogRef<EditPatientsInfoComponent> // Inject MatDialogRef
  ) {
    this.role = localStorage.getItem('role');
    // this.patientsId = data.patient;
    this.patients = data.patient;

  }

  ngOnInit(): void {
    this.signUpForm = this._formBuilder.group({
      patient_name:[this.patients.patient_name],
      patient_age: [this.patients.patient_age],
      patient_email: [this.patients.patient_email, [Validators.required, Validators.email]],
      user_contact_number: [this.patients.user_contact_number, Validators.required],
      user_password: [this.patients.user_password, Validators.required],
      patient_gender: [this.patients.patient_gender, Validators.required],
      user_row_id: [this.patients.user_row_id ],

    });
  }

    

  async updatePatients() {

    // console.log("patientsId ------>",this.patientsId)
    // console.log("patientsId ------>",this.patients)

    // console.log("join ", this.signUpForm.value + this.patientsId)
    // const data ={
    //      userdata:this.signUpForm.value,
    //      patientsId:this.patientsId
    // }
    const resp = await this.Apicontroller.updatePatientProfile(this.signUpForm.value);

    if (resp.status === 0) {
      this._snackBar.open(resp.msg, '', {
        duration: 3000, // Duration in milliseconds (3 seconds)
        verticalPosition: 'top', // Position: 'top' | 'bottom'
        horizontalPosition: 'center', // Position: 'start' | 'center' | 'end' | 'left' | 'right'
      });
      
      // Close the dialog after successful doctor creation
      this.dialogRef.close();

      // Redirect to View Researchers
      // this._router.navigate(['/Viewresearchers']);
    } else {
      console.log("Error: ", resp.msg);
    }
  }

}
