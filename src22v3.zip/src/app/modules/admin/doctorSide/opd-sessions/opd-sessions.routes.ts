import { Routes } from '@angular/router';
import { OpdSessionsComponent } from 'app/modules/admin/doctorSide/opd-sessions/opd-sessions.component';

export default [
    {
        path: '',
        component: OpdSessionsComponent,
    },
] as Routes;
