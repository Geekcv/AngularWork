import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddopdsessionComponent } from './addopdsession.component';

describe('AddopdsessionComponent', () => {
  let component: AddopdsessionComponent;
  let fixture: ComponentFixture<AddopdsessionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddopdsessionComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddopdsessionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
