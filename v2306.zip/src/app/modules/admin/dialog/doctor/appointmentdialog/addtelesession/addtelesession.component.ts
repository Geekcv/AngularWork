import { CommonModule, NgStyle } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatTimepickerModule } from '@angular/material/timepicker';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

interface Patient {
  patient_age: string;
  patient_email: string;
  patient_gender: string;
  patient_name: string;
  user_password: string;
  user_contact_number: string;
}

interface appointment {
  apt_row_id: string;
  date_of_apt: string;
  // date_of_req:string;
  doctor_name: string;
  user_contact_number: string;
  time_of_apt: string;
  // time_of_req:string;
  appointment_details: any;
  // appointment_details:{appt_status:any,appt_type:any,virtual_link:any};
  // updatedby_user_name:any
}

@Component({
  selector: 'app-addtelesession',
  imports: [MatDialogModule, MatButtonModule, MatIconModule, MatSelectModule, FormsModule
    , MatDatepickerModule, NgStyle, MatTimepickerModule, CommonModule
  ],
  templateUrl: './addtelesession.component.html',
  styleUrl: './addtelesession.component.scss'
})
export class AddtelesessionComponent {

  selectedvalue: any;
  patients: Patient[] = [];
  selectedDate: any;
  app_type: string = '';
  appointmentdata: appointment[] = [];
  selectedTime: string;
  patientsId!: string | null; // Holds the patientsId ID from the route
  patientdata: any;
    formateddateStr:any;


  timeSlots: string[] = [
    '09:00 AM',
    '10:00 AM',
    '11:00 AM',
    '12:00 PM',
    '01:00 PM',
    '02:00 PM',
    '03:00 PM',
    '04:00 PM',
     '05:00 PM']; // Ensure this has values

  availableslot: string[] = ['Physical', 'Virtual'];

  bookedDateMap: { [key: string]: string[] } = {}; // slot times mapped to dates
  isAppointmentsLoaded: boolean = false;
  availableTimeSlots: string[] = [];
  bookedTimeSlots: string[] = [];

  constructor(private apiController: ApicontrollerService,
    private dialogRef: MatDialogRef<AddtelesessionComponent>
  ) {
    this.mypatients()
  }

   selectTime(slot: string) {
        console.log('Selected Slot:--', slot,  "selectedDate---" + this.selectedDate);
         this.selectedDate = this.toLocalDateOnly(this.selectedDate);
           this.formateddateStr = this.selectedDate.toDateString();
        console.log("selectedDate-----",this.formateddateStr)
        this.selectedTime = slot;
    }



  async mypatients() {
    try {
      const resp = await this.apiController.fetchPatients();


      //console.log("doctor", resp);
      this.patients = resp.data as Patient[]; // Type assert to Doctor[]
    } catch (error) {
      console.error("Error fetching doctors:", error);
    }

  }

  onPatientChange() {
    console.log("onPatientChange")
    if (this.selectedvalue) {
      this.patientdata = this.selectedvalue;
      console.log("onPatientChange", this.selectedvalue, this.patientdata)

      this.viewappointment(); // now reload appointments
    }
  }

  async requestAppointment() {
    // console.log("time value-",this.timevalue.toTimeString().split(' ')[0], "date value-",this.datevalue.toDateString())

    console.log("selected patients", this.selectedvalue)

    var data = {
      pat_row_id: this.selectedvalue,
      time_of_apt: this.selectedTime,
      date_of_apt: this.formateddateStr,
      appt_type: this.app_type
    }

    console.log("before appointment data", data)
    const resp = await this.apiController.appointment(data);
    console.log("response--->", data)

    this.refresh();
    this.dialogRef.close(resp);


  }

  refresh() {
    console.log("refresh----")
    this.viewappointment();
    // window.location.reload();
  }

  async viewappointment() {
    const resp1 = await this.apiController.fetchappointmentdoctor(this.selectedvalue);
    this.appointmentdata = resp1.data || []

    for (const apt of this.appointmentdata) {
      const d = this.toLocalDateOnly(apt.date_of_apt);
      if (isNaN(d.getTime())) continue;

      const dateStr = d.toDateString();
      const formattedTime = this.formatTime(apt.time_of_apt);

      if (!this.bookedDateMap[dateStr]) {
        this.bookedDateMap[dateStr] = [];
      }
      this.bookedDateMap[dateStr].push(formattedTime);
    }


    console.log("view patients appointments resp ", resp1)
  }


  exitbtn() {
    this.dialogRef.close();
  }

  dateClass = (date: any): string => {
    const d = this.toLocalDateOnly(date);
    const str = d.toDateString();
    if (this.bookedDateMap[str]) {
      console.log('Highlighting date:', str);
      return 'booked-date';
    }
    return '';
  };

  toLocalDateOnly(dateInput: any): Date {
    const d = new Date(dateInput);
    return new Date(d.getFullYear(), d.getMonth(), d.getDate()); // strips time + timezone
  }

  trackBySlot(index: number, item: string): string {
    return item;
  }

  formatTime(rawTime: string): string {
    const [hourStr, minuteStr] = rawTime.split(':');
    let hour = parseInt(hourStr, 10);
    const minutes = minuteStr?.padStart(2, '0') || '00';

    const ampm = hour >= 12 ? 'PM' : 'AM';
    hour = hour % 12 || 12;

    return `${hour.toString().padStart(2, '0')}:${minutes} ${ampm}`;
  }

  onDateChange(date: any): void {
    const d = this.toLocalDateOnly(date);
    this.selectedDate = d;

    const dateStr = d.toDateString();
    console.log(' Date changed to:', dateStr);
    console.log(
      ' Booked slots for this date:',
      this.bookedDateMap[dateStr]
    );

    this.bookedTimeSlots = this.bookedDateMap?.[dateStr] || [];

    this.availableTimeSlots = this.timeSlots.filter(
      (slot) => !this.bookedTimeSlots.includes(slot)
    );
  }
}
