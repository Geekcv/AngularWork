import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DelOpdsessionsComponent } from './del-opdsessions.component';

describe('DelOpdsessionsComponent', () => {
  let component: DelOpdsessionsComponent;
  let fixture: ComponentFixture<DelOpdsessionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DelOpdsessionsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DelOpdsessionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
