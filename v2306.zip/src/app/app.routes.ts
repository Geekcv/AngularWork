import { Route } from '@angular/router';
import { initialDataResolver } from 'app/app.resolvers';
import { AuthGuard } from 'app/core/auth/guards/auth.guard';
import { NoAuthGuard } from 'app/core/auth/guards/noAuth.guard';
import { LayoutComponent } from 'app/layout/layout.component';

import { authGuard } from 'app/Services/auth.guard';
import { EmailVerifyComponent } from './modules/admin/email-verify/email-verify.component';

// @formatter:off
/* eslint-disable max-len */
/* eslint-disable @typescript-eslint/explicit-function-return-type */
export const appRoutes: Route[] = [

    // Redirect empty path to '/example'
    {path: '', pathMatch : 'full', redirectTo: 'sign-in'},
    // { path: '', component: EmailVerifyComponent },


    // Redirect signed-in user to the '/example'
    //
    // After the user signs in, the sign-in page will redirect the user to the 'signed-in-redirect'
    // path. Below is another redirection for that path to redirect the user to the desired
    // location. This is a small convenience to keep all main routes together here on this file.
    {path: 'signed-in-redirect', pathMatch : 'full', redirectTo: 'example'},

    // Auth routes for guests
    {
        path: '',
        // canActivate: [AuthGuard],
        // canActivateChild: [AuthGuard],
        component: LayoutComponent,
        data: {
            layout: 'empty'
        },
        children: [
            {path: 'confirmation-required', loadChildren: () => import('app/modules/auth/confirmation-required/confirmation-required.routes')},
            {path: 'forgot-password', loadChildren: () => import('app/modules/auth/forgot-password/forgot-password.routes')},
            {path: 'reset-password', loadChildren: () => import('app/modules/auth/reset-password/reset-password.routes')},
            {path: 'sign-in', loadChildren: () => import('app/modules/auth/sign-in/sign-in.routes')},
            {path: 'sign-up', loadChildren: () => import('app/modules/auth/sign-up/sign-up.routes')},
            {path: 'patient-sign-up', loadChildren: () => import('app/modules/auth/sign-up-user/Patient/patient-sign-up/patient-sign-up.routes')},
            {path: 'researcher-sign-up', loadChildren: () => import('app/modules/auth/sign-up-user/Researcher/researcher-sign-up/researcher-sign-up.routes')}


        ]
    },

    

    // Auth routes for authenticated users
    {
        path: '',
        // canActivate: [AuthGuard],
        // canActivateChild: [AuthGuard],
        component: LayoutComponent,
        data: {
            layout: 'empty'
        },
        children: [
            {path: 'sign-out', loadChildren: () => import('app/modules/auth/sign-out/sign-out.routes')},
            {path: 'unlock-session', loadChildren: () => import('app/modules/auth/unlock-session/unlock-session.routes')}
        ]
    },

    // Landing routes
    {
        path: '',
        component: LayoutComponent,
        data: {
            layout: 'empty'
        },
        children: [
            {path: 'home', loadChildren: () => import('app/modules/landing/home/home.routes')},
        ]
    },

    // Admin routes
    {
        path: '',
        // canActivate: [AuthGuard],
        // canActivateChild: [AuthGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver
        },
        children: [
            {path: 'example', loadChildren: () => import('app/modules/admin/example/example.routes')},
        ]
    },




     // test routes
     {
        path: '',
        // canActivate: [AuthGuard],
        // canActivateChild: [AuthGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver
        },
        children: [
            {path: 'test', loadChildren: () => import('app/modules/admin/test/test.routes')},
        ]
    },

    // test routes
    {
        path: '',
        // canActivate: [AuthGuard],
        // canActivateChild: [AuthGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver
        },
        children: [
            {path: 'common/email/verify', loadChildren: () => import('app/modules/admin/email-verify/email-verify.routes')},
        ]
    },




     // dashbord routes
     {
        path: '',
        canActivate: [authGuard],
        canActivateChild: [authGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver
        },
        children: [
            {path: 'dashboard', loadChildren: () => import('app/modules/admin/dashboard/dashboard.routes')},
        ]
    },



     // Viewresearchers routes
     {
        path: '',
        canActivate: [authGuard],
        canActivateChild: [authGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver
        },
        children: [
            {path: 'Viewresearchers', loadChildren: () => import('app/modules/admin/adminSide/viewresearchers/viewresearchers.routes')},
        ]
    },


    // Addresearchers routes
    {
        path: '',
        canActivate: [authGuard],
        canActivateChild: [authGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver
        },
        children: [
            {path: 'Addresearchers', loadChildren: () => import('app/modules/admin/adminSide/addresearchers/addresearchers.routes')},
        ]
    },









    
    





    // viewpatients routes
    {
        path: '',
        canActivate: [authGuard],
        canActivateChild: [authGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver
        },
        children: [
            {path: 'Viewpatients', loadChildren: () => import('app/modules/admin/doctorSide/viewpatients/viewpatients.routes')},
        ]
    },





    
    // ResearchersDetailsComponent routes
    {
        path: '',
        canActivate: [authGuard],
        canActivateChild: [authGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver
        },
        children: [
            {path: 'researchersDetails/:id', loadChildren: () => import('app/modules/admin/adminSide/researchers-details/researchers-details.routes')},
        ]
    },


    // Addpatients routes
    {
        path: '',
        canActivate: [authGuard],
        canActivateChild: [authGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver
        },
        children: [
            {path: 'Addpatients', loadChildren: () => import('app/modules/admin/doctorSide/addpatients/addpatients.routes')},
        ]
    },




    // appointment routes
    {
        path: '',
        canActivate: [authGuard],
        canActivateChild: [authGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver
        },
        children: [
            {path: 'appointment', loadChildren: () => import('app/modules/admin/doctorSide/appointment/appointment..routes')},
        ]
    },


     // my appointment routes
     {
        path: '',
        canActivate: [authGuard],
        canActivateChild: [authGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver
        },
        children: [
            {path: 'myappointment', loadChildren: () => import('app/modules/admin/patientSide/show-myappointment/show-myappointment.routes')},
        ]
    },



     // uploadmedia routes
     {
        path: '',
        canActivate: [authGuard],
        canActivateChild: [authGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver
        },
        children: [
            {path: 'uploadmedia', loadChildren: () => import('app/modules/admin/patientSide/uploadmedia/uploadmedia.routes')},
        ]
    },


      // appointmentdetails routes
      {
        path: '',
        canActivate: [authGuard],
        canActivateChild: [authGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver
        },
        children: [
            {path: 'appointmentdetails/:appid/:id', loadChildren: () => import('app/modules/admin/patientSide/appointment-details/appointment-details.routes')},
        ]
    },




//   audio-notes routes
      {
        path: '',
        canActivate: [authGuard],
        canActivateChild: [authGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver
        },
        children: [
            {path: 'audionotes', loadChildren: () => import('app/modules/admin/patientSide/audio-notes/audio-notes.routes')},
        ]
    },


    
//   video-notes routes
{
    path: '',
    canActivate: [authGuard],
    canActivateChild: [authGuard],
    component: LayoutComponent,
    resolve: {
        initialData: initialDataResolver
    },
    children: [
        {path: 'videonotes', loadChildren: () => import('app/modules/admin/patientSide/video-notes/video-notes.routes')},
    ]
},


   
//   tele sessions routes
{
    path: '',
    canActivate: [authGuard],
    canActivateChild: [authGuard],
    component: LayoutComponent,
    resolve: {
        initialData: initialDataResolver
    },
    children: [
        {path: 'telesessions', loadChildren: () => import('app/modules/admin/patientSide/tele-sessions/tele-sessions.routes')},
    ]
},



//   opd sessions routes
{
    path: '',
    canActivate: [authGuard],
    canActivateChild: [authGuard],
    component: LayoutComponent,
    resolve: {
        initialData: initialDataResolver
    },
    children: [
        {path: 'opdsessions', loadChildren: () => import('app/modules/admin/patientSide/opd-sessions/opd-sessions.routes')},
    ]
},



//   self rating routes
{
    path: '',
    canActivate: [authGuard],
    canActivateChild: [authGuard],
    component: LayoutComponent,
    resolve: {
        initialData: initialDataResolver
    },
    children: [
        {path: 'selfrating', loadChildren: () => import('app/modules/admin/patientSide/self-rating/self-rating.routes')},
    ]
},


// account setting 

{
    path: '',
    canActivate: [authGuard],
    canActivateChild: [authGuard],
    component: LayoutComponent,
    resolve: {
        initialData: initialDataResolver
    },
    children: [
        {path: 'settings', loadChildren: () => import('app/modules/pages/settings/settings.routes')},
    ]
},


// patient panel 

{
    path: '',
    canActivate: [authGuard],
    canActivateChild: [authGuard],
    component: LayoutComponent,
    resolve: {
        initialData: initialDataResolver
    },
    children: [
        {path: 'patientpanel/:id', loadChildren: () => import('app/modules/pages/patientPanel/patientPanel.routes')},
    ]
},


// audionotestable route

{
    path: '',
    canActivate: [authGuard],
    canActivateChild: [authGuard],
    component: LayoutComponent,
    resolve: {
        initialData: initialDataResolver
    },
    children: [
        {path: 'audionotestable', loadChildren: () => import('app/modules/admin/doctorSide/audio-notes/audio-notes.routes')},
    ]
},


// videonotestable route


{
    path: '',
    canActivate: [authGuard],
    canActivateChild: [authGuard],
    component: LayoutComponent,
    resolve: {
        initialData: initialDataResolver
    },
    children: [
        {path: 'videonotestable', loadChildren: () => import('app/modules/admin/doctorSide/video-notes/video-notes.routes')},
    ]
},


// opdsessionstable route

{
    path: '',
    canActivate: [authGuard],
    canActivateChild: [authGuard],
    component: LayoutComponent,
    resolve: {
        initialData: initialDataResolver
    },
    children: [
        {path: 'opdsessionstable', loadChildren: () => import('app/modules/admin/doctorSide/opd-sessions/opd-sessions.routes')},
    ]
},

// telesessionstable route


{
    path: '',
    canActivate: [authGuard],
    canActivateChild: [authGuard],
    component: LayoutComponent,
    resolve: {
        initialData: initialDataResolver
    },
    children: [
        {path: 'telesessionstable', loadChildren: () => import('app/modules/admin/doctorSide/telepsychiatry-sessions/telepsychiatry-sessions.routes')},
    ]
},


// addpatients route


{
    path: '',
    canActivate: [authGuard],
    canActivateChild: [authGuard],
    component: LayoutComponent,
    resolve: {
        initialData: initialDataResolver
    },
    children: [
        {path: 'addpatients', loadChildren: () => import('app/modules/admin/adminSide/addpatients/addpatients.routes')},
    ]
},


// viewpatients route


{
    path: '',
    canActivate: [authGuard],
    canActivateChild: [authGuard],
    component: LayoutComponent,
    resolve: {
        initialData: initialDataResolver
    },
    children: [
        {path: 'viewpatients', loadChildren: () => import('app/modules/admin/adminSide/viewpatients/viewpatients.routes')},
    ]
},


// viewAudiodetails route


{
    path: '',
    canActivate: [authGuard],
    canActivateChild: [authGuard],
    component: LayoutComponent,
    resolve: {
        initialData: initialDataResolver
    },
    children: [
        {path: 'viewAudiodetails/:id', loadChildren: () => import('app/modules/admin/doctorSide/view-audiodetails/view-audiodetails.routes')},
    ]
},

// viewVideodetails route


{
    path: '',
    canActivate: [authGuard],
    canActivateChild: [authGuard],
    component: LayoutComponent,
    resolve: {
        initialData: initialDataResolver
    },
    children: [
        {path: 'viewVideodetails/:id', loadChildren: () => import('app/modules/admin/doctorSide/view-videodetails/view-videodetails.routes')},
    ]
},

// viewTeleSessionsdetails route


{
    path: '',
    canActivate: [authGuard],
    canActivateChild: [authGuard],
    component: LayoutComponent,
    resolve: {
        initialData: initialDataResolver
    },
    children: [
        {path: 'viewTeleSessionsdetails/:id', loadChildren: () => import('app/modules/admin/doctorSide/view-tele-sessionsdetails/view-tele-sessionsdetails.routes')},
    ]
},

// viewOpdSessionsdetails route


{
    path: '',
    canActivate: [authGuard],
    canActivateChild: [authGuard],
    component: LayoutComponent,
    resolve: {
        initialData: initialDataResolver
    },
    children: [
        {path: 'viewOpdSessionsdetails/:id', loadChildren: () => import('app/modules/admin/doctorSide/view-opd-sessionsdetails/view-opd-sessionsdetails.routes')},
    ]
},



{
    path: '',
    canActivate: [authGuard],
    canActivateChild: [authGuard],
    component: LayoutComponent,
    resolve: {
        initialData: initialDataResolver
    },
    children: [
        {path: 'appointmentpatient', loadChildren: () => import('app/modules/admin/patientSide/appointment/appointment.routes')},
    ]
},



{
    path: '',
    canActivate: [authGuard],
    canActivateChild: [authGuard],
    component: LayoutComponent,
    resolve: {
        initialData: initialDataResolver
    },
    children: [
        {path: 'formsdesign', loadChildren: () => import('app/modules/admin/formBuilder/forms-builder/forms-builder.routes')},
    ]
},

{
    path:'',
    canActivate:[authGuard],
    canActivateChild:[authGuard],
    component:LayoutComponent,
    resolve:{
        initialData:initialDataResolver
    },
    children:[
        {path:'response',loadChildren:()=>import('app/modules/admin/formBuilder/response/response.component.routes')}
    ]
}
,


{
    path: '',
    canActivate: [authGuard],
    canActivateChild: [authGuard],
    component: LayoutComponent,
    resolve: {
        initialData: initialDataResolver
    },
    children: [
        {path: 'formpreview', loadChildren: () => import('app/modules/admin/formBuilder/form-priview/form-priview.component.routes')},
    ]
},

{
        path: '',
        // canActivate: [AuthGuard],
        // canActivateChild: [AuthGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver
        },
        children: [
            {path: 'rquestSignUpdoctor', loadChildren: () => import('app/modules/admin/adminSide/request-sign-updoctor/request-sign-updoctor.routes')},
        ]
    },

    
{
        path: '',
        // canActivate: [AuthGuard],
        // canActivateChild: [AuthGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver
        },
        children: [
            {path: 'rquestSignUpPatients', loadChildren: () => import('app/modules/admin/doctorSide/request-sign-up-patients/request-sign-up-patients.routes')},
        ]
    },

       
{
        path: '',
        // canActivate: [AuthGuard],
        // canActivateChild: [AuthGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver
        },
        children: [
                    {path: 'file-manager', loadChildren: () => import('app/modules/admin/apps/file-manager/file-manager.routes')},

        ]
    },


];
