import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowExamQuestionComponent } from './show-exam-question.component';

describe('ShowExamQuestionComponent', () => {
  let component: ShowExamQuestionComponent;
  let fixture: ComponentFixture<ShowExamQuestionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ShowExamQuestionComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShowExamQuestionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
