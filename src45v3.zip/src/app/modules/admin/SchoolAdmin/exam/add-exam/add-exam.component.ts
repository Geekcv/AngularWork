import { HttpClient } from '@angular/common/http';
import { Component, inject, ViewChild } from '@angular/core';
import {
    FormsModule,
    NgForm,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectChange, MatSelectModule } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { config } from '../../../../../../../config';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core'; // For native date adapter
import dashboardRoutes from 'app/modules/admin/dashboard/dashboard.routes';
import { CommonModule } from '@angular/common';
import { MatDialog } from '@angular/material/dialog';
import { SelectquestionBySchoolComponent } from '../selectQuestiondialog/selectquestion.component';

interface ChapterData {
    chapter_id: string;
    chapter_name: string;
}


interface Teacher{
  email: string;
  name:string;
  row_id:string;
  role:string;
}

interface SchoolAdmin {
    email: string;
    role: string;
    name: string;
    row_id: string;
    school_id:string
  }


@Component({
  selector: 'app-add-exam',
  imports: [FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatCheckboxModule,
    MatProgressSpinnerModule,
    MatSelectModule,MatDatepickerModule,MatNativeDateModule,CommonModule,                  
  ],
  templateUrl: './add-exam.component.html',
  styleUrl: './add-exam.component.scss'
})

export class AddExamComponent {
  @ViewChild('examNgForm') examNgForm: NgForm;

  examForm: UntypedFormGroup;
  showAlert = false;
  role: any = '';
  config: any;

  chapterList = []

  
  TeacherDeatials: Teacher = {
    email: '',
    name:'',
    row_id:'',
    role:''
    };

      SchoolAdminDeatials: SchoolAdmin = {
    email: '',
    name: '',
    role: '',
    row_id: '',
    school_id: ''
  };

    
  chapter_id:any;
  question_set:any;
  slelected_question :any  = 0;
  class_id:any;
  subject_id:any;
  teacher_id:any;

  constructor(
      private _formBuilder: UntypedFormBuilder,
      private _router: Router,
      private api: ApicontrollerService,
      private _matDialog: MatDialog,
  ) {
      this.config = config.apiBaseURL;
      this.role = localStorage.getItem('role');
    this.TeacherDeatials = JSON.parse(localStorage.getItem("userDeatials"));
    this.SchoolAdminDeatials = JSON.parse(localStorage.getItem("userDeatials"));

 this.fetchCompletedChapter();
//  this.fetchquestion()

    }

  private _snackBar = inject(MatSnackBar);

  ngOnInit(): void {
    this.examForm = this._formBuilder.group({     
      //chapter_id: ['', Validators.required],
      name: ['', Validators.required],
      total_marks: [null],
      passing_marks: [null],
      duration_minutes: [null],
      scheduled_on: [null],
    });
    
  }

  // boardList = [
  //     { row_id: '1729833318838_Ir5A', name: 'CBSE' },
  //     { row_id: '1729862517377_iMzd', name: 'RBSE' },
  // ];


  async submitExam(): Promise<void> {
      if (this.examForm.invalid) {
          this.examForm.markAllAsTouched();
          return;
      }

      const payload = {
          ...this.examForm.value,created_by:this.teacher_id,
           chapter_id:this.chapter_id,question_set:this.question_set,
           class_id:this.class_id,subject_id:this.subject_id,school_id:this.SchoolAdminDeatials.school_id
      };

      console.log("paylaod---",payload)
      const resp = await this.api.addExam(payload);
      console.log("resp---",resp)

      if (resp.status === 0) {
          this._snackBar.open(resp.msg, '', {
              duration: 3000,
              verticalPosition: 'top',
              horizontalPosition: 'center',
          });

          this.examNgForm.resetForm();
          this.slelected_question = 0
      } else {
          this._snackBar.open(resp.msg || 'Failed to add chapter', '', {
              duration: 3000,
              verticalPosition: 'top',
              horizontalPosition: 'center',
          });
      }
  }

       async fetchCompletedChapter() {

        var data = {
          "teacher_id":this.TeacherDeatials.row_id
        }

        const resp = await this.api.fetchAllcompletedChapter(
            'common',
            data
        );
        this.chapterList = resp.data as ChapterData[];
    }

    async fetchquestion (){
       const resp = await this.api.fetchAllquestionOfchapter(
            'common',
            '1753766673964_U9RB'
        );

        console.log("fetch question ----->",resp)
    }

    

    

    selectQuestion(){
      const dialogRef = this._matDialog.open(SelectquestionBySchoolComponent);

      dialogRef.afterClosed().subscribe((result: any) => {
        console.log("res----------------->",result)
          if (result) {
           console.log("chapter_id--",result.chapter_id) 
           console.log("question_set--",result.questiondid)  
           this.chapter_id = result.chapter_id;
           this.question_set = result.questiondid;
           this.subject_id = result.subject_id
           this.class_id = result.class_id
           this.teacher_id = result.teacher_id

           console.log("slected question set",this.question_set.length)
            this.slelected_question = this.question_set.length
            
          }
      });

    }
}