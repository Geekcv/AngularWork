import { Component, inject, ViewChild } from '@angular/core';
import {
    FormsModule,
    NgForm,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { config } from '../../../../../../config';
import { FuseDrawerComponent } from '@fuse/components/drawer';
import { CommonModule, NgStyle } from '@angular/common';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';

  interface Column {
  name: string; // The column name/key (must match MatTable's columnDef)
  label: string; // The displayed label for checkbox and header
  visible: boolean; // Whether this column is currently shown
}

interface Board {
    row_id:string;
  name:string;
}


@Component({
  selector: 'app-add-board',
  imports: [
     FormsModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatInputModule,
        MatButtonModule,
        MatIconModule,
        MatCheckboxModule,
        MatProgressSpinnerModule,
        MatSelectModule,
        FuseDrawerComponent,
        NgStyle,
          MatTableModule,
                        MatPaginatorModule,
                     
                        NgStyle , MatTooltipModule, MatSortModule,
                      
                            CommonModule,
                                    
                        
                                     
  ],
  templateUrl: './add-board.component.html',
  styleUrl: './add-board.component.scss'
})
export class AddBoardComponent {
   @ViewChild('boardNgForm') boardNgForm: NgForm;

  boardForm: UntypedFormGroup;
  config:any;
  role:any;

  isSearchActive = false;
    boardData = new MatTableDataSource<Board>([]); // Use MatTableDataSource for pagination
     @ViewChild(MatPaginator) paginator!: MatPaginator;
       @ViewChild(MatSort) sort!: MatSort;
  

   constructor(
        private _formBuilder: UntypedFormBuilder,
        private _router: Router,
        private api: ApicontrollerService,
    ) {
        this.config = config.apiBaseURL;
        this.role = localStorage.getItem('role');
        this.fetchallboard()
    }
  
    private _snackBar = inject(MatSnackBar);
  
    ngOnInit(): void {
        this.boardForm = this._formBuilder.group({
            name: ['', Validators.required],         
        });
    }
  

       get displayedColumns(): string[] {
    return this.columns.filter((c) => c.visible).map((c) => c.name);
  }
 

  
    async addBoard(addboard:any): Promise<void> {
        if (this.boardForm.invalid) {
            this.boardForm.markAllAsTouched();
            return;
        }
  
        const payload = {
            ...this.boardForm.value,
        };
  
        // pending to create add board
        const resp = await this.api.createboard(payload);
  
        if (resp.status === 0) {
            this._snackBar.open(resp.msg, '', {
                duration: 3000,
                verticalPosition: 'top',
                horizontalPosition: 'center',
            });
  
            this.boardNgForm.resetForm();
            addboard.close()
        this.fetchallboard()

        } else {
            this._snackBar.open(resp.msg || 'Failed to add board', '', {
                duration: 3000,
                verticalPosition: 'top',
                horizontalPosition: 'center',
            });
        }
    }


           columns: Column[] = [
    { name: 'sr_no', label: 'Sr.No', visible: true },
    { name: 'name', label: 'Board Name', visible: true },
   
    { name: 'actions', label: 'Actions', visible: true },


  ];


  async fetchallboard() {
    console.log(" before data")

    try {
     const resp = await this.api.fetchallBoard();

      const data = resp as Board[];

      console.log("board data",data)

      // Add sr_no for each row (based on pagination if needed)
      this.boardData.data = data.map((item, index) => ({
        ...item,
        sr_no: index + 1 + this.boardData.paginator.pageIndex * this.boardData.paginator.pageSize
      }));

      console.log("boardata.data ------------------>", this.boardData.data);


      // Enable sorting for custom fields like user_row_id (extract numeric part)
      this.boardData.sortingDataAccessor = (item, property) => {
        if (property === 'row_id') {
          return Number(item.row_id?.split('_')[0]); // numeric part
        }
        return item[property];
      };



    } catch (error) {
      // console.error("Error fetching doctors:", error);
    }

  }

    ngAfterViewInit() {
    // console.log(" ngAfterViewInit")
    this.boardData.paginator = this.paginator; // Set paginator after view init
    this.boardData.sort = this.sort

  }

   editRowId: number | null = null;

  editRow(rowId: number) {
    this.editRowId = rowId;
  }

  isRowEditing(rowId: any) {
    return this.editRowId === rowId;
  }

     async saveRow(row: any) {
    console.log("row-----", row)
    this.editRowId = null;

    const isValid =
    row.name?.trim();

  if (!isValid) {
    this.fetchallboard()
    return;
  }

    try {
      const resp = await this.api.createboard(row);
      // console.log('doctors update data:', resp);
      if (resp.status === 0) {
        this._snackBar.open(resp.msg, '', {
          duration: 3000,
          verticalPosition: 'top',
          horizontalPosition: 'center',
        });
      } else {
        this._snackBar.open(resp.msg, '', {
          duration: 4000,
          verticalPosition: 'top',
          horizontalPosition: 'center',
        });
      }
    } catch (error) {
      console.error('Error updating board:', error);
    }
  }

  cancelEdit() {
    this.editRowId = null;
  }

  
  filterByQuery(query: string): void {
    const trimmedQuery = query.trim().toLowerCase();

    if (trimmedQuery) {
      this.isSearchActive = true;
      this.boardData.filter = trimmedQuery;

      if (this.boardData.paginator) {
        this.boardData.paginator.firstPage(); // Reset to first page after search
      }
    } else {
      this.isSearchActive = false;
      this.boardData.filter = ''; // Clear filter

      // Reset the paginator and restore original data
      setTimeout(() => {
        this.boardData.paginator = this.paginator;
      });
    }
  }

}
