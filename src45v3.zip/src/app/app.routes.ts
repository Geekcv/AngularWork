import { Route } from '@angular/router';
import { initialDataResolver } from 'app/app.resolvers';
import { LayoutComponent } from 'app/layout/layout.component';

import { authGuard } from 'app/Services/auth.guard';

// @formatter:off
/* eslint-disable max-len */
/* eslint-disable @typescript-eslint/explicit-function-return-type */
export const appRoutes: Route[] = [
    // Redirect empty path to '/example'
    { path: '', pathMatch: 'full', redirectTo: 'sign-in' },

    // Redirect signed-in user to the '/example'
    //
    // After the user signs in, the sign-in page will redirect the user to the 'signed-in-redirect'
    // path. Below is another redirection for that path to redirect the user to the desired
    // location. This is a small convenience to keep all main routes together here on this file.
    { path: 'signed-in-redirect', pathMatch: 'full', redirectTo: 'example' },

    // Auth routes for guests
    {
        path: '',
        // canActivate: [AuthGuard],
        // canActivateChild: [AuthGuard],
        component: LayoutComponent,
        data: {
            layout: 'empty',
        },
        children: [
            {
                path: 'confirmation-required',
                loadChildren: () =>
                    import(
                        'app/modules/auth/confirmation-required/confirmation-required.routes'
                    ),
            },
            {
                path: 'forgot-password',
                loadChildren: () =>
                    import(
                        'app/modules/auth/forgot-password/forgot-password.routes'
                    ),
            },
            {
                path: 'reset-password',
                loadChildren: () =>
                    import(
                        'app/modules/auth/reset-password/reset-password.routes'
                    ),
            },
            {
                path: 'sign-in',
                loadChildren: () =>
                    import('app/modules/auth/sign-in/sign-in.routes'),
            },
            {
                path: 'sign-up',
                loadChildren: () =>
                    import('app/modules/auth/sign-up/sign-up.routes'),
            },
            {
                path: 'teachersignup',
                loadChildren: () =>
                    import(
                        'app/modules/auth/sign-up-user/Teacher/sign-up-teacher/sign-up-teacher.routes'
                    ),
            },
            {
                path: 'schoolsignup',
                loadChildren: () =>
                    import(
                        'app/modules/auth/sign-up-user/School/sign-up-school/sign-up-school.routes'
                    ),
            },
        ],
    },

    // Auth routes for authenticated users
    {
        path: '',
        // canActivate: [AuthGuard],
        // canActivateChild: [AuthGuard],
        component: LayoutComponent,
        data: {
            layout: 'empty',
        },
        children: [
            {
                path: 'sign-out',
                loadChildren: () =>
                    import('app/modules/auth/sign-out/sign-out.routes'),
            },
            {
                path: 'unlock-session',
                loadChildren: () =>
                    import(
                        'app/modules/auth/unlock-session/unlock-session.routes'
                    ),
            },
        ],
    },

    // Landing routes
    {
        path: '',
        component: LayoutComponent,
        data: {
            layout: 'empty',
        },
        children: [
            {
                path: 'home',
                loadChildren: () =>
                    import('app/modules/landing/home/home.routes'),
            },
        ],
    },

    // dashbord routes
    {
        path: '',
        canActivate: [authGuard],
        canActivateChild: [authGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver,
        },
        children: [
            {
                path: 'dashboard',
                loadChildren: () =>
                    import('app/modules/admin/dashboard/dashboard.routes'),
            },
        ],
    },


    // School routes
    {
        path: '',
        canActivate: [authGuard],
        canActivateChild: [authGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver,
        },
        children: [
            {
                path: 'addschool',
                loadChildren: () =>
                    import(
                        'app/modules/admin/SuperAdmin/AddSchool/add-school/add-school.routes'
                    ),
            },
        ],
    },

      {
        path: '',
        canActivate: [authGuard],
        canActivateChild: [authGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver,
        },
        children: [
            {
                path: 'showclass',
                loadChildren: () =>
                    import(
                        'app/modules/admin/SchoolAdmin/schoolClass/show-class/show-class.routes'
                    ),
            },
        ],
    },

    

     {
        path: '',
        canActivate: [authGuard],
        canActivateChild: [authGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver,
        },
        children: [
            {
                path: 'classdetails/:id',
                loadChildren: () =>
                    import(
                        'app/modules/admin/SchoolAdmin/schoolClass/class-details/class-details.routes'
                    ),
            },
        ],
    },

     {
        path: '',
        canActivate: [authGuard],
        canActivateChild: [authGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver,
        },
        children: [
            {
                path: 'addStudent',
                loadChildren: () =>
                    import(
                        'app/modules/admin/SchoolAdmin/Student/add-student/add-student.routes'
                    ),
            },
        ],
    },


      {
        path: '',
        canActivate: [authGuard],
        canActivateChild: [authGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver,
        },
        children: [
            {
                path: 'addboard',
                loadChildren: () =>
                    import(
                        'app/modules/admin/SuperAdmin/add-board/add-board.routes'
                    ),
            },
        ],
    },

     {
        path: '',
        canActivate: [authGuard],
        canActivateChild: [authGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver,
        },
        children: [
            {
                path: 'addclass',
                loadChildren: () =>
                    import(
                        'app/modules/admin/SuperAdmin/add-class/add-class.routes'
                    ),
            },
        ],
    },

      {
        path: '',
        canActivate: [authGuard],
        canActivateChild: [authGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver,
        },
        children: [
            {
                path: 'addsubject',
                loadChildren: () =>
                    import(
                        'app/modules/admin/SuperAdmin/add-subject/add-subject.routes'
                    ),
            },
        ],
    },

      {
        path: '',
        canActivate: [authGuard],
        canActivateChild: [authGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver,
        },
        children: [
            {
                path: 'addchapter',
                loadChildren: () =>
                    import(
                        'app/modules/admin/SuperAdmin/add-chapter/add-chapter.routes'
                    ),
            },
        ],
    },


     {
        path: '',
        canActivate: [authGuard],
        canActivateChild: [authGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver,
        },
        children: [
            {
                path: 'subjectdetails/:id/:classid',
                loadChildren: () =>
                    import(
                        'app/modules/admin/SchoolAdmin/schoolClass/subject-details/subject-details.routes'
                    ),
            },
        ],
    },

     {
        path: '',
        canActivate: [authGuard],
        canActivateChild: [authGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver,
        },
        children: [
            {
                path: 'addteacher',
                loadChildren: () =>
                    import(
                        'app/modules/admin/SchoolAdmin/Teacher/add-teacher/add-teacher.routes'
                    ),
            },
        ],
    },

     {
        path: '',
        canActivate: [authGuard],
        canActivateChild: [authGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver,
        },
        children: [
            {
                path: 'teacherdetails/:id',
                loadChildren: () =>
                    import(
                        'app/modules/admin/SchoolAdmin/Teacher/show-teacher-deails/show-teacher-deails.routes'
                    ),
            },
        ],
    },
    

    // account setting

    {
        path: '',
        canActivate: [authGuard],
        canActivateChild: [authGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver,
        },
        children: [
            {
                path: 'settings',
                loadChildren: () =>
                    import('app/modules/pages/settings/settings.routes'),
            },
        ],
    },

     {
        path: '',
        canActivate: [authGuard],
        canActivateChild: [authGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver,
        },
        children: [
            {
                path: 'assignSubject',
                loadChildren: () =>
                    import(
                        'app/modules/admin/SchoolAdmin/Teacher/assign-subject/assign-subject.routes'
                    ),
            },
        ],
    },

    {
        path: '',
        canActivate: [authGuard],
        canActivateChild: [authGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver,
        },
        children: [
            {
                path: 'myclass',
                loadChildren: () =>
                    import(
                        'app/modules/admin/Teacher/myClass/show-class/show-class.routes'
                    ),
            },
        ],
    },
   
    {
        path: '',
        canActivate: [authGuard],
        canActivateChild: [authGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver,
        },
        children: [
            {
                path: 'myclassdetails/:id',
                loadChildren: () =>
                    import(
                        'app/modules/admin/Teacher/myClass/class-details/class-details.routes'
                    ),
            },
        ],
    },

    {
        path: '',
        canActivate: [authGuard],
        canActivateChild: [authGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver,
        },
        children: [
            {
                path: 'mysubjectdetails/:id/:classid',
                loadChildren: () =>
                    import(
                        'app/modules/admin/Teacher/myClass/subject-details/subject-details.routes'
                    ),
            },
        ],
    },

    {
        path: '',
        canActivate: [authGuard],
        canActivateChild: [authGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver,
        },
        children: [
            {
                path: 'addquestion',
                loadChildren: () =>
                    import(
                        'app/modules/admin/Teacher/question/add-question/add-question.routes'
                    ),
            },
        ],
    },

    {
        path: '',
        canActivate: [authGuard],
        canActivateChild: [authGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver,
        },
        children: [
            {
                path: 'addexam',
                loadChildren: () =>
                    import(
                        'app/modules/admin/Teacher/exam/add-exam/add-exam.routes'
                    ),
            },
        ],
    },

    {
        path: '',
        canActivate: [authGuard],
        canActivateChild: [authGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver,
        },
        children: [
            {
                path: 'addexamadmin',
                loadChildren: () =>
                    import(
                        'app/modules/admin/SchoolAdmin/exam/add-exam/add-exam.routes'
                    ),
            },
        ],
    },

     {
        path: '',
        canActivate: [authGuard],
        canActivateChild: [authGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver,
        },
        children: [
            {
                path: 'addquestionadmin',
                loadChildren: () =>
                    import(
                        'app/modules/admin/SchoolAdmin/question/add-question/add-question.routes'
                    ),
            },
        ],
    },

     {
        path: '',
        canActivate: [authGuard],
        canActivateChild: [authGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver,
        },
        children: [
            {
                path: 'showExamofStu/:id',
                loadChildren: () =>
                    // import(
                    //     'app/modules/admin/Students/show-exam-question/show-exam-question.routes'
                    // ),
                    import(
                        'app/modules/admin/Teacher/exam/show-exam-question/show-exam-question.routes'
                    ),
            },
        ],
    },

     {
        path: '',
        canActivate: [authGuard],
        canActivateChild: [authGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver,
        },
        children: [
            {
                path: 'showExam',
                loadChildren: () =>
                    // import(
                    //     'app/modules/admin/Students/show-all-exam/show-all-exam.routes'
                    // ),
                     import(
                        'app/modules/admin/Teacher/exam/show-all-exam/show-all-exam.routes'
                    ),
            },
        ],
    },


    {
        path: '',
        canActivate: [authGuard],
        canActivateChild: [authGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver,
        },
        children: [
            {
                path: 'viewQuestions',
                loadChildren: () =>
                    // import(
                    //     'app/modules/admin/Students/show-all-exam/show-all-exam.routes'
                    // ),
                     import(
                        'app/modules/admin/Teacher/question/view-all-questions/view-all-questions.routes'
                    ),
            },
        ],
    },

     {
        path: '',
        canActivate: [authGuard],
        canActivateChild: [authGuard],
        component: LayoutComponent,
        resolve: {
            initialData: initialDataResolver,
        },
        children: [
            {
                path: 'showAllquestion/:id',
                loadChildren: () =>
                    // import(
                    //     'app/modules/admin/Students/show-exam-question/show-exam-question.routes'
                    // ),
                    import(
                        'app/modules/admin/Teacher/question/show-all-question/show-all-question.routes'
                    ),
            },
        ],
    },

    
];
