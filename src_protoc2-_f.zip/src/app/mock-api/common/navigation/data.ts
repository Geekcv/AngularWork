/* eslint-disable */
import { FuseNavigationItem } from '@fuse/components/navigation';

export const defaultNavigation = (role: any): FuseNavigationItem[] => {
    const navigation: FuseNavigationItem[] = [];

   

    if (role === 1) {
        // Super Admin - Full Access
        navigation.push(
            {
                id: 'dashboard',
                title: 'Dashboard',
                type: 'basic',
                icon: 'mat_solid:dashboard',
                link: '/dashboard',
            },
            {
                id: 'schoolManagement',
                title: 'School Management',
                type: 'collapsable',
                icon: 'heroicons_outline:academic-cap', 
                children: [
                 
                    {
                        id: 'addboard',
                        title: 'Add Board',
                        type: 'basic',
                        icon: 'heroicons_outline:clipboard-document-check', 
                        link: '/addboard',
                    },
                   
                
                ],
            }
        );
    } else if (role === 2) {
        // School Admin - Limited Access
        navigation.push(
            {
                id: 'dashboard',
                title: 'Dashboard',
                type: 'basic',
                icon: 'mat_solid:dashboard',
                link: '/dashboard',
            },
             {
                id: 'schoolManagement',
                title: 'My School',
                type: 'collapsable',
                icon: 'heroicons_outline:academic-cap', 
                children: [
            {
                id: 'class',
                title: 'Class',
                type: 'basic',
                icon: 'heroicons_outline:rectangle-stack', 
                link: '/showclass',
            },
            {
                id: 'addStudent',
                title: 'Add Student',
                type: 'basic',
                icon: 'heroicons_outline:user-plus', 
                link: '/addStudent',
            },
              {
                id: 'addTeacher',
                title: 'Add Teacher',
                type: 'basic',
                icon: 'heroicons_outline:user-plus', 
                link: '/addteacher',
            },
             {
                id: 'assignSubjectToTeacher',
                title: 'Assign Subject',
                type: 'basic',
                icon: 'heroicons_outline:clipboard-document-check',
                link: '/assignSubject',
            },
        ]
        }
        );
    } else if (role === 3) {
        // Teacher/Faculty
        navigation.push(
            {
                id: 'dashboard',
                title: 'Dashboard',
                type: 'basic',
                icon: 'mat_solid:dashboard',
                link: '/dashboard',
            },
            //  {
            //     id: 'myClass',
            //     title: 'My Classes Subjects Assigned',
            //     type: 'basic',
            //     icon: 'heroicons_outline:academic-cap',
            //     link: '/myclass',
            // },
            //  {
            //     id: 'createQuestion',
            //     title: 'Question',
            //     type: 'basic',
            //     icon: 'heroicons_outline:clipboard-document-check', // better represents quiz/test
            //     link: '/addquestion',
            // },
        );
    } else if (role === 4) {
        // Student/User
        navigation.push(
            {
                id: 'dashboard',
                title: 'Dashboard',
                type: 'basic',
                icon: 'mat_solid:dashboard',
                link: '/dashboard',
            }
        );
    }

    return navigation;
};