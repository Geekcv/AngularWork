import { Routes } from '@angular/router';
import { AddChapterComponent } from './add-chapter.component';

export default [
    {
        path: '',
        component: AddChapterComponent,
    },
] as Routes;
