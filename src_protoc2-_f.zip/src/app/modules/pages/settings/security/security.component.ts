import {
    ChangeDetectionStrategy,
    Component,
    inject,
    OnInit,
    ViewEncapsulation,
} from '@angular/core';
import {
    AbstractControl,
    FormsModule,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

@Component({
    selector: 'settings-security',
    templateUrl: './security.component.html',
    encapsulation: ViewEncapsulation.None,
    changeDetection: ChangeDetectionStrategy.OnPush,
    imports: [
        FormsModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatIconModule,
        MatInputModule,
        MatSlideToggleModule,
        MatButtonModule,
    ],
})
export class SettingsSecurityComponent implements OnInit {
    securityForm: UntypedFormGroup;
      private _snackBar = inject(MatSnackBar);

    /**
     * Constructor
     */
    constructor(private _formBuilder: UntypedFormBuilder,private Apicontroller: ApicontrollerService) {
        
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void {
        // Create the form
        this.securityForm = this._formBuilder.group({
            currentPassword: ['',Validators.required],
            newPassword: ['',[Validators.required, Validators.minLength(8)]],
              confirmPassword: ['', [Validators.required]],
            twoStep: [true],
            askPasswordChange: [false],
            
        },{ validator: this.passwordMatchValidator });
    }


    passwordMatchValidator(form: AbstractControl) {
  const newPassword = form.get('newPassword')?.value;
  const confirmPassword = form.get('confirmPassword')?.value;
  if (newPassword !== confirmPassword) {
    form.get('confirmPassword')?.setErrors({ mismatch: true });
  } else {
    form.get('confirmPassword')?.setErrors(null);
  }
  return null;
}

  async onSubmit() {

    const currentPassword = this.securityForm.value.currentPassword;
    const confirmPassword = this.securityForm.value.confirmPassword;

    console.log("data",this.securityForm.value.currentPassword)
    const data = {
     "currentPassword":currentPassword,
     "confirmPassword":confirmPassword
    }
  if (this.securityForm.invalid) {

    this.securityForm.markAllAsTouched();
      
    return;
  }

  // Proceed with password update logic
}


}
