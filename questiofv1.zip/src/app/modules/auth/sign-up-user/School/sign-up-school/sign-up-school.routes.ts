import { Routes } from '@angular/router';
import { SignUpSchoolComponent } from './sign-up-school.component';

export default [
    {
        path: '',
        component: SignUpSchoolComponent,
    },
] as Routes;
