import { CommonModule, NgStyle } from '@angular/common';
import { Component, Inject } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import {
    MAT_DIALOG_DATA,
    MatDialogModule,
    MatDialogRef,
} from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { MatListModule } from '@angular/material/list';

interface ChapterData {
    chapter_id: string;
    chapter_name: string;
}

interface Teacher {
    email: string;
    name: string;
    row_id: string;
    role: string;
}

@Component({
    selector: 'app-selectquestion',
    imports: [
        MatDialogModule,
        MatButtonModule,
        NgStyle,
        MatFormFieldModule,
        MatInputModule,
        FormsModule,
        ReactiveFormsModule,
        MatSelectModule,
        CommonModule,
        MatInputModule,
        MatCheckboxModule,
        MatListModule
    
    ],
    templateUrl: './selectquestion.component.html',
    styleUrl: './selectquestion.component.scss',
})
export class SelectquestionComponent {
    chapterList: ChapterData[] = [];

    TeacherDeatials: Teacher = {
        email: '',
        name: '',
        row_id: '',
        role: '',
    };

    constructor(
        @Inject(MAT_DIALOG_DATA)
        public data: { medialink: string; mediadata: any },
        private dialogRef: MatDialogRef<SelectquestionComponent>, // Inject MatDialogRef
        private api: ApicontrollerService
    ) {
        this.TeacherDeatials = JSON.parse(
            localStorage.getItem('userDeatials') || '{}'
        );
        this.fetchCompletedChapter();
        //this.fetchquestion();
    }
    exitbtn() {
        this.dialogRef.close();
    }

    async fetchCompletedChapter() {
        var data = {
            teacher_id: this.TeacherDeatials.row_id,
        };

        console.log('theacher');
        const resp = await this.api.fetchAllcompletedChapter('common', data);
        this.chapterList = resp.data as ChapterData[];
    }

    selectedchapterValue: any;
    selectedlimitValue: any;
    questionList: any[] = [];
    selectedQuestions: any[] = [];
    
    async fetchquestion() {
        const data = {
            chapter_id: this.selectedchapterValue,
            limit: this.selectedlimitValue,
        };
    
        console.log('Fetching questions with data:', data);
        const resp = await this.api.fetchAllquestionOfchapter('common', data);
        this.questionList = resp || [];
        console.log('Fetched questions:', this.questionList);
    }
    
    showQuestion() {
        this.fetchquestion();
    }
    
    // Optional: method to handle final selection
    submitSelectedQuestions() {
        console.log('Selected Question IDs:', this.selectedQuestions);
        console.log('chapters IDs:', this.selectedchapterValue);

        var data = {
           "questiondid":this.selectedQuestions,
           "chapter_id":this.selectedchapterValue
        }

        this.dialogRef.close(data);


    }
    


}
