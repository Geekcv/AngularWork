import { Component, inject, ViewChild } from '@angular/core';
import { FormsModule, NgForm, ReactiveFormsModule, UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CommonModule, NgStyle } from '@angular/common';
import { config } from '../../../../../../../config';
import { FuseDrawerComponent } from '@fuse/components/drawer';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';

interface school{
  row_id:string;
  name:string;
}

interface classData{
  row_id:string;
  name:string
}

interface SchoolAdmin {
    email: string;
    role: string;
    name: string;
    row_id: string;
    school_id:string
  }

  interface Column {
  name: string; // The column name/key (must match MatTable's columnDef)
  label: string; // The displayed label for checkbox and header
  visible: boolean; // Whether this column is currently shown
}

interface Teacher{
  row_id:string;
  name:string;
  email:string;
  phone:string;
  password:string;
  qualification:string;
  experience_years:string;
  user_row_id:string
}

@Component({
  selector: 'app-add-teacher',
  imports: [
     FormsModule,
            ReactiveFormsModule,
            MatFormFieldModule,
            MatInputModule,
            MatButtonModule,
            MatIconModule,
            MatCheckboxModule,
            MatProgressSpinnerModule,
            MatSelectModule,CommonModule,
            FuseDrawerComponent,

             MatTableModule,
                MatPaginatorModule,
             
                NgStyle , MatTooltipModule, MatSortModule,

              
  ],
  templateUrl: './add-teacher.component.html',
  styleUrl: './add-teacher.component.scss'
})
export class AddTeacherComponent {
@ViewChild('teacherNgForm') teacherNgForm: NgForm;

  teacherData = new MatTableDataSource<Teacher>([]); // Use MatTableDataSource for pagination
   @ViewChild(MatPaginator) paginator!: MatPaginator;
   @ViewChild(MatSort) sort!: MatSort;
 

  teacherForm: UntypedFormGroup;
  showAlert = false;
  role: any = '';
  config: any;
   schoolList : school[]; 
  classList = []; 
  // schooldata: school[]

    SchoolAdminDeatials: SchoolAdmin = {
        email: '',
        name: '',
        role:'',
        row_id: '',
        school_id:''
      };

  constructor(
      private _formBuilder: UntypedFormBuilder,
      private router: Router,
      private Apicontroller: ApicontrollerService,

  ) {
      this.config = config.apiBaseURL;
      
      this.role = localStorage.getItem('role');

      this.SchoolAdminDeatials = JSON.parse(localStorage.getItem("userDeatials"));


      this.fetchallSchool()
      this.fetchteacher()
  }

  private _snackBar = inject(MatSnackBar);

  ngOnInit(): void {
      this.teacherForm = this._formBuilder.group({
          name: ['', Validators.required],
    email: ['', [Validators.required ,Validators.email]],
    phone: ['',[Validators.required]],
    password:['',[Validators.required]],
    qualification:['',[Validators.required]],
     experience_years:[''],
    
      });
  }


   get displayedColumns(): string[] {
    return this.columns.filter((c) => c.visible).map((c) => c.name);
  }
 

  async addTeacher(addteacherpanel:any): Promise<void> {

      if (this.teacherForm.invalid) {
          this.teacherForm.markAllAsTouched();
          return;
      }

      const payload = {
          ...this.teacherForm.value,
          school_row_id: this.SchoolAdminDeatials.school_id

      };

      const resp = await this.Apicontroller.createteacher(payload);

      if (resp.status === 0) {
          this._snackBar.open(resp.msg, '', {
              duration: 3000,
              verticalPosition: 'top',
              horizontalPosition: 'center',
          });

          this.teacherNgForm.resetForm();
      this.fetchteacher()
          addteacherpanel.close()

      } else {
          this._snackBar.open(resp.msg || 'Failed to add teacher', '', {
              duration: 3000,
              verticalPosition: 'top',
              horizontalPosition: 'center',
          });
      }
  }



async  fetchallSchool(){

      const resp = await this.Apicontroller.fetchAllSchool();
      console.log("fetch all school ------->",resp)
      this.schoolList = resp as school[]
      
  }


 

  selectedValue: string = '';


     async onSelectionChange(event: Event){
        // this.selectedValue = (event.target as HTMLSelectElement).value;
        console.log('Selected value:---------', this.selectedValue);

        const resp = await this.Apicontroller.fetchAllclassOfSchool('common', this.selectedValue);
        console.log("resp",resp)
        this.classList = resp as classData[]
       

      }

      refresh(){
      this.fetchteacher()
        
      }

  isSearchActive = false;

        columns: Column[] = [
    { name: 'sr_no', label: 'Sr.No', visible: true },
    { name: 'name', label: 'Teacher Name', visible: true },
    { name: 'email', label: 'Email', visible: true },
    { name: 'phone', label: 'Phone', visible: true },
    { name: 'password', label: 'Password', visible: true },
    { name: 'qualification', label: 'Qualification', visible: true },
    { name: 'experience_years', label: 'Experience years', visible: true },


    { name: 'actions', label: 'Actions', visible: true },


  ];

    editRowId: number | null = null;

  editRow(rowId: number) {
    this.editRowId = rowId;
  }

  isRowEditing(rowId: any) {
    return this.editRowId === rowId;
  }

  async fetchteacher() {
    console.log(" before data")

    try {
      const resp = await this.Apicontroller.fetchAllteacherOfSchool('common', this.SchoolAdminDeatials.school_id);
      //  this.classData.data = resp
      console.log("Teacher data ------------------>", resp);

      const data = resp as Teacher[];

      console.log("teacher data",data)

      // Add sr_no for each row (based on pagination if needed)
      this.teacherData.data = data.map((item, index) => ({
        ...item,
        sr_no: index + 1 + this.teacherData.paginator.pageIndex * this.teacherData.paginator.pageSize
      }));

      console.log("teacherData.data ------------------>", this.teacherData.data);


      // Enable sorting for custom fields like user_row_id (extract numeric part)
      this.teacherData.sortingDataAccessor = (item, property) => {
        if (property === 'row_id') {
          return Number(item.row_id?.split('_')[0]); // numeric part
        }
        return item[property];
      };



    } catch (error) {
      // console.error("Error fetching doctors:", error);
    }

  }

    async saveRow(row: any) {
    console.log("row-----", row)
    this.editRowId = null;

    try {
      const resp = await this.Apicontroller.createteacher(row);
      // console.log('doctors update data:', resp);
      if (resp.status === 0) {
        this._snackBar.open(resp.msg, '', {
          duration: 3000,
          verticalPosition: 'top',
          horizontalPosition: 'center',
        });
      } else {
        this._snackBar.open(resp.msg, '', {
          duration: 4000,
          verticalPosition: 'top',
          horizontalPosition: 'center',
        });
      }
    } catch (error) {
      console.error('Error updating teacher:', error);
    }
  }

  cancelEdit() {
    this.editRowId = null;
  }


  viewteacherDetails(row:any){
    // teacherdetails
    console.log("show teacher data",row)
    this.router.navigate(['teacherdetails', row]);

  }

    ngAfterViewInit() {
    // console.log(" ngAfterViewInit")
    this.teacherData.paginator = this.paginator; // Set paginator after view init
    this.teacherData.sort = this.sort

  }

  filterByQuery(query: string): void {
    const trimmedQuery = query.trim().toLowerCase();

    if (trimmedQuery) {
      this.isSearchActive = true;
      this.teacherData.filter = trimmedQuery;

      if (this.teacherData.paginator) {
        this.teacherData.paginator.firstPage(); // Reset to first page after search
      }
    } else {
      this.isSearchActive = false;
      this.teacherData.filter = ''; // Clear filter

      // Reset the paginator and restore original data
      setTimeout(() => {
        this.teacherData.paginator = this.paginator;
      });
    }
  }

}
