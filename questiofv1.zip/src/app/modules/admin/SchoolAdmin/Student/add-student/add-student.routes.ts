import { Routes } from '@angular/router';
import { AddStudentComponent } from './add-student.component';

export default [
    {
        path: '',
        component: AddStudentComponent,
    },
] as Routes;
