import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditOdpappointmentComponent } from './edit-odpappointment.component';

describe('EditOdpappointmentComponent', () => {
  let component: EditOdpappointmentComponent;
  let fixture: ComponentFixture<EditOdpappointmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EditOdpappointmentComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EditOdpappointmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
