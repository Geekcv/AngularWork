import {ChangeDetectionStrategy, Component} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {MatTimepickerModule} from '@angular/material/timepicker';
import {MatInputModule} from '@angular/material/input';
import {MatFormFieldModule} from '@angular/material/form-field';
import {provideNativeDateAdapter} from '@angular/material/core';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { MatSelectModule } from '@angular/material/select';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { AuthService } from 'app/Services/auth.service';
import { MatButtonModule } from '@angular/material/button';


interface Patient { 
  patient_age: string;
  patient_email: string;
  patient_gender: string;
  patient_name:string;
  user_contact_number:string;
  user_password:string;
  user_row_id:string;
  }
   
  

@Component({
  selector: 'app-appointment',
  imports: [  MatFormFieldModule,
    MatInputModule,
    MatTimepickerModule,
    MatDatepickerModule,
    FormsModule,
    MatFormFieldModule, MatSelectModule, MatInputModule, FormsModule, MatButtonModule],
  templateUrl: './appointment.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [provideNativeDateAdapter()],
})
export class AppointmentComponent {
  value: Date;
  patients: Patient[] = [];

  selectedvalue:string;
  app_type:string = '';

  // slot: string = '';
  availableslot: string[] = ['Physical', 'Virtual'];

  constructor(
        private route: ActivatedRoute,
        private router: Router,
        private apiController: ApicontrollerService,
        private authService: AuthService
      ) {
        this.mydoctor();

        
      }



      async mydoctor() {
        try {
          const resp = await this.apiController.fetchPatients();

        
          console.log("doctor", resp);
          this.patients = resp.data as Patient[]; // Type assert to Doctor[]
        } catch (error) {
          console.error("Error fetching doctors:", error);
        }
    
      }


    
      // Value: Tue Mar 11 2025 00:30:00 GMT+0530 (India Standard Time)

     async  appointment(){

     var data = {
        "pat_row_id": this.selectedvalue,
        "time_of_apt": this.value.toTimeString().split(' ')[0],
        "date_of_apt": this.value.toDateString(),
        "appt_type": this.app_type,
      }    



       // console.log("add appointment....",data)
        const resp = await this.apiController.appointment(data);

       

        if (resp.status === 0) {

          this.router.navigate(['/Viewpatients'])
          
        }


      }


}
