import { Routes } from '@angular/router';
import { AddpatientsComponent } from 'app/modules/admin/doctorSide/addpatients/addpatients.component';

export default [
    {
        path: '',
        component: AddpatientsComponent,
    },
] as Routes;
