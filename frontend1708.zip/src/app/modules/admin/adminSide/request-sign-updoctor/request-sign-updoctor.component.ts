import { Component, Inject, inject, ViewChild } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';

import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { DeldialogComponent } from '../../dialog/deldialog/deldialog.component';
import { MatDialog } from '@angular/material/dialog';
import { AdddoctordialogComponent } from '../../dialog/adddoctordialog/adddoctordialog.component';
import { ActivePatientsComponent } from '../../dialog/active-patients/active-patients.component';

interface Doctor {
  doctor_email: string;
  doctor_gender: string;
  doctor_name: string;
  user_contact_number:string;
  user_password:string;
  user_row_id:string;
  
}
 
@Component({
  selector: 'app-request-sign-updoctor',
 imports: [MatTableModule,MatPaginatorModule,MatButtonModule,
    MatIconModule,
    MatInputModule],
  templateUrl: './request-sign-updoctor.component.html',
  styleUrl: './request-sign-updoctor.component.scss'
})

export class RequestSignUpdoctorComponent { 
  role :any ='';
  // doctor: Doctor[] = [];

  doctor = new MatTableDataSource<Doctor>([]); // Use MatTableDataSource for pagination

  isSearchActive = false;
  isempty = false;

  @ViewChild(MatPaginator) paginator!: MatPaginator;

  // readonly dialogRef = inject(MatDialogRef<ViewresearchersComponent>);
  
  displayedColumns: string[] = [
      'user_row_id', 
      'doctor_name', 
      'doctor_email', 
      'user_contact_number',
            'actions'
  ];
  constructor(
    private Apicontroller: ApicontrollerService,
    private router: Router,
    private _matDialog: MatDialog
   
  ) { 

    this.role=  localStorage.getItem('role')

    // console.log("my role",this.role)
  }

  ngOnInit(): void {
    console.log(" ngOnInit")

    this.mydoctor();
  }
  
  ngAfterViewInit() {
    console.log(" ngAfterViewInit")
    this.doctor.paginator = this.paginator; // Set paginator after view init
  }

  page: number = 1; // Default to first page

  async mydoctor() {
    console.log(" mydoctor")

    try {
      const resp = await this.Apicontroller.fetchDeactivedoctor('common',this.page);
      // console.log("doctor", resp);
      this.doctor.data = resp.data as Doctor[]; // Type assert to Doctor[]
    } catch (error) {
      // console.error("Error fetching doctors:", error);
    }

  }


  viewDoctorDetails(doctor_rowId: string) {
    console.log("viewdata",doctor_rowId)
    this.router.navigate(['researchersDetails', doctor_rowId]);
  }




  refresh(){
    console.log("refresh----")
    this.mydoctor();
    // window.location.reload();
  }


  visibilitybtn(){
    console.log("visibilitybtn .....")
  }
  
  approvebtn(user_row_id:any){

    
    const dialogRef = this._matDialog.open(ActivePatientsComponent,{ data: { patient: user_row_id  } });


    dialogRef.afterClosed().subscribe((result) => {
        this.mydoctor();
    });


    
    console.log("delete.....")
  }

  
 
  
}