import { CommonModule, NgIf } from '@angular/common';
import { Component, Input } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';

interface FormElement {
  type: string;
  label: string;
  placeholder?: string;
  accept?:string
}

@Component({
  selector: 'app-file-upload',
  imports: [ NgIf,             
    CommonModule, 
    FormsModule,          
    MatInputModule,
 MatIconModule,],
  templateUrl: './file-upload.component.html',
  styleUrl: './file-upload.component.scss'
})
export class FileUploadComponent {
@Input() selectedElementIndex:any; 
 @Input() formItems:FormElement[]; 


 accept:string = 'image/jpeg'

selectElement(index: number) {
  this.selectedElementIndex = index;
  const selectedElement = this.formItems[index];

  const selectedElementtype = this.formItems[index].type;
  this.accept = selectedElement.accept  || 'image/jpeg'
}


updateStyles() {
  // console.log("bac color",this.bgColor)
  if (this.selectedElementIndex !== null) {
    const selectedElement = this.formItems[this.selectedElementIndex];
    // selectedElement.accept = this.accept;

    selectedElement.accept = this.accept
    console.log("update ",this.accept)
   
  }
}
}
