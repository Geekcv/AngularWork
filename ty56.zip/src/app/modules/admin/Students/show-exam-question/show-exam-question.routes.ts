import { Routes } from '@angular/router';
import { ShowExamQuestionComponent } from './show-exam-question.component';

export default [
    {
        path: '',
        component: ShowExamQuestionComponent,
    },
] as Routes;
