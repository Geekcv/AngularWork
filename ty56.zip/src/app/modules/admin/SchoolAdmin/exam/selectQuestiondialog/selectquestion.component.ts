import { CommonModule, NgStyle } from '@angular/common';
import { Component, Inject } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import {
    MAT_DIALOG_DATA,
    MatDialogModule,
    MatDialogRef,
} from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectChange, MatSelectModule } from '@angular/material/select';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { MatListModule } from '@angular/material/list';

interface ChapterData {
    chapter_id: string;
    chapter_name: string;
}

interface Teacher {
    email: string;
    name: string;
    row_id: string;
    role: string;
}

  interface Class {
  row_id: string;
  name: string;
}

interface Subject {
  row_id: string;
  name: string;
}

interface SchoolAdmin {
    email: string;
    role: string;
    name: string;
    row_id: string;
    school_id:string
  }



@Component({
    selector: 'app-selectquestion',
    imports: [
        MatDialogModule,
        MatButtonModule,
        NgStyle,
        MatFormFieldModule,
        MatInputModule,
        FormsModule,
        ReactiveFormsModule,
        MatSelectModule,
        CommonModule,
        MatInputModule,
        MatCheckboxModule,
        MatListModule,
    
    ],
    templateUrl: './selectquestion.component.html',
    styleUrl: './selectquestion.component.scss',
})
export class SelectquestionBySchoolComponent {
   // chapterList: ChapterData[] = [];

     teacherlist : Teacher[] = []
       selectedteacherValue:any;

        SchoolAdminDeatials: SchoolAdmin = {
        email: '',
        name: '',
        role:'',
        row_id: '',
        school_id:''
      };

    TeacherDeatials: Teacher = {
        email: '',
        name: '',
        row_id: '',
        role: '',
    };

    constructor(
        @Inject(MAT_DIALOG_DATA)
        public data: { medialink: string; mediadata: any },
        private dialogRef: MatDialogRef<SelectquestionBySchoolComponent>, // Inject MatDialogRef
        private api: ApicontrollerService
    ) {
        this.TeacherDeatials = JSON.parse(
            localStorage.getItem('userDeatials') || '{}'
        );

         this.SchoolAdminDeatials = JSON.parse(
            localStorage.getItem('userDeatials') || '{}'
        );

        this.fetchCompletedChapter();
        //this.fetchquestion();
        this.fetchclassdata()
                this.fetchallteacher()

    }
    exitbtn() {
        this.dialogRef.close();
    }

   

    selectedchapterValue: any;
    selectedlimitValue: any;
    questionList: any[] = [];
    selectedQuestions: any[] = [];
    
    async fetchquestion() {
        const data = { chapter_id: this.selectedchapterValue };
        const resp = await this.api.fetchAllquestionOfchapter('common', data);
        this.questionList = resp || [];
        
        // Always pick random questions after fetching
        this.onLimitChange();
    }
    
    showQuestion() {
        this.fetchquestion();
    }
    
    // Optional: method to handle final selection
    submitSelectedQuestions() {
        console.log('Selected Question IDs:', this.selectedQuestions);
        console.log('chapters IDs:', this.selectedchapterValue);

        var data = {
           "questiondid":this.selectedQuestions,
           "chapter_id":this.selectedchapterValue,
           "class_id":this.selectedclassValue,
           "subject_id":this.selectedsubValue,
           "teacher_id":this.selectedteacherValue
        }

        console.log("data----",data)

        this.dialogRef.close(data);


    }
    


       classList: Class[] = [];
    
    
         async fetchclassdata() {
        console.log(" before data")
    
        try {
          const resp = await this.api.fetchOwnlass('common', this.TeacherDeatials.row_id);
          //  this.classData.data = resp
          console.log("class data ------------------>", resp.data);
    
           this.classList  = resp.data as Class[];    
    
    
        } catch (error) {
          // console.error("Error fetching doctors:", error);
        }
    
      }
    
    
    
       subList: Subject[] = [];
    
      selectedclassValue:any;
    
     async onSelectionclassChange(event:MatSelectChange){
    
        console.log("data---->",event.value)
        this.selectedclassValue = event.value
    
        const dataid = {
            class_id : event.value,
            teacher_id:this.selectedteacherValue
           }
    
           console.log("dataa--",dataid)
      
          const resp = await this.api.fetchClassSubjectByteacher('common',dataid);
          //  this.classData.data = resp
          console.log("school data ------------------>",resp);
    
          this.subList = resp as Subject[];
    
          console.log("sub lsit ",this.subList)
    
      }
    

        chapterList: ChapterData[] = [];
      
        selectedsubValue:any
         async onSelectionsubChange(event:MatSelectChange){
      
          console.log("data---->",event.value)
          this.selectedsubValue = event.value
      
          
        
              var data = {
            teacher_id: this.selectedteacherValue,
            subject_id:event.value
        };

        console.log('theacher');
        const resp = await this.api.fetchAllcompletedChapter('common', data);
        this.chapterList = resp.data as ChapterData[];

        }

         async fetchCompletedChapter() {
       
    }
    

     // Auto-select questions based on entered limit
    onLimitChange() {
        if (this.selectedlimitValue > 0 && this.questionList.length > 0) {
            //  Randomly shuffle the question list
            const shuffled = [...this.questionList].sort(() => Math.random() - 0.5);
    
            // Pick the first N from the shuffled list
            this.selectedQuestions = shuffled
                .slice(0, this.selectedlimitValue)
                .map(q => q.row_id);
    
            console.log('Randomly selected:', this.selectedQuestions);
        } else {
            this.selectedQuestions = [];
        }
    }

    
    // Select all questions
selectAllQuestions() {
    this.selectedQuestions = this.questionList.map(q => q.row_id);
    console.log('All selected:', this.selectedQuestions);
}

// Clear all selections
clearAllQuestions() {
    this.selectedQuestions = [];
    console.log('Selection cleared');
}

async onSelectionteacherChange(event:MatSelectChange){

    console.log("event --->",event.value)
    const resp = await this.api.fetchTeacherClass('common', event.value);
       this.selectedteacherValue = event.value
      console.log("class data ------------------>", resp);

       this.classList  = resp.data as Class[]; 

       console.log("classlsit--->",this.classList)
  }

    async fetchallteacher(){
     const resp = await this.api.fetchAllteacherOfSchool('common', this.SchoolAdminDeatials.school_id);
      //  this.classData.data = resp
      console.log("Teacher data ------------------>", resp);

      this.teacherlist = resp as Teacher[];
  }


  

}
