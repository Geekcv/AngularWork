import { Component, inject, ViewChild } from '@angular/core';
import { FormsModule, ReactiveFormsModule, UntypedFormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { config } from '../../../../../../../config';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { CommonModule, NgStyle } from '@angular/common';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { SelectquestionComponent } from '../selectQuestiondialog/selectquestion.component';
import { SelectquestionBySchoolComponent } from 'app/modules/admin/SchoolAdmin/exam/selectQuestiondialog/selectquestion.component';


interface SchoolAdmin {
  email: string;
  role: string;
  name: string;
  row_id: string;
  school_id: string;
}



interface Column {
  name: string; // The column name/key (must match MatTable's columnDef)
  label: string; // The displayed label for checkbox and header
  visible: boolean; // Whether this column is currently shown
}

interface exam{
  subject_name:string;
  class_name:string;
  exam_name:string;
  total_marks:string;
  passing_marks:string;
  duration_minutes:string;
  row_id:string;
}

@Component({
  selector: 'app-show-all-exam',
  imports: [
 MatTableModule,
    MatPaginatorModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    NgStyle, MatTooltipModule, MatSortModule,
    ReactiveFormsModule, MatFormFieldModule,
    MatSelectModule, CommonModule,
    FormsModule, 

  ],
  templateUrl: './show-all-exam.component.html',
  styleUrl: './show-all-exam.component.scss'
})
export class ShowAllExamComponent {

  //  examData: any[] = [];

     examData = new MatTableDataSource<exam>([]); // Use MatTableDataSource for pagination
     @ViewChild(MatPaginator) paginator!: MatPaginator;
     @ViewChild(MatSort) sort!: MatSort;
     private _snackBar = inject(MatSnackBar);
   
    config: any;
    role: any = '';
  

      SchoolAdminDeatials: SchoolAdmin = {
    email: '',
    name: '',
    role: '',
    row_id: '',
    school_id: ''
  };
  
      studentAnswers: Record<string, string | string[] | null> = {};
  
      constructor(
        private _formBuilder: UntypedFormBuilder,
        private router: Router,private _matDialog: MatDialog,
        private api: ApicontrollerService,
    ) {
        this.config = config.apiBaseURL;
        this.role = localStorage.getItem('role');
      //this.TeacherDeatials = JSON.parse(localStorage.getItem("userDeatials"));
    this.SchoolAdminDeatials = JSON.parse(localStorage.getItem("userDeatials"));

  
   this.fetchexambyteacher()
      }
  
  async fetchexambyteacher(){


      if (this.role == 3) {
          const resp = await this.api.fetchAllexambyteacher();

      console.log("data exam ---->>",resp)

      const data = resp.data as exam[];

    // Add sr_no for each row (based on pagination if needed)
      this.examData.data = data.map((item, index) => ({
        ...item,
        sr_no: index + 1 + this.examData.paginator.pageIndex * this.examData.paginator.pageSize
      }));

      }
    
      if (this.role == 2) {
        console.log("school admin fetche exam data ",this.SchoolAdminDeatials.school_id)
        const resp = await this.api.fetchAllexambyschool('common',this.SchoolAdminDeatials.school_id)
         const data = resp.data as exam[];

           this.examData.data = data.map((item, index) => ({
        ...item,
        sr_no: index + 1 + this.examData.paginator.pageIndex * this.examData.paginator.pageSize
      }));

      }
    
  }

    view(rowId: string) {
    console.log("viewdata", rowId)
    this.router.navigate(['showExamofStu', rowId]);
  }


    isSearchActive = false;

      columns: Column[] = [
    { name: 'sr_no', label: 'Sr.No', visible: true },
    { name: 'exam_name', label: 'Exam Name', visible: true },
    { name: 'total_marks', label: 'Total Marks', visible: true },
    { name: 'passing_marks', label: 'Passing Marks', visible: true },
    { name: 'duration_minutes', label: 'Duration', visible: true },
    { name: 'class_name', label: 'Class', visible: true },
    { name: 'subject_name', label: 'Subject', visible: true }, 
    { name: 'actions', label: 'Actions', visible: true },

  ];

   get displayedColumns(): string[] {
    return this.columns.filter((c) => c.visible).map((c) => c.name);
  }


    ngAfterViewInit() {
    // console.log(" ngAfterViewInit")
    this.examData.paginator = this.paginator; // Set paginator after view init
    this.examData.sort = this.sort

  }

  
  editRowId: number | null = null;

  editRow(rowId: number) {
    this.editRowId = rowId;
  }

  isRowEditing(rowId: any) {
    return this.editRowId === rowId;
  }

    viewexamDetails(rowId: string) {
    // console.log("viewdata", doctor_rowId)
     this.router.navigate(['showExamofStu', rowId]);
  }


    async saveRow(row: any) {
    console.log("row-----", row)
    this.editRowId = null;

    var payload = {
      ...row,
           chapter_id:this.chapter_id,question_set:this.question_set,
           class_id:this.class_id,subject_id:this.subject_id
    }


    console.log("edit exam payload================>",payload)

 try {
      const resp = await this.api.updateExam(payload);
      // console.log('doctors update data:', resp);
      if (resp.status === 0) {
        this._snackBar.open(resp.msg, '', {
          duration: 3000,
          verticalPosition: 'top',
          horizontalPosition: 'center',
        });
           this.fetchexambyteacher()


      } else {
        this._snackBar.open(resp.msg, '', {
          duration: 4000,
          verticalPosition: 'top',
          horizontalPosition: 'center',
        });
      }
    } catch (error) {
      console.error('Error updating exam:', error);
    }



   
  }

  cancelEdit() {
    this.editRowId = null;
  }


    chapter_id:any;
  question_set:any;
  slelected_question :any  = 0;
  class_id:any;
  subject_id:any;
    totalMarks:any;


  selectQuestion(){

    let dialogRef;

        if (this.role == 2) {
          
          dialogRef = this._matDialog.open(SelectquestionBySchoolComponent);
        }else{
          dialogRef = this._matDialog.open(SelectquestionComponent);

        }
  
        dialogRef.afterClosed().subscribe((result: any) => {
          console.log("res----------------->",result)
            if (result) {
             console.log("chapter_id--",result.chapter_id) 
             console.log("question_set--",result.questiondid)  
             this.chapter_id = result.chapter_id;
             this.question_set = result.questiondid;
             this.subject_id = result.subject_id
             this.class_id = result.class_id
            this.totalMarks = result.totalMarks
  
             console.log("slected question set",this.question_set.length)
              this.slelected_question = this.question_set.length
              
            }
        });
  
      }


}
