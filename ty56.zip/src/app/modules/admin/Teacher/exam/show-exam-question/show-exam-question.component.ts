import { Component } from '@angular/core';
import { FormsModule, ReactiveFormsModule, UntypedFormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { config } from '../../../../../../../config';

@Component({
  selector: 'app-show-exam-question',
  imports: [FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatCheckboxModule,
    MatProgressSpinnerModule,
    MatSelectModule,MatDatepickerModule,MatNativeDateModule],
  templateUrl: './show-exam-question.component.html',
  styleUrl: './show-exam-question.component.scss'
})
export class ShowExamQuestionComponent {

    examData: any[] = [];
  config: any;
  role: any = '';
  exameid:any;
  min:any;

    studentAnswers: Record<string, string | string[] | null> = {};

    constructor(
      private _formBuilder: UntypedFormBuilder,
      private router: Router,private _matDialog: MatDialog,
      private api: ApicontrollerService,
       private route: ActivatedRoute,
  ) {
      this.config = config.apiBaseURL;
      this.role = localStorage.getItem('role');
    //this.TeacherDeatials = JSON.parse(localStorage.getItem("userDeatials"));
    this.exameid = this.route.snapshot.paramMap.get('id');
   // this.min = this.route.snapshot.paramMap.get('min');



 this.fetchExamdetails()

}

async fetchExamdetails() {

  var examdata = {
    "exam_id":this.exameid
  }
  const resp = await this.api.fetchexamandQuestionsByteacher('common', examdata);
  this.examData = resp.data;

  console.log("examdata----->>>>->>>>",this.examData)
  console.log("examdata----->>>>",this.examData.length > 0)


  // Initialize based on question type
  this.studentAnswers = {};
  for (const q of this.examData) {
    if (q.question_type === 'checkbox') {
      this.studentAnswers[q.row_id] = []; // multiple answers
    } else {
      this.studentAnswers[q.row_id] = null; // single answer
    }
  }

  console.log("Exam Data:----------", resp);
}

onCheckboxChange(questionId: string, option: string, checked: boolean) {
  const current = this.studentAnswers[questionId] as string[];

  if (checked) {
    if (!current.includes(option)) {
      current.push(option);
    }
  } else {
    const idx = current.indexOf(option);
    if (idx > -1) current.splice(idx, 1);
  }
}

async submitAnswers() {
  const payload = this.examData.map(q => {
    let answer;

    if (q.question_type === 'checkbox') {
      answer = { selected: this.studentAnswers[q.row_id] }; // array
    } else {
      answer = { selected: this.studentAnswers[q.row_id] || null }; // single value
    }

    console.log("q---->",q)

    return {
      examId: this.exameid,
      questionId: q.row_id,
      answer
    };
  });

  console.log(payload);
  await this.api.addExamSubmistion(payload, 'common');
}
    


 goback(){
    this.router.navigate(['/showExam'])

 }
}
