export const config = {
    
    apiBaseURL : 'http://192.168.114.1:3000', 

    // apiBaseURL:'https://aiclassroom.ftisindia.com',

    appVersion: '1.2.0'
}

