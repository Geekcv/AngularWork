import { Injectable } from '@angular/core';
import { UploadFileService } from '../services/upload-file.service';
import { UtiltiesService } from '../services/utilties.service';
import { AuthService } from '../services/auth.service';
import { ApiService } from '../services/api.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ApicontrollerService {
 async fetchCenterWiseResultsReport(selectedExamSession: any, selectedCenter: any, selectedFaculty: string, selectedClass: any) {
    var data = {
      "se": "fe_merit_list",
      "data": { 
        "faculty":selectedFaculty,
        "exam_sessions":selectedExamSession,
        "class_id":selectedClass,
      }
    };
    var redata: any = await this.apiService.post(data);
  console.log("redata===============");
  console.log(redata);
    if (redata.status == '0') {
    // console.log(redata.data);
      return redata.data;
    } else {
      this.utitilitiesService.openSnackBar(redata.msg);
      return false;
    }
  }
  async fetchMarksByBandal(selectedExamSession: any, bandalNo: any) {
    var data = {
      "se": "fe_stu_marks",
      "data": {       
        "exam_session":selectedExamSession,
      "bandal_no":bandalNo,
      
      }
    };
    console.log("data===============");
    console.log(data);
    var redata: any = await this.apiService.post(data);
  console.log("redata===============");
  console.log(redata);
    if (redata.status == '0') {
    // console.log(redata.data);
      return redata.data;
    } else {
      this.utitilitiesService.openSnackBar(redata.msg);
      return false;
    }
  }
  async fetchStudentMarks(selectedFaculty: any, selectedExamSession: any, selectedClass: any | null, selectedCenter: any | null,marksFrom: number | null, marksTo: number | null) {
    
  //   const payload: any = {
  //     faculty: selectedFaculty,
  //     exam_session: selectedExamSession,
  // };
  // // Add optional parameters only if they have a value
  // if (selectedClass !== null ) {
  //     payload.class_id = selectedClass;
  // }
  // if (selectedCenter !== null ) {
  //     payload.center = selectedCenter;
  // }
  // if (marksFrom !== null) {
  //     payload.marksfrom = marksFrom;
  // }
  // if (marksTo !== null) {
  //     payload.marksto = marksTo;
  // }

    // var data = {
    //   "se": "fe_stu_marks_filter",
    //   "data": payload
    // };

    var data = {
      "se": "fe_stu_marks_filter",
      "data": {
        "faculty":selectedFaculty,
        "exam_session":selectedExamSession,
        "class_id":selectedClass,
        "center":selectedCenter,
        "marksfrom":marksFrom,
        "marksto":marksTo
      }
    };

    console.log("data===============");
    console.log(data);
    var redata: any = await this.apiService.post(data);
  console.log("redata===============");
  console.log(redata);
    if (redata.status == '0') {
    // console.log(redata.data);
      return redata.data;
    } else {
      this.utitilitiesService.openSnackBar(redata.msg);
      return false;
    }
  }
  async fetchRejectStudentExam(selectedExamSession: any) {
    var data = {
      "se": "fe_rejact_exam_stu",
      "data": { 
       
        "exam_session":selectedExamSession,
      
      }
    };
    console.log("data===============");
    console.log(data);
    var redata: any = await this.apiService.post(data);
  console.log("redata===============");
  console.log(redata);
    if (redata.status == '0') {
    // console.log(redata.data);
      return redata.data;
    } else {
      this.utitilitiesService.openSnackBar(redata.msg);
      return false;
    }
  }
  async fetchMeritListReport(selectedFaculty: string, selectedExamSession: any, selectedClass: any) {
    var data = {
      "se": "fe_merit_list",
      "data": { 
        "faculty":selectedFaculty,
        "exam_sessions":selectedExamSession,
        "class_id":selectedClass,
      }
    };
    var redata: any = await this.apiService.post(data);
  console.log("redata===============");
  console.log(redata);
    if (redata.status == '0') {
    // console.log(redata.data);
      return redata.data;
    } else {
      this.utitilitiesService.openSnackBar(redata.msg);
      return false;
    }
  }
 async fetchAdmissionCardDetails(selectedExam: any, selectedCenter: any, rollNo: string) {
    var data = {
      "se": "fe_stu_card",
      "data": { 
        "exam_sessions":selectedExam,
        "center":selectedCenter,
        "roll_no":rollNo,
      }
    };
    var redata: any = await this.apiService.post(data);
  console.log("redata===============");
  console.log(redata);
    if (redata.status == '0') {
    // console.log(redata.data);
      return redata.data;
    } else {
      this.utitilitiesService.openSnackBar(redata.msg);
      return false;
    }
  }
  async fetchCenterWiseStudentTotals(selectedExam: any, selectedCenter: any, selectedGender: string, selectedOrderBy: string) {
    var data = {
      "se": "fe_stu_tot_center",
      "data": { 
        "exam_sessions":selectedExam,
        "center":selectedCenter,
        "gender":selectedGender,
       "orderby":selectedOrderBy
      }
    };
    var redata: any = await this.apiService.post(data);
  console.log("redata===============");
  console.log(redata);
    if (redata.status == '0') {
    // console.log(redata.data);
    var resdata={
      "students":redata.data,
      "classes":redata.class_wise_count
    }
      return resdata;
    } else {
      this.utitilitiesService.openSnackBar(redata.msg);
      return false;
    }
  }
async  fetchStudentByCityWise(selectedCity: any, selectedExam: any, selectedState: any, page: number, limit: number) {
    var data = {
      "se": "fe_stu_rep_stat_city",
      "data": { 
        "exam_sessions":selectedExam,
        "state":selectedState,
        "city":selectedCity,
        "page": page,
        "limit": limit
      }
    };
    var redata: any = await this.apiService.post(data);
  // console.log("redata===============");
  // console.log(redata);
    if (redata.status == '0') {
    // console.log(redata.data);
      return redata.data;
    } else {
      this.utitilitiesService.openSnackBar(redata.msg);
      return false;
    }
  }
  async fetchStudentByCenterwise(selectedCenter: any, selectedExam: any, selectedGender: any, fromDate: any, toDate: any, page: number, limit: number) {
    var data = {
      "se": "fe_stu_centewise",
      "data": { 
        "exam_sessions":selectedExam,
        "gender":selectedGender,
        "from_date":fromDate,
        "to_date":toDate,
        "center":selectedCenter,
        "page": page,
        "limit": limit
      }
    };
    var redata: any = await this.apiService.post(data);
  console.log("redata===============");
  console.log(redata);
    if (redata.status == '0') {
    // console.log(redata.data);
      return redata.data;
    } else {
      this.utitilitiesService.openSnackBar(redata.msg);
      return false;
    }
  }
 
 async addMarks(studentids: any[], selectedExam: any, selectedClass: any, selectedFaculty: any, selectedChecker: any, bundleNo: any) {
   
    var data = {
      "se": "cr_marks ",
      "data": {"students":studentids,"exam_session":selectedExam,"class_id":selectedClass,"faculty":selectedFaculty,"copy_checker_id":selectedChecker,"bandal_no":bundleNo}  
    };
    var redata: any = await this.apiService.post(data);
  // console.log(redata);

    this.utitilitiesService.openSnackBar(redata.msg);
  }
 async fetchStudentAttendance(selectedCenter: any, selectedExam: any, selectedClass: any, page: number, limit: number) {
    var data = {
      "se": "fe_attend",
      "data": { 
        "exam_sessions":selectedExam,
        "class_id":selectedClass,
        "center":selectedCenter,
        "page": page,
        "limit": limit
      }
    };
    var redata: any = await this.apiService.post(data);
  // console.log("redata===============");
  // console.log(redata);
    if (redata.status == '0') {
    // console.log(redata.data);
      return redata.data;
    } else {
      this.utitilitiesService.openSnackBar(redata.msg);
      return false;
    }
  }
 async updateAttendance(row_id: any, selectedExam: any, selectedClass: any, selectedFaculty: any, selectedCenter: any, status: any,remarks:any) {
   
    var data = {
      "se": "up_attend_st ",
      "data": {"row_id":row_id,"exam_session":selectedExam,"class_id":selectedClass,"faculty":selectedFaculty,"center":selectedCenter,"status":status,"remarks":remarks}  
    };
    console.log("data===============");
    console.log(data);
    var redata: any = await this.apiService.post(data);
    console.log(redata);

    this.utitilitiesService.openSnackBar(redata.msg);
  }
 async fetchClassesByFaculty(selectedFaculty: any, page: number, limit: number) {
    var data = {
      "se": "fe_class_fac",
      "data": { 
        "faculty":selectedFaculty
      }
    };
    var redata: any = await this.apiService.post(data);
  // console.log("redata===============");
  // console.log(redata);
    if (redata.status == '0') {
    // console.log(redata.data);
      return redata.data;
    } else {
      this.utitilitiesService.openSnackBar(redata.msg);
      return false;
    }
  }

 async fetchExameByFaculty(selectedFaculty: any, page: number, limit: number) {
    var data = {
      "se": "fe_exam_fac",
      "data": { 
        "faculty":selectedFaculty
      }
    };
    var redata: any = await this.apiService.post(data);
  // console.log("redata===============");
  // console.log(redata);
    if (redata.status == '0') {
    // console.log(redata.data);
      return redata.data;
    } else {
      this.utitilitiesService.openSnackBar(redata.msg);
      return false;
    }
  }
 async fetchStudentsByFilterWithChecker(selectedFaculty: any, selectedExam: any, selectedClass: any, selectedChecker: any, page: number, limit: number) {
    var data = {
      "se": "fe_stu_ass_bandal",
      "data": { "exam_sessions": selectedExam, "class_id": selectedClass,"copy_checker_id":selectedChecker, "faculty": selectedFaculty, "page": page, "limit": limit }
    };
    var redata: any = await this.apiService.post(data);
    console.log("redata=========");
    console.log(redata);
    if (redata.status == '0') {
      // console.log(redata.data);
      return redata.data;
    } else {
      this.utitilitiesService.openSnackBar(redata.msg);
      return false;
    }
  }
 async fetchStudentsByFilter(selectedFaculty: any, selectedExam: any, selectedClass: any, page: number, limit: number) {
    var data = {
      "se": "fe_bandal_not_stu ",
      "data": { "exam_sessions": selectedExam, "class_id": selectedClass, "faculty": selectedFaculty, "page": page, "limit": limit }
    };
    var redata: any = await this.apiService.post(data);
    // console.log(redata);
    if (redata.status == '0') {
      // console.log(redata.data);
      return redata.data;
    } else {
      this.utitilitiesService.openSnackBar(redata.msg);
      return false;
    }
  }
 async  fetchLatestBundlNo(page: number, limit: number) {
    var data = {
      "se": "fe_bandalNo",
      "data": { }
    };
    var redata: any = await this.apiService.post(data);
  // console.log(redata);
    if (redata.status == '0') {
    // console.log(redata.data);
      return redata.data;
    } else {
      this.utitilitiesService.openSnackBar(redata.msg);
      return false;
    }
  }

   async  fetchLatestCenterCode(page: number, limit: number) {
    var data = {
      "se": "fe_center_co",
      "data": { }
    };
    var redata: any = await this.apiService.post(data);
  // console.log(redata);
    if (redata.status == '0') {
    // console.log(redata.data);
      return redata.data;
    } else {
      this.utitilitiesService.openSnackBar(redata.msg);
      return false;
    }
  }

  async createBundle(selectedStudents: any, selectedExam: any, selectedClass: any, selectedFaculty: any, selectedChecker: any, bundleNo: any) {
    var data = {
      "se": "cr_band",
      "data": {
        "exam_session":selectedExam,
        "class_id":selectedClass,
        "student_ids":selectedStudents,
        "copy_checker_id":selectedChecker,
        "faculty":selectedFaculty
      }
    };
    var redata: any = await this.apiService.post(data);
    // console.log(redata);

    this.utitilitiesService.openSnackBar(redata.msg);
  }
  async assignExamtoStudent(rowId: any, selectedExam: any, selectedClass: any, selectedCenter: any,selectedFaculty:any) {
   
    var data = {
      "se": "map_stu_center ",
      "data": {
        "row_id":rowId,
        "exam_sessions":selectedExam,
        "class_id":selectedClass,
        "center":selectedCenter,
        "faculty":selectedFaculty
      }
    };
    console.log("data===============");
    console.log(data);
    var redata: any = await this.apiService.post(data);
    console.log(redata);

    this.utitilitiesService.openSnackBar(redata.msg);
  }
  async fechExam(page: number, limit: number) {
    var data = {
      "se": "fe_session ",
      "data": { "page": page, "limit": limit }
    };
    var redata: any = await this.apiService.post(data);
    // console.log(redata);
    if (redata.status == '0') {
      // console.log(redata.data);
      return redata.data;
    } else {
      this.utitilitiesService.openSnackBar(redata.msg);
      return false;
    }
  }
  async saveExam(savedForm: any, selectedRowId: any) {
    if (selectedRowId != undefined) {
      savedForm["row_id"] = selectedRowId;
    }
    var data = {
      "se": "cr_session ",
      "data": savedForm
    };
    var redata: any = await this.apiService.post(data);
    // console.log(redata);

    this.utitilitiesService.openSnackBar(redata.msg);
  }
  async fetchSheetCheckers(page: number, limit: number) {
    var data = {
      "se": "fe_checker ",
      "data": { "page": page, "limit": limit }
    };
    var redata: any = await this.apiService.post(data);
    // console.log(redata);
    if (redata.status == '0') {
      // console.log(redata.data);
      return redata.data;
    } else {
      this.utitilitiesService.openSnackBar(redata.msg);
      return false;
    }
  }
  async saveSheetChecker(savedForm: any, selectedRowId: any) {
    if (selectedRowId != undefined) {
      savedForm["row_id"] = selectedRowId;
    }
    var data = {
      "se": "cr_checker ",
      "data": savedForm
    };
    var redata: any = await this.apiService.post(data);
    // console.log(redata);

    this.utitilitiesService.openSnackBar(redata.msg);

  }
  async fetchClasses(page: number, limit: number) {
    var data = {
      "se": "fe_class",
      "data": { "page": page, "limit": limit }
    };
    var redata: any = await this.apiService.post(data);
    // console.log(redata);
    if (redata.status == '0') {
      // console.log(redata.data);
      return redata.data;
    } else {
      this.utitilitiesService.openSnackBar(redata.msg);
      return false;
    }
  }
  async saveClasses(savedForm: any, selectedRowId: any) {
    if (selectedRowId != undefined) {
      savedForm["row_id"] = selectedRowId;
    }
    var data = {
      "se": "cr_class ",
      "data": savedForm
    };
    var redata: any = await this.apiService.post(data);
    // console.log(redata);

    this.utitilitiesService.openSnackBar(redata.msg);
  }
  async fetchExamCenter(page: number, limit: number) {
    var data = {
      "se": "fe_center ",
      "data": { "page": page, "limit": limit }
    };
    var redata: any = await this.apiService.post(data);
    // console.log(redata);
    if (redata.status == '0') {
      // console.log(redata.data);
      return redata.data;
    } else {
      this.utitilitiesService.openSnackBar(redata.msg);
      return false;
    }
  }
  async saveExamCenter(savedForm: any, selectedRowId: any) {
    if (selectedRowId != undefined) {
      savedForm["row_id"] = selectedRowId;
    }
    var data = {
      "se": "cr_center ",
      "data": savedForm
    };
    var redata: any = await this.apiService.post(data);
    // console.log(redata);

    this.utitilitiesService.openSnackBar(redata.msg);
  }
  async fetchAllUsersData(page: number, limit: number) {
    var data = {
      "se": "fe_us",
      "data": { "page": page, "limit": limit }
    };
    var redata: any = await this.apiService.post(data);
    // console.log(redata);
    if (redata.status == '0') {
      // console.log(redata.data);
      return redata.data;
    } else {
      this.utitilitiesService.openSnackBar(redata.msg);
      return false;
    }
  }
  async saveUsers(savedForm: any, selectedRowId: any) {
    var data = {
      "se": "sa_us",
      "data": { "userdata": savedForm, "row_id": selectedRowId }
    };
    var redata: any = await this.apiService.post(data);
    // console.log(redata);

    this.utitilitiesService.openSnackBar(redata.msg);
  }
  // when page load wordpress data save in usres table 
  async fetchStudents(page: any = null, limit: any = null) {
    var data = {
      "se": "fe_stu",
      "data": {
        "page": page,
        "limit": limit
      }
    };
    var redata: any = await this.apiService.post(data);
  // console.log("redata======questions");
  // console.log(redata);
    if (redata.status == 0) {
      // console.log(redata.data);
      return redata.data;
    } else {
      this.utitilitiesService.openSnackBar(redata.msg);
      return false;
    }
  }

   async fetchfaculty(page: any = null, limit: any = null) {
    var data = {
      "se": "fe_fec",
      "data": {
        "page": page,
        "limit": limit
      }
    };
    var redata: any = await this.apiService.post(data);
  // console.log("redata======questions");
  // console.log(redata);
    if (redata.status == 0) {
      // console.log(redata.data);
      return redata.data;
    } else {
      this.utitilitiesService.openSnackBar(redata.msg);
      return false;
    }
  }

  async savestudent(savedForm: any, selectedRowId: any) {
    if (selectedRowId != undefined) {
      savedForm["row_id"] = selectedRowId;
    }
    var data = {
      "se": "cr_stu",
      "data": savedForm
    };
    var redata: any = await this.apiService.post(data);
    // console.log(redata);

    this.utitilitiesService.openSnackBar(redata.msg);

  }

    async savefaculty(savedForm: any, selectedRowId: any) {
    if (selectedRowId != undefined) {
      savedForm["row_id"] = selectedRowId;
    }
    var data = {
      "se": "cr_fac",
      "data": savedForm
    };
    var redata: any = await this.apiService.post(data);
    // console.log(redata);

    this.utitilitiesService.openSnackBar(redata.msg);

  }

  async fetchBranches(page: any = null, limit: any = null) {
    var data = {
      "se": "fe_branch",
      "data": {
        "page": page,
        "limit": limit
      }
    };
    var redata: any = await this.apiService.post(data);
  // console.log("redata======questions");
  // console.log(redata);
    if (redata.status == 0) {
      // console.log(redata.data);
      return redata.data;
    } else {
      this.utitilitiesService.openSnackBar(redata.msg);
      return false;
    }
  }

  async saveBranch(savedForm: any, selectedRowId: any) {
    if (selectedRowId != undefined) {
      savedForm["row_id"] = selectedRowId;
    } var data = {
      "se": "cr_branch",
      "data": savedForm
    };
    console.log("saveBranch");
    console.log(savedForm);
    var redata: any = await this.apiService.post(data);
    // console.log(redata);

    this.utitilitiesService.openSnackBar(redata.msg);

  }




  constructor(private apiService: ApiService, private authService: AuthService, private utitilitiesService: UtiltiesService, private uploadFileService: UploadFileService, private router: Router) { }



  async loginUser(logindata: any) {
    var data = {
      "fn": "common_fn",
      "se": "lo_us",
      "data": { "user_name": logindata.username, "user_password": logindata.password }
    };
  // console.log(data)
    var redata: any = await this.apiService.postUrl(data, 'user');
  // console.log(redata);
    if (redata.status == '0') {
    // console.log(redata.data);
      this.authService.setToken(redata.data['token']);
    } else {
      this.utitilitiesService.openSnackBar(redata.msg);
    }
  }




  async fetchCount(tb: string) {
    var data = {
      "se": "fe_count",
      "data": { "tablename": tb }
    };
    var redata: any = await this.apiService.post(data);
    // console.log(redata);
    if (redata.status == '0') {
      return redata.data;
    } else {
      return false;
    }
  }

  async CenterWiseAmountReport(selectedExamSession: any, selectedCenter: any,selectedAccount:any) {
    var data = {
      "se": "fe_stu_center_wiseAmm",
      "data": {        
        "exam_sessions":selectedExamSession,
        "center":selectedCenter,
        "account_no":selectedAccount,

      }
    };
    var redata: any = await this.apiService.post(data);
  console.log("redata===============");
  console.log(redata);
    if (redata.status == '0') {
    // console.log(redata.data);
      return redata;
    } else {
      this.utitilitiesService.openSnackBar(redata.msg);
      return false;
    }
  }

  async StudentExamLog(selectedStudents: any) {
    var data = {
      "se": "fe_exam_log",
      "data": {        
        "student":selectedStudents, 

      }
    };
    var redata: any = await this.apiService.post(data);
  console.log("redata===============");
  console.log(redata);
    if (redata.status == '0') {
    // console.log(redata.data);
      return redata.data;
    } else {
      this.utitilitiesService.openSnackBar(redata.msg);
      return false;
    }
  }


    async fetchStudentById(id: any) {
    const data = {
      se: "fe_stu_by_id", // <-- You need to handle this 'se' key on your backend
      data: {
        id: id
      }
    };
  
    const redata: any = await this.apiService.post(data);
  
    if (redata.status === 0) {
      return redata.data; // returns a single student object
    } else {
      this.utitilitiesService.openSnackBar(redata.msg);
      return false;
    }
  }


}

