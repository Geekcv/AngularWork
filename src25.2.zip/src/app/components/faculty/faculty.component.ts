import { Component, ViewChild } from '@angular/core';
import { FormsService } from 'src/app/constants/forms.service';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service';
import { FormBuilderComponent } from 'src/app/custom-components/form-builder/form-builder.component';
import { UtiltiesService } from 'src/app/services/utilties.service';

@Component({
  selector: 'app-faculty',
  templateUrl: './faculty.component.html',
  styleUrls: ['./faculty.component.css']
})

export class FacultyComponent {
  @ViewChild(FormBuilderComponent) formBuilderComponent!: FormBuilderComponent;
  constructor(public formsService: FormsService, private apiController: ApicontrollerService, public utiltiesService: UtiltiesService) { }
  selectedRowId: any;
  searchFields: any =  this.formsService.facultyTableData.searchFields;
  tableData: any = [];
  tableDataHeader: any = this.formsService.facultyTableData.tableDataHeader;
  tableDataRows: any = this.formsService.facultyTableData.tableDataRows;

  tableTitle: any =  this.formsService.facultyTableData.title;
  savedForm: any = {};
  isFormValid: boolean = false;
  totalRecords: any=100;
  limit: any = 100;
  noofpage: any = 1;
  ngOnInit() {
    this.fetchCount();
    this.fetchFacultys();
  }

  async saveQuestion() {
 // console.log("Client Saved");
 // console.log(this.savedForm);
    var tempData=this.savedForm;
    await this.apiController.savefaculty(tempData, this.selectedRowId);
    this.resetForm();
    this.fetchFacultys();

  }

  onFormValidityChange(isValid: boolean) {
    this.isFormValid = isValid;
  }
  resetForm() {
    this.savedForm = {};
    this.selectedRowId = null;
  }

  async fetchFacultys(page = 1, limit = 5) {
    var tempClientDAta = await this.apiController.fetchfaculty(page, limit);
    if (tempClientDAta != false) {
      this.tableData = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        this.tableData.push(
          {
            "row_id": tempClientDAta[i].row_id,
            "faculty_name": tempClientDAta[i].faculty_name
          }
        );
      }
     // console.log("this.tableData========");
     // console.log(this.tableData);
    }
  }

 
 editClient(cl: any) {
   console.log(cl);
    // this.savedForm=cl.data;
    this.savedForm.faculty=cl.faculty_name;

    
    this.selectedRowId = cl.row_id;
   // console.log(this.savedForm);
  }

  deleteClient(cl: any) {
   // console.log(cl);
  }

  fetchNextData(row: any) {
   // console.log("fetchNextData");
    const page = row.page;
    const limit = row.limit;
   // console.log(page, limit);
    this.fetchFacultys(page, limit);
  }
  async fetchCount() {
    var totRec = await this.apiController.fetchCount('faculty');
 // console.log(totRec);
    if (totRec != false) {
      this.totalRecords = totRec;
      this.noofpage = Math.ceil(this.totalRecords / this.limit);
     // console.log(this.totalRecords);
    }
    this.fetchFacultys();
  }

}