import { Component } from '@angular/core';
import { JsonListService } from 'src/app/constants/json-list.service';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service';
import { UtiltiesService } from 'src/app/services/utilties.service';

@Component({
  selector: 'app-student-marks-filter-report',
  templateUrl: './student-marks-filter-report.component.html',
  styleUrls: ['./student-marks-filter-report.component.css']
})
export class StudentMarksFilterReportComponent {

  // Dropdown options
  examSessions: any[] = [];
  classes: any[] = [];
  centers: any[] = [];
    faculty:any[]=[];

  

  // Selected filter values
    selectedFaculty: any = null;
  selectedExamSession: any = null;
  selectedClass: any = null; // Optional filter
  selectedCenter: any = null; // Optional filter
  marksFrom: number | null = null;
  marksTo: number | null = null;
  temCenter:any = []


  // Data for the report table
  filteredMarksData: any[] = [];
  submitted: boolean = false;

  constructor(
    private apiController: ApicontrollerService,
    private utiltiesService: UtiltiesService,
    public jsonlist: JsonListService // For dropdown data
  ) { }

  ngOnInit(): void {
    this.loadInitialData();
    this.fetchClasses(); // Fetch initial classes based on default faculty
  }

  async loadInitialData() {
    // Fetch exam sessions
    this.examSessions = [];
    // Fetch centers (assuming you want all centers initially)
    this.centers =  [];
    this.faculty = []
    this.classes = []
    this.fetchExams();
    this.fetchExamCenter();
    this.fetchfaculty();

  }

  async fetchExams(page = 1, limit = 500) {
    var tempClientDAta = await this.apiController.fetchExameByFaculty(this.selectedFaculty,page, limit);
    if (tempClientDAta != false) {
      this.examSessions = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        this.examSessions.push(
          {
            name: tempClientDAta[i].session_name, // Changed to 'name' for consistency with HTML
            data: tempClientDAta[i],
            id: tempClientDAta[i].row_id // Changed to 'id' for consistency with HTML
          }
        );
      }
    }

     if (tempClientDAta === false) {
      this.examSessions = []; // Clear existing students
      
    }
  }


  async fetchExamCenter(page = 1, limit = 500) {
    var tempClientDAta = await this.apiController.fetchExamCenter(page, limit);
    if (tempClientDAta != false) {
      this.centers = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        this.centers.push(
          {
            name: tempClientDAta[i].center, // Changed to 'name' for consistency with HTML
            data: tempClientDAta[i], // Keep original data if needed (e.g., for code)
            id: tempClientDAta[i].row_id, // Changed to 'id' for consistency with HTML
            title: tempClientDAta[i].center + "-" +tempClientDAta[i].center_code, 
            code: tempClientDAta[i].center_code

          }
        );
      }
      this.temCenter = this.centers;
    }
  }



  async fetchClasses(page = 1, limit = 500) {
    
 
    var tempClientDAta = await this.apiController.fetchClassesByFaculty(this.selectedFaculty, page, limit);
    if (tempClientDAta != false) {
      this.classes = [];
      this.selectedClass = null; // Reset class when faculty changes
    this.submitted = false;
      for (var i = 0; i < tempClientDAta.length; i++) {
        this.classes.push({
          title: tempClientDAta[i].class_name,
          data: tempClientDAta[i],
          value: tempClientDAta[i].row_id
        });
      }
    }

    this.fetchExams()
  }

       async fetchfaculty(page = 1, limit = 500) {
    // Use the renamed 'students' property
    var tempClientDAta = await this.apiController.fetchfaculty(page, limit);
    if (tempClientDAta != false) {
    // console.log("exams========",tempClientDAta);
      this.faculty = []; // Clear existing students
      for (var i = 0; i < tempClientDAta.length; i++) {
        // Map fetched data to the structure expected by the table/dialog
        // Ensure 'name' and 'rollNo' properties exist for the template
        this.faculty.push(
          {
            title: tempClientDAta[i].faculty_name, 
            data: tempClientDAta[i], // Keep original data if needed
            value: tempClientDAta[i].row_id
          }
        );
      }
    }
  }


  async fetchFilteredMarks() {
    this.submitted = true;
    this.filteredMarksData = []; // Clear previous results
    if (!this.selectedFaculty || !this.selectedExamSession) {
      console.error("Please select Faculty and Exam Session.");
      return;
    }

    // Validate marks range if both are entered
    if (this.marksFrom !== null && this.marksTo !== null && this.marksFrom > this.marksTo) {
        this.utiltiesService.openSnackBar("Marks 'From' value cannot be greater than 'To' value.");
        return;
    }


    console.log('Fetching filtered marks for:', this.selectedFaculty, this.selectedExamSession, this.selectedClass, this.selectedCenter, this.marksFrom, this.marksTo);

    // Call API to fetch filtered marks list
    const fetchedData = await this.apiController.fetchStudentMarks(
        this.selectedFaculty,
        this.selectedExamSession,
        this.selectedClass, // Pass null if not selected
        this.selectedCenter, // Pass null if not selected
        this.marksFrom, // Pass null if not entered
        this.marksTo // Pass null if not entered
    ) || []; // Create this API call

    // Map fetchedData to the structure needed by the table
    this.filteredMarksData = fetchedData.map((item: any) => ({
        rollNo: item.roll_no,
        bandalNo: item.bandal_no,
        centerCode: item.center_code,
        centerName: item.center_name,
        sheetChecker: item.sheet_checker_name, // Adjust field name based on API
        className: item.class_name,
        marks: item.marks,
        id: item.row_id // Or another unique identifier
    }));
    console.log('Fetched filtered marks:', this.filteredMarksData);
  }

  // --- Helper methods for display ---
  getSessionName(id: any): string | null {
    const item = this.examSessions.find(e => e.id === id);
    return item ? item.name : null;
  }

  getClassName(id: any): string | null {
    const item = this.classes.find(c => c.id === id);
    return item ? item.name : null;
  }

  getCenterName(id: any): string | null {
    const item = this.centers.find(c => c.id === id);
    return item ? item.name : null;
  }
  // --- End Helper methods ---

  exportData() {
    if (this.filteredMarksData && this.filteredMarksData.length > 0) {
      console.log("Exporting data...", this.filteredMarksData);
      this.filteredMarksData.forEach((item: any) => {
        delete item.id;

      });
      this.utiltiesService.exportAsExcelFile(this.filteredMarksData, 'FilteredMarksReport');
    } else {
      console.warn("No data to export.");
    }
  }

  printReport() {
    this.utiltiesService.printReport('report', 'StudentMarksFilterReport'); // Adjust the ID of the report section
  }

  getFacultyName(id: any): string | null {
    // const item = this.jsonlist.faculty.find(e => e.value === id);
    const item = this.faculty.find(e => e.value === id);
    return item ? item.title : null;
  }

}
