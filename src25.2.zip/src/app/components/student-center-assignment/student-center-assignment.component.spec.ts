import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StudentCenterAssignmentComponent } from './student-center-assignment.component';

describe('StudentCenterAssignmentComponent', () => {
  let component: StudentCenterAssignmentComponent;
  let fixture: ComponentFixture<StudentCenterAssignmentComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StudentCenterAssignmentComponent]
    });
    fixture = TestBed.createComponent(StudentCenterAssignmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
