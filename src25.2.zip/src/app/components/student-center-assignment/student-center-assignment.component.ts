import { Component } from '@angular/core';

@Component({
  selector: 'app-student-center-assignment',
  templateUrl: './student-center-assignment.component.html',
  styleUrls: ['./student-center-assignment.component.css']
})
export class StudentCenterAssignmentComponent {

}
