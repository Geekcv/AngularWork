import { Component, OnInit } from '@angular/core';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service'; // Adjust path
import { UtiltiesService } from 'src/app/services/utilties.service'; // Adjust path

@Component({
  selector: 'app-center-wise-student-total',
  templateUrl: './center-wise-student-total.component.html',
  styleUrls: ['./center-wise-student-total.component.css']
})
export class CenterWiseStudentTotalComponent implements OnInit {

  // Dropdown options
  examSessions: any[] = [];
  transposedData: any[] = [];
  centers: any[] = [];
  orderByOptions: any[] = [
      { label: 'Class+Roll No', value: 'roll_no' },
      { label: 'Class+Name', value: 'name' }
  ];

  // Selected filter values
  selectedExamSession: any = null;
  selectedCenter: any = null;
  selectedGender: string = 'All'; // Default value
  selectedOrderBy: string = 'roll_no'; // Default value

  // Data for the report table
  reportData: any[] = []; 
  students:any=[];// e.g., [{ className: 'Class 10', maleCount: 15, femaleCount: 10, totalCount: 25 }, ...]
  grandTotalMale: number = 0;
  grandTotalFemale: number = 0;
  grandTotal: number = 0;
  temCenter:any = []


  constructor(
    private apiController: ApicontrollerService,
    private utiltiesService: UtiltiesService // For export
  ) { }

  ngOnInit(): void {
    this.loadInitialData();
  }

  async loadInitialData() {
    // Fetch exam sessions
    this.examSessions =  []; // Adapt API call
    // Fetch centers
    this.centers = []; // Adapt API call
    // Map data if needed to {name: '...', id: '...'} format for dropdowns
    this.fetchExams();
    this.fetchExamCenter();
  }

  async fetchExams(page = 1, limit = 500) {
    var tempClientDAta = await this.apiController.fechExam(page, limit);
    if (tempClientDAta != false) {
      this.examSessions = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        this.examSessions.push(
          {
            name: tempClientDAta[i].session_name, // Changed to 'name' for consistency with HTML
            data: tempClientDAta[i],
            id: tempClientDAta[i].row_id // Changed to 'id' for consistency with HTML
          }
        );
      }
    }
  }


  async fetchExamCenter(page = 1, limit = 500) {
    var tempClientDAta = await this.apiController.fetchExamCenter(page, limit);
    if (tempClientDAta != false) {
      this.centers = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        this.centers.push(
          {
            name: tempClientDAta[i].center, // Changed to 'name' for consistency with HTML
            data: tempClientDAta[i], // Keep original data if needed (e.g., for code)
            id: tempClientDAta[i].row_id, // Changed to 'id' for consistency with HTML
            title: tempClientDAta[i].center + "-" +tempClientDAta[i].center_code, 
            code: tempClientDAta[i].center_code

          }
        );
      }
      this.temCenter = this.centers;
    }
  }

  async fetchReportData() {
    if (!this.selectedExamSession ) {
      console.error("Please select Exam Session and Gender and OrderBy.");
      this.reportData = [];
      // this.calculateTotals(); // Reset totals
      return;
    }
    console.log('Fetching report data for:', this.selectedExamSession, this.selectedCenter, this.selectedGender, this.selectedOrderBy);

    // Call API to fetch aggregated student counts based on filters
    const fetchedData = await this.apiController.fetchCenterWiseStudentTotals(
        this.selectedExamSession,
        this.selectedCenter,
        this.selectedGender,
        this.selectedOrderBy
    ) || []; // Create this API call

    // Assuming API returns data like [{ class_name: 'Class 10', male_count: 15, female_count: 10, total_count: 25 }, ...]
    // this.reportData = fetchedData.map((item: any) => ({
    //     className: item.class_name,
    //     maleCount: item.male_count || 0,
    //     femaleCount: item.female_count || 0,
    //     totalCount: item.total_count || 0
//     // Add other fields if needed
// }));

this.reportData = []; this.students = []; // Clear existing students before adding new ones
  
this.transposedData = [];
// Check if fetchedData is the expected object type and has the 'students' property
if (!Array.isArray(fetchedData) && 'students' in fetchedData) {
    const tempClientDAta = fetchedData.students; // Access students safely
     for(var i=0; i < tempClientDAta.length; i++){
    var  age = this.utiltiesService.calculateAge(new Date(tempClientDAta[i].dob));
      this.students.push(
        {
          rollNo: tempClientDAta[i].roll_no,
          studentName: tempClientDAta[i].student_name,
          fatherName: tempClientDAta[i].father_name,
          address: tempClientDAta[i].address,
          aadharNo: tempClientDAta[i].aadhar_no, // Adjust field names as per your API response
          phone: tempClientDAta[i].phone,
          age:age,
          class: tempClientDAta[i].class_name, // Assuming class name is needed
          accountNo: tempClientDAta[i].account_no,
          accountName: tempClientDAta[i].account_name,
          ifscCode: tempClientDAta[i].ifsc_code,

            }
          )
        }
        for(var i=0;i<fetchedData.classes.length;i++){
          this.reportData.push(
            {
              "Class":fetchedData.classes[i]['class_name'],
              "Total":fetchedData.classes[i]['total_students']
            }
          );
        }
        const keys = Object.keys(this.reportData[0]);
        this.transposedData = keys.map(key => {
          return {
            key,
            values: this.reportData.map(item => item[key])
          };
        });
    } else {
        // Handle the case where fetchedData is an array (e.g., the fallback []) or lacks 'students'
        this.students = []; // Ensure students array is empty
        console.warn("No student data found or data format incorrect.");
    }
    // this.calculateTotals(); // This seems to operate on reportData, not students
    console.log('Processed students:', this.students); // Log the processed students array
  }
  
  calculateTotals() {
      this.grandTotalMale = this.reportData.reduce((sum, row) => sum + (row.maleCount || 0), 0);
      this.grandTotalFemale = this.reportData.reduce((sum, row) => sum + (row.femaleCount || 0), 0);
      this.grandTotal = this.reportData.reduce((sum, row) => sum + (row.totalCount || 0), 0);
  }

  // --- Helper methods for display ---
  getSessionName(id: any): string | null {
    const item = this.examSessions.find(e => e.id === id);
    return item ? item.name : null;
  }

  getCenterName(id: any): string | null {
    const item = this.centers.find(c => c.id === id);
    return item ? item.name : null;
  }

  getCenterCode(id: any): string | null {
    const item = this.centers.find(c => c.id === id);
    // Adjust based on your center data structure
    return item ? item.data?.center_code : null;
  }

  getOrderByName(value: string): string | null {
      const item = this.orderByOptions.find(o => o.value === value);
      return item ? item.label : null;
  }
  // --- End Helper methods ---

  exportData() {
    if (this.reportData && this.reportData.length > 0) {
      console.log("Exporting data...", this.reportData);
     
      this.utiltiesService.exportTablesToExcel(this.students, this.transposedData, 'CenterWiseStudentTotalReport');
      // this.utiltiesService.exportAsExcelFile(dataToExport, 'CenterWiseStudentTotalReport');
    } else {
      console.warn("No data to export.");
    }
  }

  printReport() {
    this.utiltiesService.printReport('report', 'CenterWiseStudentTotalReport');
  }
  
}
