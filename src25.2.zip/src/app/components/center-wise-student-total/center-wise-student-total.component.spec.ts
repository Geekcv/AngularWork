import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CenterWiseStudentTotalComponent } from './center-wise-student-total.component';

describe('CenterWiseStudentTotalComponent', () => {
  let component: CenterWiseStudentTotalComponent;
  let fixture: ComponentFixture<CenterWiseStudentTotalComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CenterWiseStudentTotalComponent]
    });
    fixture = TestBed.createComponent(CenterWiseStudentTotalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
