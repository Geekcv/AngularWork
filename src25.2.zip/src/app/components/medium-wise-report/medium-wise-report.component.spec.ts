import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MediumWiseReportComponent } from './medium-wise-report.component';

describe('MediumWiseReportComponent', () => {
  let component: MediumWiseReportComponent;
  let fixture: ComponentFixture<MediumWiseReportComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [MediumWiseReportComponent]
    });
    fixture = TestBed.createComponent(MediumWiseReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
