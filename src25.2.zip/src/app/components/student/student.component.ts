import { Component, ElementRef, Input, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormsService } from 'src/app/constants/forms.service';
import { JsonListService } from 'src/app/constants/json-list.service';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service';
import { FormBuilderComponent } from 'src/app/custom-components/form-builder/form-builder.component';
import { UtiltiesService } from 'src/app/services/utilties.service';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css'],
})
export class StudentComponent {
  @ViewChild(FormBuilderComponent) formBuilderComponent!: FormBuilderComponent;
  constructor(
    public formsService: FormsService,
    private apiController: ApicontrollerService,
    public utiltiesService: UtiltiesService,
    private route: ActivatedRoute,
    private router: Router,
    private jsonList: JsonListService
  ) {}
  selectedRowId: any;
  searchFields: any = this.formsService.studentTableData.searchFields;
  tableData: any = [];
  tableDataHeader: any = this.formsService.studentTableData.tableDataHeader;
  tableDataRows: any = this.formsService.studentTableData.tableDataRows;

  tableTitle: any = this.formsService.studentTableData.title;
  savedForm: any = {};
  isFormValid: boolean = false;
  totalRecords: any = 100;
  limit: any = 100;
  noofpage: any = 1;
  studentId: string | null = null;

  @ViewChild('student_name') studentNameRef!: ElementRef;

  async ngOnInit() {
    this.studentId = this.route.snapshot.paramMap.get('id');

    if (this.studentId) {
      await this.loadStudentById(this.studentId);
    } else {
      await this.fetchCount();
      await this.fetchStudents();
      this.initializeFormDefaults();
    }
  }

  initializeFormDefaults() {
    this.savedForm['medium'] = 'hindi';
    this.savedForm['dob'] = new Date();
    this.savedForm['gender'] = 'm';

    setTimeout(() => {
      const mediumOption = this.jsonList.medium.find(
        (m: any) => m.value === 'hindi'
      );
      if (mediumOption && this.formBuilderComponent) {
        this.formBuilderComponent.searchValues['medium'] = mediumOption.title;
      }

      this.formBuilderComponent.searchValues['country'] = '';
      this.formBuilderComponent.searchValues['state'] = '';
      this.formBuilderComponent.searchValues['city'] = '';
    }, 0);
  }

  listStudents() {
    this.router.navigate(['/list-students']);
  }

  //   async saveQuestion() {
  //  // console.log("Client Saved");
  //  // console.log(this.savedForm);
  //     var tempData=this.savedForm;

  //     console.log("mobile no",this.savedForm.mobile_no)
  //     if(this.savedForm.mobile_no  || this.savedForm.phone_o  || this.savedForm.phone_r){
  //       console.log("save ")
  //     }else if(this.savedForm.mobile_no,length <10  || this.savedForm.phone_o<10  || this.savedForm.phone_r<10){
  //       console.log("no save ")

  //     }else{
  //     await this.apiController.savestudent(tempData, this.selectedRowId);
  //     this.resetForm();
  //     this.fetchStudents();
  //     this.savedForm.medium = "hindi"
  //     }

  //   }

  async saveQuestion() {
    const data = this.savedForm;

    const mobile = data.mobile_no?.toString().trim() || '';
    const phoneO = data.phone_o?.toString().trim() || '';
    const phoneR = data.phone_r?.toString().trim() || '';
    const ifsc = data.ifsc_code?.toString().trim() || '';

    const isMobileValid = !mobile || /^\d{10}$/.test(mobile);
    const isPhoneOValid = !phoneO || /^\d{10}$/.test(phoneO);
    const isPhoneRValid = !phoneR || /^\d{10}$/.test(phoneR);
    const isIFSCValid = !ifsc || /^[A-Za-z0-9]{11}$/.test(ifsc);

    if (!isMobileValid || !isPhoneOValid || !isPhoneRValid || !isIFSCValid) {
      console.error(
        'Validation failed: Phone numbers must be 10 digits. IFSC must be 11 alphanumeric characters.'
      );
      return;
    }

    if (this.studentId) {
      // If editing an existing student, reload the student data
      await this.apiController.savestudent(data, this.selectedRowId);
    } else {
      // If adding a new student, reset the form and refresh list
      await this.apiController.savestudent(data, this.selectedRowId);

      this.resetForm();
      await this.fetchStudents();
      this.initializeFormDefaults();
    }
  }

  async loadStudentById(id: string) {
    const studentData = await this.apiController.fetchStudentById(id);
    console.log('stud', studentData);
    if (!studentData) {
      console.error('Student not found for id:', id);
      this.router.navigate(['/list-students']);
      return;
    }

    // Format dob for input type="date"
    // Convert dob string to Date object (for p-calendar)
    if (studentData.dob) {
      studentData.dob = new Date(studentData.dob);
      console.log('dadta', studentData.dob);
    }

    this.savedForm = studentData;
    this.selectedRowId = id;
    this.formBuilderComponent.formdata = { ...studentData };

    const countryOption = this.formBuilderComponent.filteredOptions[
      'country'
    ]?.find((s: any) => s.value == studentData.country);
    if (countryOption) {
      this.formBuilderComponent.searchValues['country'] = countryOption.title;
    }

    const stateOption = this.formBuilderComponent.filteredOptions[
      'state'
    ]?.find((s: any) => s.value == studentData.state);
    if (stateOption) {
      this.formBuilderComponent.searchValues['state'] = stateOption.title;
    }

    console.log('students--------->', studentData.country);
    // this.formBuilderComponent.updateStateOptions(studentData.country)
    // this.formBuilderComponent.updateCityOptions(studentData.state);

    const cityOption = this.formBuilderComponent.filteredOptions['city']?.find(
      (c: any) => c.value == studentData.city
    );
    if (cityOption) {
      this.formBuilderComponent.searchValues['city'] = cityOption.title;
    }

    const mediumOption = this.jsonList.medium.find(
      (m: any) => m.value == studentData.medium
    );
    if (mediumOption) {
      this.formBuilderComponent.searchValues['medium'] = mediumOption.title;
    }
  }

  onFormValidityChange(isValid: boolean) {
    this.isFormValid = isValid;
  }
  resetForm() {
    this.savedForm = {};
    this.selectedRowId = null;
  }

  async fetchStudents(page = 1, limit = 5) {
    var tempClientDAta = await this.apiController.fetchStudents(page, limit);
    if (tempClientDAta != false) {
      this.tableData = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        this.tableData.push({
          student_name: tempClientDAta[i].student_name,
          father_name: tempClientDAta[i].father_name,
          dob: new Date(tempClientDAta[i].dob).toLocaleDateString(),
          address: tempClientDAta[i].address,
          mobile: tempClientDAta[i].mobile_no,
          data: tempClientDAta[i],
          rowId: tempClientDAta[i].row_id,
          zip_code: tempClientDAta[i].zip_code,
          ahhar_no: tempClientDAta[i].ahhar_no,
          phone_r: tempClientDAta[i].phone_r,
          phone_o: tempClientDAta[i].phone_o,
          medium: tempClientDAta[i].medium,
          account_no: tempClientDAta[i].account_no,
          account_name: tempClientDAta[i].account_name,
          bank_name: tempClientDAta[i].bank_name,
          roll_no: tempClientDAta[i].roll_no,
          ifsc_code: tempClientDAta[i].ifsc_code,
          education: tempClientDAta[i].education,
          center_code: tempClientDAta[i].center_code,
          cr_on: new Date(tempClientDAta[i].cr_on).toDateString(),
        });
      }
      // console.log("this.tableData========");
      // console.log(this.tableData);
    }
  }

  editClient(cl: any) {
    // console.log(cl);
    this.savedForm = cl.data;
    this.savedForm.dob = new Date(cl.data.dob);

    this.selectedRowId = cl.rowId;
    // console.log(this.savedForm);
  }
  deleteClient(cl: any) {
    // console.log(cl);
  }

  fetchNextData(row: any) {
    // console.log("fetchNextData");
    const page = row.page;
    const limit = row.limit;
    // console.log(page, limit);
    this.fetchStudents(page, limit);
  }
  async fetchCount() {
    var totRec = await this.apiController.fetchCount('students');
    // console.log(totRec);
    if (totRec != false) {
      this.totalRecords = totRec;
      this.noofpage = Math.ceil(this.totalRecords / this.limit);
      // console.log(this.totalRecords);
    }
    // this.fetchStudents();
  }
}
