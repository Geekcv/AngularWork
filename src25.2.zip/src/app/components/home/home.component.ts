import { Component } from '@angular/core';
import { Router } from '@angular/router';

import { MenuItem } from 'primeng/api';
import { AuthService } from 'src/app/services/auth.service';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  items: MenuItem[] | undefined;
  routes: MenuItem[] | undefined;
  activeItem: any;
  userRole: any;

  constructor(private authService: AuthService, private router: Router) {
  }

  ngOnInit() {
    this.routes = [

      {
        label: 'Student Management',
        "icon": "pi pi-fw pi-users",
        "id": "users",
        items: [
          
          {
            label: 'Create Student', routerLink: '/students',
            "icon": "pi pi-fw pi-user-edit",
            "id": "create-student"

          },
          
          {
            label: 'list of Student', routerLink: '/list-students',
            "icon": "pi pi-fw pi-file-edit",
            "id": "list-students"

          },
          {
            label: 'Student Attendance', routerLink: '/attendance',
            "icon": "pi pi-fw pi-check-circle",
            "id": "attendance"

          },
         
         

        ]
      },
      {
        label: 'Exam Management',
        "icon": "pi pi-fw pi-calendar-times",
        "id": "exams",
        items: [

          {
            label: 'Exam', routerLink: '/exam',

            "icon": "pi pi-fw pi-calendar-plus",
            "id": "programs"

          },
          {
            label: 'Exam Center',
            routerLink: '/exam-center',
            "icon": "pi pi-fw pi-shop",
            "id": "exam-center"
          },
          {
            label: 'Bundle',
            routerLink: '/bundle',
            "icon": "pi pi-fw pi-box",
            "id": "bundle"
          },

          {
            label: 'Sheet Checker', 
            routerLink: '/checker',

            "icon": "pi pi-fw pi-check-square",
            "id": "checker"

          }
        ]
      },   {
        label: 'Reports',
        "icon": "pi pi-fw pi-file",
        "id": "marks",
        items: [

          {
            label: 'Student Center Wise Report', 
            routerLink: '/center-wise-students',

            "icon": "pi pi-fw pi-file",
            "id": "center-wise-students"

          },
          {
            label: 'Student State/City Wise Report', 
            routerLink: '/city-wise-students',

            "icon": "pi pi-fw pi-file",
            "id": "city-wise-students"

          },
          {
            label: 'Center Wise Total Student Report', 
            routerLink: '/center-wise-total-students',

            "icon": "pi pi-fw pi-file",
            "id": "center-wise-total-students"

          },
          {
            label: 'Admission Card', 
            routerLink: '/admission-card',

            "icon": "pi pi-fw pi-id-card",
            "id": "admission-card'"

          },
          {
            label: 'Merit List Report', 
            routerLink: '/merit-list',

            "icon": "pi pi-fw pi-graduation-cap",
            "id": "merit-list"

          },
          {
            label: 'Merit List Center WiseReport', 
            routerLink: '/merit-list-center-wise',

            "icon": "pi pi-fw pi-graduation-cap",
            "id": "merit-list-center-wise"

          },
          {
            label: 'Reject Exam Report', 
            routerLink: '/reject-exam',

            "icon": "pi pi-fw pi-ban",
            "id": "reject-exam"

          },
          {
            label: 'Student Marks Report', 
            routerLink: '/student-marks',

            "icon": "pi pi-fw pi-percentage",
            "id": "student-marks"

          },
          {
            label: 'Student Marks Filter Report', 
            routerLink: '/student-marks-filter',

            "icon": "pi pi-fw pi-percentage",
            "id": "student-marks-filter"

          },
          {
            label: 'Center Wise Amount Report', 
            routerLink: '/center-wise-amount',

            "icon": "pi pi-fw pi-percentage",
            "id": "center-wise-amount-report"

          },
          // {
          //   label: 'Medium Wise Report', 
          //   routerLink: '/medium-wise-report',

          //   "icon": "pi pi-fw pi-percentage",
          //   "id": "medium-wise-report"
          // }
        ]
      },
      {
        label: 'Classes Management',
        "icon": "pi pi-fw pi-calendar",
        "id": "classes",
        items: [

          {
            label: 'Class', 
            routerLink: '/class',

            "icon": "pi pi-fw pi-calendar-plus",
            "id": "classes"

          }
        ]
      },
      {
        label: 'Branch Management',
        "icon": "pi pi-fw pi-warehouse",
        "id": "branch",
        items: [

          {
            label: 'Branch', 
            routerLink: '/branch',

            "icon": "pi pi-fw pi-warehouse",
            "id": "branch"

          }
        ]
      },
      {
        label: 'Marks Management',
        "icon": "pi pi-fw pi-percentage",
        "id": "marks",
        items: [

          {
            label: 'Add Marks', 
            routerLink: '/marks',

            "icon": "pi pi-fw pi-percentage",
            "id": "marks"

          }
        ]
      }, 
      {
        label: 'Faculty',
        "icon": "pi pi-users",
        "id": "faculty",
        items: [

          {
            label: 'Add Faculty', 
            routerLink: '/faculty',

            "icon": "pi pi-plus-circle",
            "id": "faculty"

          }
        ]
      }, 
    
    ];
    this.items = this.routes;
    // this.items = this.getRoutes();

   // console.log(this.items);

  }


  // getRoutes() {


  //   const allowedPanels = this.authService.getUserAllowedPanels();

  //   return this.routes?.filter(route => allowedPanels.includes(route.id));
  // }
  logout() {
    this.authService.logoutUser();
  }
}
