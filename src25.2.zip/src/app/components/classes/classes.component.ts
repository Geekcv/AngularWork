import { Component, ViewChild } from '@angular/core';
import { FormsService } from 'src/app/constants/forms.service';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service';
import { FormBuilderComponent } from 'src/app/custom-components/form-builder/form-builder.component';
import { UtiltiesService } from 'src/app/services/utilties.service';

@Component({
  selector: 'app-classes',
  templateUrl: './classes.component.html',
  styleUrls: ['./classes.component.css']
})
export class ClassesComponent {
 @ViewChild(FormBuilderComponent) formBuilderComponent!: FormBuilderComponent;
  constructor(public formsService: FormsService, private apiController: ApicontrollerService, public utiltiesService: UtiltiesService) { }
  selectedRowId: any;
  searchFields: any =  this.formsService.classTableData.searchFields;
  tableData: any = [];
  tableDataHeader: any = this.formsService.classTableData.tableDataHeader;
  tableTitle: any =  this.formsService.classTableData.title;
  tableDataRows:any = this.formsService.classTableData.tableDataRows;
  savedForm: any = {};
  isFormValid: boolean = false;
  totalRecords: any=100;
  limit: any = 100;
  noofpage: any = 1;
  feculty:any=[];
  exams: any[] = [];
  
  ngOnInit() {
    this.exams = [];

    this.fetchCount();
    this.fetchStudents();
    this.fetchfaculty();
    // this.fetchExams();


  }



  async saveQuestion() {
 // console.log("Client Saved");
 // console.log(this.savedForm);
    var tempData=this.savedForm;
    await this.apiController.saveClasses(tempData, this.selectedRowId);
    this.resetForm();
    this.fetchStudents();

  }

  onFormValidityChange(isValid: boolean) {
    this.isFormValid = isValid;
  }
  resetForm() {
    this.savedForm = {};
    this.selectedRowId = null;
  }

  async fetchStudents(page = 1, limit = 100) {
    var tempClientDAta = await this.apiController.fetchClasses(page, limit);
    if (tempClientDAta != false) {
      this.tableData = [];
    // console.log("tempClientDAta========",tempClientDAta);
      for (var i = 0; i < tempClientDAta.length; i++) {
        this.tableData.push(
          {
            "name": tempClientDAta[i].class_name,
            "first_price": tempClientDAta[i].first_price,
            "second_price": tempClientDAta[i].second_price,
            "third_price": tempClientDAta[i].third_price,
          
            "data": tempClientDAta[i],
            "rowId": tempClientDAta[i].row_id,
            "marks_greater_equal_to_90": tempClientDAta[i].marks_greater_equal_to_90,
            "marks_70_to_less_then_90": tempClientDAta[i].marks_70_to_less_then_90,
            "marks_50_to_less_then_70": tempClientDAta[i].marks_50_to_less_then_70,


          }
        );
      }
     // console.log("this.tableData========");
     // console.log(this.tableData);
    }
  }

 
  editClient(cl: any) {
   console.log(cl);
    this.savedForm=cl.data;
    this.savedForm.faculty=cl.data.faculty.toString();
    this.savedForm.name=cl.data.class_name;
    this.selectedRowId = cl.rowId;
   // console.log(this.savedForm);
  }
  deleteClient(cl: any) {
   // console.log(cl);
  }

  fetchNextData(row: any) {
   // console.log("fetchNextData");
    const page = row.page;
    const limit = row.limit;
   // console.log(page, limit);
    this.fetchStudents(page, limit);
  }
  async fetchCount() {
    var totRec = await this.apiController.fetchCount('classes');
   // console.log(totRec);
    if (totRec != false) {
      this.totalRecords = totRec;
      this.noofpage = Math.ceil(this.totalRecords / this.limit);
     // console.log(this.totalRecords);
    }
    this.fetchStudents();
  }

   async fetchfaculty(page = 1, limit = 500) {
    var tempClientDAta = await this.apiController.fetchfaculty(page, limit);
    if (tempClientDAta != false) {
      this.feculty = [];
      var tempOptions: { value: any; title: any; }[] = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        const faculty = tempClientDAta[i];
        this.feculty.push(
          {
            "faculty_name": faculty.faculty_name,            
            "rowId": faculty.row_id
          }
        );
        // Populate tempOptions with appropriate value and title
        tempOptions.push({ value: faculty.row_id, title: faculty.faculty_name });
      }
            
      var tempInd = this.utiltiesService.findIndexByKeyValue(this.formsService.classesForm.elements, 'id', 'faculty');

      // Use type assertion 'as any' or define a proper type for elements with options
      (this.formsService.classesForm.elements[tempInd] as any)['options'] = [...tempOptions];
     // console.log("this.tableData========");
     // console.log(this.tableData);
    }
  }

//  async fetchExams(page = 1, limit = 500) {
//    var tempClientDAta = await this.apiController.fechExam(page, limit);
//     if (tempClientDAta != false) {
//       this.feculty = [];
//       var tempOptions: { value: any; title: any; }[] = [];
//       for (var i = 0; i < tempClientDAta.length; i++) {
//         const examSession = tempClientDAta[i];
//         this.feculty.push(
//           {
//             "session_name": examSession.session_name,            
//             "rowId": examSession.row_id
//           }
//         );
//         // Populate tempOptions with appropriate value and title
//         tempOptions.push({ value: examSession.row_id, title: examSession.session_name });
//       }
            
//       var tempInd = this.utiltiesService.findIndexByKeyValue(this.formsService.classesForm.elements, 'id', 'exam_session');

//       // Use type assertion 'as any' or define a proper type for elements with options
//       (this.formsService.classesForm.elements[tempInd] as any)['options'] = [...tempOptions];
//      // console.log("this.tableData========");
//      // console.log(this.tableData);
//     }
//   }

}
