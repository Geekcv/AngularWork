import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BandalSheetComponent } from './bandal-sheet.component';

describe('BandalSheetComponent', () => {
  let component: BandalSheetComponent;
  let fixture: ComponentFixture<BandalSheetComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [BandalSheetComponent]
    });
    fixture = TestBed.createComponent(BandalSheetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
