import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CenterWiseAmountComponent } from './center-wise-amount.component';

describe('CenterWiseAmountComponent', () => {
  let component: CenterWiseAmountComponent;
  let fixture: ComponentFixture<CenterWiseAmountComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CenterWiseAmountComponent]
    });
    fixture = TestBed.createComponent(CenterWiseAmountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
