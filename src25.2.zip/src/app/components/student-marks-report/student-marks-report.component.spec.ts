import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StudentMarksReportComponent } from './student-marks-report.component';

describe('StudentMarksReportComponent', () => {
  let component: StudentMarksReportComponent;
  let fixture: ComponentFixture<StudentMarksReportComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StudentMarksReportComponent]
    });
    fixture = TestBed.createComponent(StudentMarksReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
