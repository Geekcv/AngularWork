import { Component, OnInit } from '@angular/core';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service'; // Adjust path
import { UtiltiesService } from 'src/app/services/utilties.service'; // Adjust path

@Component({
  selector: 'app-student-marks-report',
  templateUrl: './student-marks-report.component.html',
  styleUrls: ['./student-marks-report.component.css']
})
export class StudentMarksReportComponent implements OnInit {

  // Dropdown options
  examSessions: any[] = [];

  // Selected filter values
  selectedExamSession: any = null;
  bandalNo: string = '';

  // Data
  marksData: any[] = []; // Raw data from API
  pairedMarksData: any[] = []; // Processed data for two-column display
  sheetCheckerName: string | null = null; // Name associated with Bandal No.
  submitted: boolean = false; // To track if submit was clicked

  constructor(
    private apiController: ApicontrollerService,
    private utiltiesService: UtiltiesService // For export
  ) { }

  ngOnInit(): void {
    this.loadInitialData();
  }

  async loadInitialData() {
    // Fetch exam sessions
    this.examSessions =  []; // Adapt API call
    // Map data if needed to {name: '...', id: '...'} format for dropdowns
    this.fetchExams();
  }
  async fetchExams(page = 1, limit = 500) {
    var tempClientDAta = await this.apiController.fechExam(page, limit);
    if (tempClientDAta != false) {
      this.examSessions = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        this.examSessions.push(
          {
            name: tempClientDAta[i].session_name, // Changed to 'name' for consistency with HTML
            data: tempClientDAta[i],
            id: tempClientDAta[i].row_id // Changed to 'id' for consistency with HTML
          }
        );
      }
    }
  }

  async fetchMarksReport() {
    this.submitted = true;
    this.marksData = [];
    this.pairedMarksData = [];
    this.sheetCheckerName = null;
    if (!this.selectedExamSession) {
      console.error("Please select Exam Session");
      return;
    }
    console.log('Fetching marks report for:', this.selectedExamSession);

    // Call API to fetch marks based on session and bandal number
    // This API might return the list of marks AND the sheet checker name
    const response = await this.apiController.fetchMarksByBandal(
        this.selectedExamSession,
        this.bandalNo
    ); // Create this API call

    console.log("res--->1",response)
    console.log("res--->2",response.marks)


    if (response  && Array.isArray(response)) {
        this.marksData = response.map((item: any, index: number) => ({
            sno: index + 1, // Generate S.No based on index
            bandalNo: item.bandal_no, // Adjust field names based on API response
            class: item.class_name,
            rollNo: item.roll_no,
            marks: item.marks,
            id: item.row_id // Or another unique identifier
        }));
        this.sheetCheckerName = response[0].sheet_checker_name || null; // Get checker name from response

        this.preparePairedData(); // Process data for two-column layout
        console.log('Fetched marks data:', this.marksData);
        console.log('Sheet Checker:', this.sheetCheckerName);
    } else {
        console.log("No marks data found or invalid response format.");
    }
  }

  preparePairedData() {
      this.pairedMarksData = [];
      const half = Math.ceil(this.marksData.length / 2);
      for (let i = 0; i < half; i++) {
          const leftItem = this.marksData[i];
          const rightItem = this.marksData[i + half]; // Get corresponding item from the second half
          this.pairedMarksData.push({ left: leftItem, right: rightItem || null }); // Add pair, handle case where right item doesn't exist
      }
      console.log('Paired data:', this.pairedMarksData);
  }

  // --- Helper method for display ---
  getSessionName(id: any): string | null {
    const item = this.examSessions.find(e => e.id === id);
    return item ? item.name : null;
  }
  // --- End Helper method ---

  exportData() {
    if (this.marksData && this.marksData.length > 0) {
      console.log("Exporting data...", this.marksData);
      // Export the raw, single-column data
      this.marksData.forEach((item: any) => {
        delete item.id;

      });
      this.utiltiesService.exportAsExcelFile(this.marksData, `MarksReport_Bandal_${this.bandalNo}`);
    } else {
      console.warn("No data to export.");
    }
  }

  printReport() {
    this.utiltiesService.printReport('report', 'StudentMarksReport'); // Adjust the ID of the report section
  }
}