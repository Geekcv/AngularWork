import { Component, OnInit } from '@angular/core';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service'; // Adjust path
import { UtiltiesService } from 'src/app/services/utilties.service';

@Component({
  selector: 'app-admission-card',
  templateUrl: './admission-card.component.html',
  styleUrls: ['./admission-card.component.css']
})
export class AdmissionCardComponent implements OnInit {

  // Dropdown options
  examSessions: any[] = [];
  centers: any[] = [];

  // Selected filter values
  selectedExamSession: any = null;
  selectedCenter: any = null;
  rollNo: string = '';
  temCenter:any = []


  // Data for the admission card
  admissionData: any = []; // e.g., { permanentRollNo: '...', studentName: '...', ... }
  submitted: boolean = false; // To track if submit was clicked

  constructor(
    private apiController: ApicontrollerService,
    private utiltiesService: UtiltiesService // For export
  ) { }

  ngOnInit(): void {
    this.loadInitialData();
  }

  async loadInitialData() {
    this.examSessions = []; // Adapt API call
    // Fetch centers
    this.centers = []; // Adapt API call
    // Map data if needed to {name: '...', id: '...'} format for dropdowns
    this.fetchExams();
    this.fetchExamCenter();
  }

  getSessionName(examId: any): string | null {
    const exam = this.examSessions.find(e => e.id === examId);
    // console.log("exam============",exam)
    return exam ? exam.name : null;
  }
  async fetchExams(page = 1, limit = 500) {
    var tempClientDAta = await this.apiController.fechExam(page, limit);
    if (tempClientDAta != false) {
      this.examSessions = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        this.examSessions.push(
          {
            name: tempClientDAta[i].session_name, // Changed to 'name' for consistency with HTML
            data: tempClientDAta[i],
            id: tempClientDAta[i].row_id // Changed to 'id' for consistency with HTML
          }
        );
      }
    }
  }


  async fetchExamCenter(page = 1, limit = 500) {
    var tempClientDAta = await this.apiController.fetchExamCenter(page, limit);
    if (tempClientDAta != false) {
      this.centers = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        this.centers.push(
          {
            name: tempClientDAta[i].center, // Changed to 'name' for consistency with HTML
            data: tempClientDAta[i], // Keep original data if needed (e.g., for code)
            id: tempClientDAta[i].row_id, // Changed to 'id' for consistency with HTML
            title: tempClientDAta[i].center + "-" +tempClientDAta[i].center_code, 
            code: tempClientDAta[i].center_code

          }
        );
      }
      this.temCenter = this.centers;
    }
  }

  async fetchAdmissionCard() {
    this.submitted = true; // Mark that submit was attempted
    this.admissionData = []; // Reset previous data
    if (!this.selectedExamSession || !this.selectedCenter) {
      console.error("Please select Exam Session, Center");
      return;
    }
    console.log('Fetching admission card for:', this.selectedExamSession, this.selectedCenter, this.rollNo);

    // Call API to fetch admission card details based on filters
    const fetchedData = await this.apiController.fetchAdmissionCardDetails(
      this.selectedExamSession,
      this.selectedCenter,
      this.rollNo
    ); // Create this API call

    if (fetchedData) {
      // Assuming API returns data matching the fields needed
      for (var i = 0; i < fetchedData.length; i++) {
        var tempdata = {
          permanentRollNo: fetchedData[i].roll_no, // Adjust field names based on API response
          studentName: fetchedData[i].student_name,
          fatherHusbandName: fetchedData[i].father_name,
          addressAndPhone: fetchedData[i].address +"("+fetchedData[i]['mobile_no']+")",
          class: fetchedData[i].class_name,
          examDate: fetchedData[i].exam_date ? new Date(fetchedData[i].exam_date) : null, // Convert to Date if needed
          examinationCenter: fetchedData[i].center_name,
          examName: this.getSessionName(this.selectedExamSession), // Get exam name from ID
          // Add other fields if needed
        };
        this.admissionData.push(tempdata);
      }

      console.log('Fetched admission data:', this.admissionData);
    } else {
      console.log("No admission card data found.");
    }
  }

  printCard() {
this.utiltiesService.printReport('admissionCard','Admission Card'); // Adjust the ID of the element to print
  }
}
