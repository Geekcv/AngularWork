import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdmissionCardComponent } from './admission-card.component';

describe('AdmissionCardComponent', () => {
  let component: AdmissionCardComponent;
  let fixture: ComponentFixture<AdmissionCardComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AdmissionCardComponent]
    });
    fixture = TestBed.createComponent(AdmissionCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
