import { Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import * as XLSX from 'xlsx';
import * as FileSaver from 'file-saver';

const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
const EXCEL_EXTENSION = '.xlsx';

@Injectable({
  providedIn: 'root'
})
export class UtiltiesService {
  formatDateForApi(fromDate: Date) {
    if (fromDate) {
      const day = String(fromDate.getDate()).padStart(2, '0');
      const month = String(fromDate.getMonth() + 1).padStart(2, '0'); // Months are zero-based
      const year = fromDate.getFullYear();
      return `${year}-${month}-${day}`;
    }
    return null; // Return null if fromDate is not provided
  }
  printReport(elementid:string,title:string) {
    const printElement = document.getElementById(elementid);
    if (!printElement) {
      console.error('Element with ID "report" not found.');
      return;
    }
  
    const printContents = printElement.innerHTML;
    const printWindow = window.open(title, '_blank', 'width=800,height=600');
  
    if (printWindow) {
      printWindow.document.open();
      printWindow.document.write(`
        <html>
          <head>
            <title>Print Report</title>
            <style>
              @media print {
                .no-print {
                  display: none !important;
                }
                body, table {
                  font-size: 10px;
                }
                table {
                  border-collapse: collapse;
                  width: 100%;
                }
                th, td {
                  border: 1px solid #000;
                  padding: 4px;
                  text-align: left;
                }
              }
            </style>
          </head>
          <body>
            ${printContents}
            <script>
              window.onload = function() {
                window.print();
                setTimeout(() => window.close(), 500);
              };
            </script>
          </body>
        </html>
      `);
      printWindow.document.close();
    } else {
      console.error('Failed to open print window');
    }
  }
  formateDatetoddmmyyyy(date:Date){
    if (date) {
      const day = String(date.getDate()).padStart(2, '0');
      const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are zero-based
      const year = date.getFullYear();
      return `${day}-${month}-${year}`;
    }
    return null; // Return null if date is not provided

  }
  constructor(private snackbar: MatSnackBar) { }
  openSnackBar(msg: any) {
    this.snackbar.open(msg, 'Close', {
      duration: 2000,
    });
  }
  isEmptyObject(obj: any) {
    return (obj && (Object.keys(obj).length === 0));
  }

  isEmptyValue(value: any): boolean {
    // Consider a value empty if it's undefined, null, 'undefined', 'null', or an empty string
    return value === undefined ||
      value === null ||
      value === 'undefined' ||
      value === 'null' ||
      value === '';
  }

  hasEmptyValue(obj: { [key: string]: any }): boolean {
    // First check if the object is empty
    if (this.isEmptyObject(obj)) {
      return true;
    }

    // Check each key-value pair
    for (const key in obj) {
      if (obj.hasOwnProperty(key)) {
        if (this.isEmptyValue(obj[key])) {
          return true;
        }
      }
    }

    // If no empty value is found
    return false;
  }
  findIndexByKeyValue(arr: any, key: any, value: any) {
    const index = arr.findIndex((object: any) => {
      return object[key] === value;
    });
    return index;
    // console.log(index);
  }

  readExcelFile(evt: any) {
    const file = evt.files[0];
    const reader: FileReader = new FileReader();
    reader.onload = (e: any) => {
      const bstr: string = e.target.result;
      const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });

      const wsname: string = wb.SheetNames[0];
      const ws: XLSX.WorkSheet = wb.Sheets[wsname];
      const headers: string[] = XLSX.utils.sheet_to_json(ws, { header: 1 })[0] as string[];

      const sheetdata = XLSX.utils.sheet_to_json(ws);

     // console.log('Headers:', headers);
     // console.log('Sheet Data:', sheetdata);
      return { headers, sheetdata };
      // You can process the data further here or call another method
    };
    reader.readAsBinaryString(file);
  }
  public exportAsExcelFile(json: any[], excelFileName: string): void {

    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(json);
   // console.log('worksheet', worksheet);
    const workbook: XLSX.WorkBook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };
    const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    //const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'buffer' });
    this.saveAsExcelFile(excelBuffer, excelFileName);
  }

  private saveAsExcelFile(buffer: any, fileName: string): void {
    const data: Blob = new Blob([buffer], {
      type: EXCEL_TYPE
    });
    FileSaver.saveAs(data, fileName + EXCEL_EXTENSION);
  }
  
exportTablesToExcel(tabledata1:any=[], tabledata2:any=[],filename:string) {
  // ----- First Table (Normal) -----
  const table1Header = Object.keys(tabledata1[0]);
  const table1Body = tabledata1.map((obj: { [x: string]: any; }) => table1Header.map(k => obj[k]));

  // ----- Second Table (Transposed, No Header) -----
  const table2Body = tabledata2.map((row: { key: any; values: any; }) => [row.key, ...row.values]);

  // ----- Combine -----
  const combinedData = [
    table1Header,
    ...table1Body,
    [], // Blank row
    ...table2Body
  ];

  const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(combinedData);
  const wb: XLSX.WorkBook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, filename);

  const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  FileSaver.saveAs(new Blob([wbout], { type: 'application/octet-stream' }), filename+'.xlsx');

}

// Helper to transform transposed data to flat format for Excel
formatForExcel(data: any[]) {
  return data.map(row => {
    const formatted: any = { Field: row.key };
    row.values.forEach((v: any, i: number) => {
      formatted[`Value ${i + 1}`] = v;
    });
    return formatted;
  });
}

calculateAge(birthDateInput: Date | string): number {
  let birthDate: Date;

  // Check if birthDateInput is a string and try to parse it
  if (typeof birthDateInput === 'string') {
    birthDate = new Date(birthDateInput);
  } else if (birthDateInput instanceof Date) {
    birthDate = birthDateInput;
  } else {
    // Handle cases where input is neither string nor Date, or parsing failed
    console.error('Invalid birthDate input:', birthDateInput);
    return 0; // Or throw an error, depending on desired behavior
  }

  // Check if the parsed date is valid
  if (isNaN(birthDate.getTime())) {
     console.error('Failed to parse birthDate string:', birthDateInput);
     return 0; // Invalid date
  }

  if (!birthDate) {
    return 0; // Or handle invalid input as needed
  }
  const today = new Date();
  let age = today.getFullYear() - birthDate.getFullYear();
  const monthDiff = today.getMonth() - birthDate.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  // Ensure age is not negative if birthDate is in the future
  return Math.max(0, age);

}
}
