import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { JsonListService } from '../constants/json-list.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private isloggedIn = false;
  private token: string | null = null;

  constructor(private router: Router, private jsonListService: JsonListService) {
    // Try to load token from localStorage on service initialization
    this.token = window.localStorage.getItem('token');
    this.isloggedIn = !!this.token;
  }

  isAuthenticated(): boolean {
    return !!window.localStorage.getItem('token');
  }

  isUserLoggedIn(): boolean {
    const token = window.localStorage.getItem('token');
    console.log('authService token:', token);
    return !!token;
  }

  setUserLoggedIn(isLoggedIn: boolean) {
    this.isloggedIn = isLoggedIn;
  }

  setCurrentRole(role: string | undefined | null) {
    if (role) {
      const userRole = this.jsonListService.userType.find((roleData: any) => roleData.value === role);
      if (userRole) {
        window.localStorage.setItem('userRole', JSON.stringify(userRole));
      }
    }
  }

  getUserRole() {
    const userRole = window.localStorage.getItem('userRole');
    return userRole ? JSON.parse(userRole) : null;
  }

  setToken(token: string | undefined | null) {
    this.token = token ?? null;
    if (this.token) {
      window.localStorage.setItem('token', this.token);
      this.setUserLoggedIn(true);
      this.router.navigate(['/']);
    }
  }

  getToken() {
    if (!this.token) {
      this.token = window.localStorage.getItem('token');
      if (this.token) {
        this.setUserLoggedIn(true);
      }
    }
    return this.token;
  }

  getUserAllowedPanels() {
    const userRole = this.getUserRole();
    return userRole ? userRole.allowedPanels : null;
  }

  logoutUser(): void {
    this.isloggedIn = false;
    this.token = null;
    window.localStorage.removeItem('token');
    window.localStorage.removeItem('userRole');
    this.router.navigate(['/login']);
  }

}
