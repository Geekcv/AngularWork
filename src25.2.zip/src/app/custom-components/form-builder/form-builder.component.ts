import {
  Component,
  EventEmitter,
  Input,
  Output,
  ChangeDetectorRef,
  AfterViewInit,
  ElementRef,
  ViewChild,
} from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';

import { UtiltiesService } from 'src/app/services/utilties.service';

interface FormElementOption {
  title: string;
  value: string;
  co?: string; // for states (country id)
  st?: string; // for cities (state id)
}

interface FormElement {
  id: string;
  type: string;
  label: string;
  required: boolean;
  options: FormElementOption[];
}

@Component({
  selector: 'app-form-builder',
  templateUrl: './form-builder.component.html',
  styleUrls: ['./form-builder.component.css'],
})
export class FormBuilderComponent {
  @Input() forms: any;
  @Input() formdata: any;
  @Output() formdataChange: EventEmitter<any> = new EventEmitter<any>();
  // @Input() form: FormGroup;
  @Output() formChange: EventEmitter<any> = new EventEmitter<any>();
  @Output() formValidityChange: EventEmitter<boolean> =
    new EventEmitter<boolean>();
  Output: any = {};

  searchValues: { [key: string]: string } = {};
  filteredOptions: { [key: string]: any[] } = {};
  showDropdown: { [key: string]: boolean } = {};
  focusedIndex: { [key: string]: number } = {};

  constructor(
    private cdr: ChangeDetectorRef,
    private utilities: UtiltiesService,
    private fb: FormBuilder
  ) {
    // this.form = this.fb.group({});
  }

  ngOnInit() {
    this.forms.elements.forEach((element: any) => {
      if (element.type === 'select-list') {
        this.searchValues[element.id] = '';
        this.filteredOptions[element.id] = element.options;

        if (element.id === 'city' && this.formdata['state']) {
          this.updateCityOptions(this.formdata['state']);
        }
      }
    });
  }

  allowOnlyDigits(event: KeyboardEvent): void {
    const allowedKeys = ['Backspace', 'ArrowLeft', 'ArrowRight', 'Tab'];
    if (!/^\d$/.test(event.key) && !allowedKeys.includes(event.key)) {
      event.preventDefault();
    }
  }

  onPhoneInput(event: any, id: string): void {
    let value = event.target.value.replace(/\D/g, ''); // remove non-digits
    if (value.length > 10) {
      value = value.slice(0, 10); // limit to 10 digits
    }
    this.formdata[id] = value;
  }

  @ViewChild('inputField') inputField: ElementRef | undefined;

  ngAfterViewInit() {
    // Focus on the element if it's available
    if (this.inputField) {
      this.inputField.nativeElement.focus();
    }
  }

  onAalpaNumericInput(event: any, id: string): void {
    let value = event.target.value.replace(/[^a-zA-Z0-9]/g, ''); // remove non-alphanumeric
    if (value.length > 12) {
      value = value.slice(0, 12); // limit to 11 characters
    }
    this.formdata[id] = value;
  }

  filterOptions(id: string, options: any[]) {
    const rawInput = this.searchValues[id] || '';
    const searchTerm = rawInput.trim().toLowerCase();

    this.showDropdown[id] = true;

    let filtered = [];

    if (id === 'state' && this.formdata['country']) {
      const filteredStates = options.filter(
        (state: any) => state.co === this.formdata['country']
      );
      filtered = searchTerm
        ? filteredStates.filter((s: any) =>
            s.title.toLowerCase().includes(searchTerm)
          )
        : filteredStates;
    } else if (id === 'city' && this.formdata['state']) {
      const filteredCities = options.filter(
        (city: any) => city.st === this.formdata['state']
      );
      filtered = searchTerm
        ? filteredCities.filter((c: any) =>
            c.title.toLowerCase().includes(searchTerm)
          )
        : filteredCities;
    } else {
      filtered = searchTerm
        ? options.filter((opt: any) =>
            opt.title.toLowerCase().includes(searchTerm)
          )
        : options;
    }

    this.filteredOptions[id] = filtered;
    this.focusedIndex[id] = 0;

    // Auto-complete and auto-select
    if (filtered.length && searchTerm) {
      const firstMatch = filtered[0];
      if (firstMatch.title.toLowerCase().startsWith(searchTerm)) {
        this.searchValues[id] = firstMatch.title;
        this.formdata[id] = firstMatch.value;
        this.setCaretPositionToEnd(id);

        // Trigger dependent filtering
        if (id === 'country') {
          this.updateStateOptions(firstMatch.value);
          this.formdata['state'] = null;
          this.searchValues['state'] = '';
          this.filteredOptions['city'] = [];
          this.formdata['city'] = null;
          this.searchValues['city'] = '';
        }

        if (id === 'state') {
          this.updateCityOptions(firstMatch.value);
          this.formdata['city'] = null;
          this.searchValues['city'] = '';
        }
      }
    }
  }

  selectOption(id: string, option: any) {
    this.formdata[id] = option.value;
    this.searchValues[id] = option.title;
    this.showDropdown[id] = false;

    if (id === 'country') {
      this.updateStateOptions(option.value);
      this.formdata['state'] = null;
      this.searchValues['state'] = '';
      this.filteredOptions['city'] = [];
      this.formdata['city'] = null;
      this.searchValues['city'] = '';
    }

    if (id === 'state') {
      this.updateCityOptions(option.value);
      this.formdata['city'] = null;
      this.searchValues['city'] = '';
    }
  }

  hideDropdownWithDelay(id: string) {
    setTimeout(() => {
      this.showDropdown[id] = false;
    }, 150);
  }

  handleKeydown(event: KeyboardEvent, id: string) {
    const options = this.filteredOptions[id] || [];
    const maxIndex = options.length - 1;

    if (event.key === 'ArrowDown') {
      event.preventDefault();
      this.focusedIndex[id] = Math.min(this.focusedIndex[id] + 1, maxIndex);
      this.selectOption(id, options[this.focusedIndex[id]]);
    } else if (event.key === 'ArrowUp') {
      event.preventDefault();
      this.focusedIndex[id] = Math.max(this.focusedIndex[id] - 1, 0);
      this.selectOption(id, options[this.focusedIndex[id]]);
    } else if (event.key === 'Enter') {
      event.preventDefault();
    } else if (event.key === 'Tab') {
      // Allow default tab behavior, but close dropdown
      this.showDropdown[id] = false;
    }
  }

  updateStateOptions(selectedCountryId: string) {
    const stateElement = this.forms.elements.find((e: any) => e.id === 'state');
    if (!stateElement) return;

    this.filteredOptions['state'] = stateElement.options.filter(
      (state: any) => `${state.co}` === `${selectedCountryId}`
    );

    this.formdata['state'] = null;
    this.searchValues['state'] = '';
  }

  updateCityOptions(selectedState: string) {
    const cityElement = this.forms.elements.find((e: any) => e.id === 'city');
    if (!cityElement) return;

    this.filteredOptions['city'] = cityElement.options.filter(
      (city: any) => `${city.st}` === `${selectedState}`
    );

    this.formdata['city'] = null;
    this.searchValues['city'] = '';
  }

  setCaretPositionToEnd(id: string) {
    setTimeout(() => {
      const inputEl = document.querySelector(
        `input[name="${id}"]`
      ) as HTMLInputElement;
      if (inputEl) {
        const length = inputEl.value.length;
        inputEl.setSelectionRange(length, length);
        inputEl.focus();
      }
    });
  }
}
