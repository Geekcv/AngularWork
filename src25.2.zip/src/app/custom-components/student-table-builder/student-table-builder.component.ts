import {
  Component,
  EventEmitter,
  Input,
  Output,
  ViewChild,
} from '@angular/core';
import { Router } from '@angular/router';
import { Dropdown } from 'primeng/dropdown';
import { Table } from 'primeng/table';
import { FormsService } from 'src/app/constants/forms.service';
import { JsonListService } from 'src/app/constants/json-list.service';
import { ApicontrollerService } from 'src/app/controllers/apicontroller.service';
import { FormBuilderComponent } from '../form-builder/form-builder.component';
import { UtiltiesService } from 'src/app/services/utilties.service';

@Component({
  selector: 'app-student-table-builder',
  templateUrl: './student-table-builder.component.html',
  styleUrls: ['./student-table-builder.component.css'],
})
export class StudentTableBuilderComponent {
  @ViewChild('dt') dt: Table | undefined;
  @Output() editEvent = new EventEmitter();
  @Output() deleteEvent = new EventEmitter();
  @Output() fetchNextData = new EventEmitter();
  @Input() selectedtableData: any = [];
  @Input() searchFields: any = [];
  @Input() tableTitle: any = 'Record List';
  @Input() totalRecords: any = 4;
  @Input() rows: any = 4;
  @Input() noofpages: any = 4;
  @Input() allowDelete: any = false;
  @Input() allowEdit: any = true;
  @Input() width: any = '75rem';
  @Input() height: any = '85rem';
  @Input() tableData: any = [];
  @Input() filteredData: any = this.tableData;
  loading: any = false;
  viewDialog: boolean = false;
  selectedViewData: any = null;
  Examlogdata: any = [];
  temCenter: any = [];

  // --- Add properties for the dialog ---
  displayDialog: boolean = false;
  displayEditDialog: boolean = false;
  selectedStudent: any = null; // Declare selectedStudent
  exams: any[] = []; // Example: [{label: 'Exam 1', value: 'E1'}, {label: 'Exam 2', value: 'E2'}]
  classes: any[] = []; // Example: [{label: 'Class A', value: 'C1'}, {label: 'Class B', value: 'C2'}]
  centers: any[] = []; // Example: [{id: 1, name: 'Center A'}, {id: 2, name: 'Center B'}] - This holds all centers
  filteredCenters: any[] = []; // For autocomplete suggestions
  selectedFaculty: any = null;
  selectedExam: any = null;
  selectedClass: any = null;
  selectedCenter: any = null;
  faculty: any[] = [];
  city_name: any;
  state_name: any;

  selectedGender: any; // Default to 'All'
  query: any;

  @ViewChild('facultyDropdown') facultyDropdown!: Dropdown;
  @ViewChild(FormBuilderComponent) formBuilderComponent!: FormBuilderComponent;

  constructor(
    public formsService: FormsService,
    private apiController: ApicontrollerService,
    public jsonlist: JsonListService,
    private router: Router,
    private jsonList: JsonListService,
    private utiltiesService: UtiltiesService // For export
  ) {}

  ngOnChanges() {
    this.filteredData = this.tableData;
  }

  ngOnInit() {
    this.filteredData = this.tableData;
    this.loadInitialData();
  }

  ngAfterViewInit() {
    // The focusable element inside p-dropdown is a native input or div with tabindex
    setTimeout(() => {
      this.facultyDropdown.focus();
    }, 100);
  }

  loadInitialData() {
    // Placeholder: Load your exam, class, and center data here
    // Example:
    this.exams = [];
    this.classes = [];
    this.centers = [];
    // this.fetchClasses();
    this.fetchExams();
    this.fetchExamCenter();
    this.fetchfaculty();
  }

  @Input() tableDataHeader: any = [];

  //  tableDataRows: any = this.formsService.studentTableData.tableDataRows;

  @Input() tableDataRows: any = [];

  student_name: any;
  father_name: any;
  address: any;
  city: any;
  state: any;
  zipcode: any;
  dob: any;
  phone_o: any;
  phone_r: any;
  mobile: any;
  education: any;
  medium: any;
  account_no: any;
  account_name: any;
  bank_name: any;
  ifsc_code: any;
  rowId: any;

  async edit(pr: any) {
    this.editEvent.emit(pr);
    this.router.navigate(['/students', pr.rowId], {
      state: { studentData: pr },
    });
  }

  delete(pr: any) {
    this.deleteEvent.emit(pr);
  }

  filterByQuery(query: string): void {
    const trimmedQuery = query.trim().toLowerCase();

    console.log('trimmedQuery', trimmedQuery);
    // this.tableData = trimmedQuery

    this.tableData = this.filterItems(this.filteredData, trimmedQuery);
  }

  openViewDialog(rowItem: any): void {
    this.selectedViewData = rowItem;
    this.viewDialog = true;
  }

  filterGlobal(event: Event) {
    const input = event.target as HTMLInputElement;
    const value = input?.value || '';

    // console.log("data-",value,"filterdata",this.tableData)
    this.tableData = this.filterItems(this.filteredData, value);
  }
  onPageChagne(event: any) {
    this.loading = true;
    // console.log(event);
    var page = event.first / event.rows + 1;

    var nextPage = { page: page, limit: event.rows };
    this.fetchNextData.emit(nextPage);
    this.loading = false;
  }

  sortItems(items: any[], sortField: string, sortOrder: number): any[] {
    if (!sortField || sortOrder === 0) {
      return items;
    }

    return items.sort((a, b) => {
      const value1 = a[sortField];
      const value2 = b[sortField];
      const result = value1 < value2 ? -1 : value1 > value2 ? 1 : 0;
      return sortOrder * result;
    });
  }
  filterItems(items: any[], filter: string): any[] {
    if (!filter) {
      console.log('inside filter ');
      return items;
    }
    return items.filter((item) => {
      console.log('items', item);
      return this.searchFields.some((field: any) => {
        console.log('feild', field);
        return item[field]
          ?.toString()
          .toLowerCase()
          .includes(filter.toLowerCase());
      });
    });
  }
  onSort(event: any) {
    // console.log(event);
    this.loading = true;
    this.tableData = this.sortItems(this.tableData, event.field, event.order);

    this.loading = false;
  }

  // applyFilters(items: any[], filters: any): any[] {
  //   if (!filters || Object.keys(filters).length === 0) {
  //     return items;
  //   }

  //   return items.filter(item => {
  //     // console.log("item=====qq=======", item);

  //     return Object.keys(filters).every(field => {
  //       return Object.keys(filters[field]).every(chfield => {
  //         // console.log("chfield============", chfield);
  //         // console.log("item[field]============");
  //         // console.log(filters[field][chfield]);
  //         const filterValue = filters[field][chfield].value??'';
  //         const filterMatchMode = filters[field][chfield].matchMode || 'contains';
  //         const fieldValue = item[chfield]? item[chfield].toString().toLowerCase() : '';

  //         if (filterMatchMode === 'contains') {
  //           return fieldValue.includes(filterValue.toLowerCase());
  //         }
  //         else if (filterMatchMode === 'startsWith') {
  //           return fieldValue.startsWith(filterValue.toLowerCase());
  //         }
  //         else if (filterMatchMode === 'endsWith') {
  //           return fieldValue.endsWith(filterValue.toLowerCase());
  //         }
  //         else if (filterMatchMode === 'equals') {
  //           return fieldValue === filterValue.toLowerCase();
  //         }
  //         else if (filterMatchMode === 'notEquals') {
  //           return fieldValue !== filterValue.toLowerCase();
  //         }
  //         else if (filterMatchMode === 'notContains') {
  //           return !fieldValue.includes(filterValue.toLowerCase());
  //         }
  //         else if(filterMatchMode==='nofilter'){
  //           return true;
  //         }
  //         return true; // Handle other match modes as needed
  //       });
  //     });
  //   });
  // }

  // onFilterChange(filter: any) {
  //  // console.log(filter);
  //   this.tableData = this.applyFilters(this.filteredData, filter);
  // }

  showActionDialog(student: any) {
    console.log('selected students--->>>', student.data.city);

    const cityOption = this.jsonList.cities_rs.find(
      (m: any) => m.value === student.data.city
    );
    if (cityOption) {
      this.city_name = cityOption.title;
      console.log('city_name', this.city_name);
    }

    const stateOption = this.jsonList.states_rs.find(
      (m: any) => m.value === student.data.state
    );
    if (stateOption) {
      this.state_name = stateOption.title;
      console.log('state_name', this.state_name);
    }

    setTimeout(() => {
      // simulate a user click to open the dropdown panel
      const dropdownEl =
        this.facultyDropdown?.el?.nativeElement.querySelector('.p-dropdown');
      dropdownEl?.dispatchEvent(new Event('click'));
    }, 200); // wait for DOM to fully load

    this.selectedStudent = student; // Set the selected student

    // console.log("selected students---->",student)

    // Reset form fields when opening dialog
    this.selectedExam = null;
    this.selectedClass = null;
    this.selectedCenter = null;
    this.filteredCenters = [];
    this.displayDialog = true; // Show the dialog

    this.fetchExamlogStudent();
  }

  async fetchExamlogStudent() {
    console.log('selected students', this.selectedStudent.rowId);
    var exallogdata = await this.apiController.StudentExamLog(
      this.selectedStudent.rowId
    );

    console.log('res-->', exallogdata);
    if (exallogdata != false) {
      console.log('response dta============', exallogdata);
      this.Examlogdata = []; // Clear existing students
      for (var i = 0; i < exallogdata.length; i++) {
        // Map fetched data to the structure expected by the table/dialog
        // Ensure 'name' and 'rollNo' properties exist for the template
        this.Examlogdata.push({
          name: exallogdata[i].student_name,
          className: exallogdata[i].class_name,
          center: exallogdata[i].center,
          sessionName: exallogdata[i].session_name,
          examDate: exallogdata[i].exam_date,
          marks: exallogdata[i].marks,
        });
      }
    } else {
      this.Examlogdata = []; // Clear existing students
    }
  }

  hideDialog() {
    this.displayDialog = false; // Hide the dialog
    this.selectedStudent = null; // Clear selected student
    this.displayEditDialog = false;
  }

  async assignDetails() {
    if (
      this.selectedStudent &&
      this.selectedExam &&
      this.selectedClass &&
      this.selectedCenter
    ) {
      // console.log('Assigning Details:', {
      //   studentId: this.selectedStudent.rowId, // or another unique ID
      //   studentName: this.selectedStudent.name,
      //   exam: this.selectedExam,
      //   class: this.selectedClass,
      //   center: this.selectedCenter // This will be the selected center object
      // });

      await this.apiController.assignExamtoStudent(
        this.selectedStudent.rowId,
        this.selectedExam,
        this.selectedClass,
        this.selectedCenter,
        this.selectedFaculty
      );
      this.hideDialog(); // Close dialog on successful assignment
    } else {
      console.error('Form is not complete');
      // Optionally show a message to the user
    }
    // Reset the selected values
    this.selectedCenter = null;
    this.searchValues['center'] = ''; // Clear the input box!

    this.selectedStudent = null;
    this.selectedExam = null;
    this.selectedClass = null;
    this.selectedFaculty = null;

    this.fetchStudents();
  }

  async EditDetails() {
    var data = {
      student_name: this.student_name,
      father_name: this.father_name,
      address: this.address,
      city: this.city,
      state: this.state,
      zip_code: this.zipcode,
      dob: this.dob,
      phone_o: this.phone_o,
      phone_r: this.phone_r,
      mobile_no: this.mobile,
      education: this.education,
      medium: this.medium,
      account_no: this.account_no,
      account_name: this.account_name,
      bank_name: this.bank_name,
      ifsc_code: this.ifsc_code,
      gender: this.selectedGender,
    };

    console.log('data edit', data);

    const mobile = this.mobile?.toString() || '';
    const phone_o = this.phone_o?.toString() || '';
    const phone_r = this.phone_r?.toString() || '';
    const ifsc_code = this.ifsc_code?.toString() || '';
    const isMobileValid = mobile.length === 10;
    const isPhoneOValid = phone_o.length === 10;
    const isPhoneRValid = phone_r.length === 10;
    const isIFSCValid = ifsc_code.length === 11;
    const hasAnyPhone = !!(mobile || phone_o || phone_r || ifsc_code);
    // Validate phone numbers if any entered
    if (
      hasAnyPhone &&
      !(isMobileValid || isPhoneOValid || isPhoneRValid || isIFSCValid)
    ) {
      console.log("Don't save — At least one phone number must be 10 digits.");
      return;
    }

    await this.apiController.savestudent(data, this.rowId);
    this.displayEditDialog = false;
    this.fetchStudents();
  }

  async fetchStudents(page = 1, limit = 500) {
    var tempClientDAta = await this.apiController.fetchStudents(page, limit);
    if (tempClientDAta != false) {
      this.tableData = [];
      for (var i = 0; i < tempClientDAta.length; i++) {
        this.tableData.push({
          student_name: tempClientDAta[i].student_name,
          father_name: tempClientDAta[i].father_name,
          dob: new Date(tempClientDAta[i].dob).toLocaleDateString(),
          address: tempClientDAta[i].address,
          mobile: tempClientDAta[i].mobile_no,
          data: tempClientDAta[i],
          rowId: tempClientDAta[i].row_id,
          zip_code: tempClientDAta[i].zip_code,
          ahhar_no: tempClientDAta[i].ahhar_no,
          phone_r: tempClientDAta[i].phone_r,
          phone_o: tempClientDAta[i].phone_o,
          medium: tempClientDAta[i].medium,
          account_no: tempClientDAta[i].account_no,
          account_name: tempClientDAta[i].account_name,
          bank_name: tempClientDAta[i].bank_name,
          roll_no: tempClientDAta[i].roll_no,
          ifsc_code: tempClientDAta[i].ifsc_code,
          education: tempClientDAta[i].education,
          center_code: tempClientDAta[i].center_code,
          cr_on: new Date(tempClientDAta[i].cr_on).toDateString(),
        });
      }
      // console.log("this.tableData========");
      // console.log(this.tableData);
    }
  }

  async fetchClasses(page = 1, limit = 500) {
    // Use the renamed 'students' property
    var tempClientDAta = await this.apiController.fetchClassesByFaculty(
      this.selectedFaculty,
      page,
      limit
    );
    console.log('tem---', tempClientDAta);
    if (tempClientDAta != false) {
      // console.log("classes========",tempClientDAta);
      this.classes = []; // Clear existing students
      for (var i = 0; i < tempClientDAta.length; i++) {
        // Map fetched data to the structure expected by the table/dialog
        // Ensure 'name' and 'rollNo' properties exist for the template
        this.classes.push({
          title: tempClientDAta[i].class_name,
          data: tempClientDAta[i], // Keep original data if needed
          value: tempClientDAta[i].row_id,
        });
      }
    }
    this.fetchExams();

    if (tempClientDAta === false) {
      this.classes = []; // Clear existing students
    }
  }

  async fetchExams(page = 1, limit = 500) {
    // Use the renamed 'students' property
    var tempClientDAta = await this.apiController.fetchExameByFaculty(
      this.selectedFaculty,
      page,
      limit
    );
    console.log('temExam---', tempClientDAta);

    if (tempClientDAta != false) {
      // console.log("exams========",tempClientDAta);
      this.exams = []; // Clear existing students
      for (var i = 0; i < tempClientDAta.length; i++) {
        // Map fetched data to the structure expected by the table/dialog
        // Ensure 'name' and 'rollNo' properties exist for the template
        this.exams.push({
          title: tempClientDAta[i].session_name,
          data: tempClientDAta[i], // Keep original data if needed
          value: tempClientDAta[i].row_id,
        });
      }
    }

    if (tempClientDAta === false) {
      this.exams = []; // Clear existing students
    }
  }

  async fetchExamCenter(page = 1, limit = 500) {
    const tempClientData = await this.apiController.fetchExamCenter(
      page,
      limit
    );
    console.log('data', tempClientData);
    if (tempClientData !== false) {
      this.temCenter = tempClientData.map((item: any) => ({
        title: `${item.center} - ${item.center_code}`,
        code: item.center_code?.toString(),
        value: item.row_id,
        data: item,
      }));
    }
  }

  async fetchfaculty(page = 1, limit = 500) {
    // Use the renamed 'students' property
    var tempClientDAta = await this.apiController.fetchfaculty(page, limit);
    if (tempClientDAta != false) {
      // console.log("exams========",tempClientDAta);
      this.faculty = []; // Clear existing students
      for (var i = 0; i < tempClientDAta.length; i++) {
        // Map fetched data to the structure expected by the table/dialog
        // Ensure 'name' and 'rollNo' properties exist for the template
        this.faculty.push({
          title: tempClientDAta[i].faculty_name,
          data: tempClientDAta[i], // Keep original data if needed
          value: tempClientDAta[i].row_id,
        });
      }
    }
  }

  searchCenter(event: any) {
    // Basic filtering example, adjust as needed
    console.log('serach log', event);
    let query = event.query;

    this.filteredCenters = this.centers.filter((center) => {
      return center.code;
    });
  }

  onFilterChange(event: Event, fieldName: string): void {
    const input = event.target as HTMLInputElement;
    const value = input?.value || '';

    // Apply your filter logic here
    this.tableData = this.applyFilters(this.filteredData, fieldName, value);
  }

  applyFilters(data: any[], fieldName: string, value: string): any[] {
    return data.filter((item) => {
      const fieldValue = item[fieldName]?.toString().toLowerCase() || '';
      return fieldValue.includes(value.toLowerCase());
    });
  }

  allowOnlyDigits(event: KeyboardEvent): void {
    const allowedKeys = ['Backspace', 'ArrowLeft', 'ArrowRight', 'Tab'];
    if (!/^\d$/.test(event.key) && !allowedKeys.includes(event.key)) {
      event.preventDefault();
    }
  }

  // mobile: string = '';
  mobileError: boolean = false;
  phoneRError: boolean = false;
  phoneOError: boolean = false;
  IfscCodeError: boolean = false;

  validateMobile(): void {
    console.log('data', this.mobile);
    if (this.mobile.length < 10) {
      this.mobileError = true;
    } else {
      this.mobileError = false;
    }
    // Block input beyond 10 digits (extra precaution even if maxlength is set)
    if (this.mobile.length > 10) {
      this.mobile = this.mobile.slice(0, 10);
    }
  }

  validatephoneR(): void {
    if (this.phone_r.length < 10) {
      this.phoneRError = true;
    } else {
      this.phoneRError = false;
    }
    // Block input beyond 10 digits (extra precaution even if maxlength is set)
    if (this.phone_r.length > 10) {
      this.phone_r = this.phone_r.slice(0, 10);
    }
  }

  validatePhoneO(): void {
    if (this.phone_o.length < 10) {
      this.phoneOError = true;
    } else {
      this.phoneOError = false;
    }
    // Block input beyond 10 digits (extra precaution even if maxlength is set)
    if (this.phone_o.length > 10) {
      this.phone_o = this.phone_o.slice(0, 10);
    }
  }

  allowAlphanumeric(event: KeyboardEvent): void {
    const char = event.key;
    const isAlphanumeric = /^[a-zA-Z0-9]$/.test(char);
    if (!isAlphanumeric) {
      event.preventDefault();
    }
  }

  validateIfscCode(): void {
    if (this.ifsc_code.length < 11) {
      this.IfscCodeError = true;
    } else {
      this.IfscCodeError = false;
    }
    // Block input beyond 10 digits (extra precaution even if maxlength is set)
    if (this.ifsc_code.length > 11) {
      this.ifsc_code = this.ifsc_code.slice(0, 11);
    }
  }

  searchValues: { [key: string]: string } = {};
  showDropdown: { [key: string]: boolean } = {};
  filteredOptions: { [key: string]: any[] } = {};
  focusedIndex: { [key: string]: number } = {};
  // temCenter: any[] = [];
  // selectedCenter: any;

  filterOptions(id: string) {
    const query = this.searchValues[id]?.toLowerCase() || '';

    if (query.trim() === '') {
      // If the input is empty, show all options
      this.filteredOptions[id] = [...this.temCenter];
    } else {
      this.filteredOptions[id] = this.temCenter.filter(
        (option: { code: string; title: string }) =>
          option.code?.toLowerCase().includes(query) ||
          option.title?.toLowerCase().includes(query)
      );
    }

    this.focusedIndex[id] = 0;
  }

  selectOption(id: string, option: any) {
    this.searchValues[id] = option.title;
    this.selectedCenter = option.value;
    this.showDropdown[id] = false;
  }

  hideDropdownWithDelay(id: string) {
    setTimeout(() => {
      this.showDropdown[id] = false;
    }, 200);
  }

  handleKeydown(event: KeyboardEvent, id: string) {
    const options = this.filteredOptions[id] || [];
    let index = this.focusedIndex[id] ?? -1;

    if (options.length === 0) return;

    if (event.key === 'ArrowDown') {
      index = (index + 1) % options.length;
      this.focusedIndex[id] = index;

      // Select option immediately
      this.selectOption(id, options[index]);

      event.preventDefault();
    } else if (event.key === 'ArrowUp') {
      index = (index - 1 + options.length) % options.length;
      this.focusedIndex[id] = index;

      // Select option immediately
      this.selectOption(id, options[index]);

      event.preventDefault();
    }
  }

  examlogprint: any = false;

  printCard() {
    // this.examlogprint = false;
    this.examlogprint = true; // Set this based on your logic
    this.utiltiesService.printReport('examlog', 'Exam Log'); // Adjust the ID of the element to print
  }
}
