import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StudentTableBuilderComponent } from './student-table-builder.component';

describe('StudentTableBuilderComponent', () => {
  let component: StudentTableBuilderComponent;
  let fixture: ComponentFixture<StudentTableBuilderComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StudentTableBuilderComponent]
    });
    fixture = TestBed.createComponent(StudentTableBuilderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
