import { Component, EventEmitter, Input, Output } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { UtiltiesService } from '../../services/utilties.service';

@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.css']
})
export class FileUploadComponent {
  constructor(private apiService: ApiService,private utilities:UtiltiesService) { }
  @Input() label: string | undefined;
  @Input() name: string | undefined;
  @Input() fileuploadData: any;
  @Output() fileuploadDataChange = new EventEmitter();
  @Input() acceptedFiles: string = "image/*";
  @Output() fileUploaded = new EventEmitter();
  uploadedUrl = '';
  ngOnInit() {
    this.uploadedUrl = this.apiService.apiUrl + 'uploads/';
  }
  upload(file: any) {
   // console.log('uploading file');
   // console.log('file', file);
   // console.log('file', file.originalEvent);
    if(file.originalEvent.body.status==true){
      this.fileuploadData=file.originalEvent.body.data;
      this.fileuploadDataChange.emit(this.fileuploadData);
      this.utilities.openSnackBar(file.originalEvent.body.message);
    }else{
      
      this.utilities.openSnackBar('No file uploaded');
    }
  }

}
