import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './services/auth.guard';
import { LoginComponent } from './components/login/login.component';
import { HomeComponent } from './components/home/home.component';
import { StudentComponent } from './components/student/student.component';
import { CheckerComponent } from './components/checker/checker.component';
import { StudentCenterAssignmentComponent } from './components/student-center-assignment/student-center-assignment.component';
import { MarksComponent } from './components/marks/marks.component';
import { BandalComponent } from './components/bandal/bandal.component';
import { AttendanceComponent } from './components/attendance/attendance.component';
import { BranchComponent } from './components/branch/branch.component';
import { ClassesComponent } from './components/classes/classes.component';
import { ExamCenterComponent } from './components/exam-center/exam-center.component';
import { ExamComponent } from './components/exam/exam.component';
import { ListStudentComponent } from './components/list-student/list-student.component';
import { CenterWiseStudentComponent } from './components/center-wise-student/center-wise-student.component';
import { CenterWiseStudentTotalComponent } from './components/center-wise-student-total/center-wise-student-total.component';
import { CityWiseStudentComponent } from './components/city-wise-student/city-wise-student.component';
import { AdmissionCardComponent } from './components/admission-card/admission-card.component';
import { MeritListComponent } from './components/merit-list/merit-list.component';
import { RejectStudentExamComponent } from './components/reject-student-exam/reject-student-exam.component';
import { StudentMarksReportComponent } from './components/student-marks-report/student-marks-report.component';
import { StudentMarksFilterReportComponent } from './components/student-marks-filter-report/student-marks-filter-report.component';
import { MeritListCenterWiseComponent } from './components/merit-list-center-wise/merit-list-center-wise.component';
import { CenterWiseAmountComponent } from './components/center-wise-amount/center-wise-amount.component';
import { MediumWiseReportComponent } from './components/medium-wise-report/medium-wise-report.component';
import { FacultyComponent } from './components/faculty/faculty.component';

const routes: Routes = [

  {
    path: "",
    component: HomeComponent,
    canActivate: [AuthGuard], 
    children: [
      { path: '', redirectTo: 'list-students', pathMatch: 'full' },
      { path: 'students/:id', component: StudentComponent, canActivate: [AuthGuard]}, 
      { path: 'students', component: StudentComponent, canActivate: [AuthGuard]},    
      { path: 'list-students', component: ListStudentComponent, canActivate: [AuthGuard]},    
      { path: 'checker', component: CheckerComponent, canActivate: [AuthGuard]},    
      { path: 'exam', component: ExamComponent, canActivate: [AuthGuard]},    
      { path: 'exam-center', component: ExamCenterComponent, canActivate: [AuthGuard]},    
      { path: 'class', component: ClassesComponent, canActivate: [AuthGuard]},    
      { path: 'branch', component: BranchComponent, canActivate: [AuthGuard]},    
      { path: 'attendance', component: AttendanceComponent, canActivate: [AuthGuard]},    
      { path: 'bundle', component: BandalComponent, canActivate: [AuthGuard]},    
      { path: 'marks', component: MarksComponent, canActivate: [AuthGuard], },
      { path: 'center-wise-students', component: CenterWiseStudentComponent, canActivate: [AuthGuard], },
      { path: 'city-wise-students', component: CityWiseStudentComponent, canActivate: [AuthGuard], },
      { path: 'center-wise-total-students', component: CenterWiseStudentTotalComponent, canActivate: [AuthGuard], },
      { path: 'student-center', component: StudentCenterAssignmentComponent, canActivate: [AuthGuard], },
      { path: 'admission-card', component: AdmissionCardComponent, canActivate: [AuthGuard], },
      { path: 'merit-list', component: MeritListComponent, canActivate: [AuthGuard], },
      { path: 'reject-exam', component: RejectStudentExamComponent, canActivate: [AuthGuard], },
      { path: 'student-marks', component: StudentMarksReportComponent, canActivate: [AuthGuard], },
      { path: 'student-marks-filter', component: StudentMarksFilterReportComponent, canActivate: [AuthGuard], },
      { path: 'merit-list-center-wise', component: MeritListCenterWiseComponent, canActivate: [AuthGuard], },
      { path: 'center-wise-amount', component: CenterWiseAmountComponent, canActivate: [AuthGuard], },
      { path: 'medium-wise-report', component: MediumWiseReportComponent, canActivate: [AuthGuard], },
      { path: 'faculty', component: FacultyComponent, canActivate: [AuthGuard], },


    ]
  },
  {
    path: "login",
    component: LoginComponent
  },
  {
    path: 'unauthorized',
    component: LoginComponent // Create this component to show an unauthorized access message
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
