import {
  MAT_TOOLTIP_DEFAULT_OPTIONS,
  MAT_TOOLTIP_DEFAULT_OPTIONS_FACTORY,
  MAT_TOOLTIP_SCROLL_STRATEGY,
  MAT_TOOLTIP_SCROLL_STRATEGY_FACTORY,
  MAT_TOOLTIP_SCROLL_STRATEGY_FACTORY_PROVIDER,
  MatTooltip,
  MatTooltipModule,
  SCROLL_THROTTLE_MS,
  TOOLTIP_PANEL_CLASS,
  TooltipComponent,
  getMatTooltipInvalidPositionError,
  matTooltipAnimations
} from "./chunk-O63HT4J3.js";
import "./chunk-UIHZTQ5A.js";
import "./chunk-KGWFVHGB.js";
import "./chunk-ME66J6V6.js";
import "./chunk-RVDIP7WJ.js";
import "./chunk-QKYASU42.js";
import "./chunk-7CNGLZKA.js";
import "./chunk-ZMK3G3X3.js";
import "./chunk-YURQ3VDP.js";
import "./chunk-3KMBDC47.js";
import "./chunk-N3U4OAZ5.js";
import "./chunk-LLH4QHU6.js";
import "./chunk-2MILMYBF.js";
import "./chunk-W4PHOTIT.js";
import "./chunk-ZSY7TSMJ.js";
import "./chunk-RJX5MCQ2.js";
export {
  MAT_TOOLTIP_DEFAULT_OPTIONS,
  MAT_TOOLTIP_DEFAULT_OPTIONS_FACTORY,
  MAT_TOOLTIP_SCROLL_STRATEGY,
  MAT_TOOLTIP_SCROLL_STRATEGY_FACTORY,
  MAT_TOOLTIP_SCROLL_STRATEGY_FACTORY_PROVIDER,
  MatTooltip,
  MatTooltipModule,
  SCROLL_THROTTLE_MS,
  TOOLTIP_PANEL_CLASS,
  TooltipComponent,
  getMatTooltipInvalidPositionError,
  matTooltipAnimations
};
//# sourceMappingURL=@angular_material_tooltip.js.map
