import {
  Platform,
  PlatformModule,
  RtlScrollAxisType,
  _getEventTarget,
  _getFocusedElementPierceShadowDom,
  _getShadowRoot,
  _isTestEnvironment,
  _supportsShadowDom,
  getRtlScrollAxisType,
  getSupportedInputTypes,
  normalizePassiveListenerOptions,
  supportsPassiveEventListeners,
  supportsScrollBehavior
} from "./chunk-LLH4QHU6.js";
import "./chunk-2MILMYBF.js";
import "./chunk-W4PHOTIT.js";
import "./chunk-ZSY7TSMJ.js";
import "./chunk-RJX5MCQ2.js";
export {
  Platform,
  PlatformModule,
  RtlScrollAxisType,
  _getEventTarget,
  _getFocusedElementPierceShadowDom,
  _getShadowRoot,
  _isTestEnvironment,
  _supportsShadowDom,
  getRtlScrollAxisType,
  getSupportedInputTypes,
  normalizePassiveListenerOptions,
  supportsPassiveEventListeners,
  supportsScrollBehavior
};
//# sourceMappingURL=@angular_cdk_platform.js.map
