import {
  MAT_INPUT_CONFIG,
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-6CYHAMAC.js";
import "./chunk-K45EVNJG.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-O7LGD3OU.js";
import "./chunk-V3QJXHVB.js";
import "./chunk-VXO3PQDQ.js";
import "./chunk-UIHZTQ5A.js";
import "./chunk-7CNGLZKA.js";
import "./chunk-ZMK3G3X3.js";
import "./chunk-YURQ3VDP.js";
import "./chunk-3KMBDC47.js";
import "./chunk-N3U4OAZ5.js";
import "./chunk-LLH4QHU6.js";
import "./chunk-2MILMYBF.js";
import "./chunk-W4PHOTIT.js";
import "./chunk-ZSY7TSMJ.js";
import "./chunk-RJX5MCQ2.js";
export {
  MAT_INPUT_CONFIG,
  MAT_INPUT_VALUE_ACCESSOR,
  MatError,
  MatFormField,
  MatHint,
  MatInput,
  MatInputModule,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
