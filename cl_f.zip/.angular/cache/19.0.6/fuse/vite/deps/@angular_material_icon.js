import {
  ICON_REGISTRY_PROVIDER,
  ICON_REGISTRY_PROVIDER_FACTORY,
  MAT_ICON_DEFAULT_OPTIONS,
  MAT_ICON_LOCATION,
  MAT_ICON_LOCATION_FACTORY,
  MatIcon,
  MatIconModule,
  MatIconRegistry,
  getMatIconFailedToSanitizeLiteralError,
  getMatIconFailedToSanitizeUrlError,
  getMatIconNameNotFoundError,
  getMatIconNoHttpProviderError
} from "./chunk-2DLFCW5O.js";
import "./chunk-AVMQOOV2.js";
import "./chunk-VMK56I6P.js";
import "./chunk-7CNGLZKA.js";
import "./chunk-ZMK3G3X3.js";
import "./chunk-YURQ3VDP.js";
import "./chunk-3KMBDC47.js";
import "./chunk-N3U4OAZ5.js";
import "./chunk-LLH4QHU6.js";
import "./chunk-2MILMYBF.js";
import "./chunk-W4PHOTIT.js";
import "./chunk-ZSY7TSMJ.js";
import "./chunk-RJX5MCQ2.js";
export {
  ICON_REGISTRY_PROVIDER,
  ICON_REGISTRY_PROVIDER_FACTORY,
  MAT_ICON_DEFAULT_OPTIONS,
  MAT_ICON_LOCATION,
  MAT_ICON_LOCATION_FACTORY,
  MatIcon,
  MatIconModule,
  MatIconRegistry,
  getMatIconFailedToSanitizeLiteralError,
  getMatIconFailedToSanitizeUrlError,
  getMatIconNameNotFoundError,
  getMatIconNoHttpProviderError
};
//# sourceMappingURL=@angular_material_icon.js.map
