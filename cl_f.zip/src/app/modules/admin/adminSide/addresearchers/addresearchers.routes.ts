import { Routes } from '@angular/router';
import { AddresearchersComponent } from 'app/modules/admin/adminSide/addresearchers/addresearchers.component';

export default [
    {
        path: '',
        component: AddresearchersComponent,
    },
] as Routes;
