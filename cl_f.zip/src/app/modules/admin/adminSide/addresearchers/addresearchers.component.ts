import { Component, inject, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import {
    FormsModule,
    NgForm,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { Router, RouterLink } from '@angular/router';
import { fuseAnimations } from '@fuse/animations';
import { FuseAlertComponent, FuseAlertType } from '@fuse/components/alert';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { AuthService } from 'app/core/auth/auth.service';
import {MatSnackBar} from '@angular/material/snack-bar';
import { HttpClient } from '@angular/common/http';
import { config } from '../../../../../../config';

@Component({
  selector: 'app-addresearchers',
  imports: [
    //RouterLink,
   // FuseAlertComponent,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatCheckboxModule,
    MatProgressSpinnerModule,MatSelectModule
],
  templateUrl: './addresearchers.component.html'
})
export class AddresearchersComponent {
  @ViewChild('schoolNgForm') schoolNgForm: NgForm;

  schoolForm: UntypedFormGroup;
  showAlert = false;
  role: any = '';
  config: any;
  filepath: any;
  mediatype: any;

  constructor(
      private _formBuilder: UntypedFormBuilder,
      private _router: Router,
      private api: ApicontrollerService,
      private http: HttpClient
  ) {
      this.config = config.apiBaseURL;
      this.role = localStorage.getItem('role');
  }

  private _snackBar = inject(MatSnackBar);

  ngOnInit(): void {
      this.schoolForm = this._formBuilder.group({
          name: ['', Validators.required],
          email: ['', [Validators.required, Validators.email]],
          phone: ['', Validators.required],
          address: ['', Validators.required],
          board_id: [''],
          is_active: [true],
      });
  }

  async addSchool(): Promise<void> {
      if (this.schoolForm.invalid) {
          this.schoolForm.markAllAsTouched();
          return;
      }

      const payload = {
          ...this.schoolForm.value,
          created_by: localStorage.getItem('row_id') || '', // optional
      };

      const resp = await this.api.createschool(payload);

      if (resp.status === 0) {
          this._snackBar.open(resp.msg, '', {
              duration: 3000,
              verticalPosition: 'top',
              horizontalPosition: 'center',
          });

          this.schoolNgForm.resetForm();
      } else {
          this._snackBar.open(resp.msg || 'Failed to add school', '', {
              duration: 3000,
              verticalPosition: 'top',
              horizontalPosition: 'center',
          });
      }
  }

  onSchoolLogoSelected(event: Event): void {
      const input = event.target as HTMLInputElement;
      if (input.files && input.files.length > 0) {
          const file = input.files[0];
          const formData = new FormData();
          formData.append('file', file);

          this.http.post(`${this.config}/common/upload`, formData).subscribe({
              next: (response: any) => {
                  this.filepath = response.data.foPa || response.data.filePath;
                  this.mediatype = response.data.mimetype;
                  console.log('Uploaded File:', this.filepath);
              },
              error: (error) => {
                  console.error('Upload failed:', error);
              },
          });
      }
  }

}
