import { Component, inject, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import {
    FormsModule,
    NgForm,
    ReactiveFormsModule,
    UntypedFormBuilder,
    UntypedFormGroup,
    Validators,
} from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { Router, RouterLink } from '@angular/router';
import { fuseAnimations } from '@fuse/animations';
import { FuseAlertComponent, FuseAlertType } from '@fuse/components/alert';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { AuthService } from 'app/core/auth/auth.service';
import {MatSnackBar} from '@angular/material/snack-bar';
import { HttpClient } from '@angular/common/http';
import { config } from '../../../../../../config';

@Component({
  selector: 'app-addresearchers',
  imports: [
    //RouterLink,
   // FuseAlertComponent,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatCheckboxModule,
    MatProgressSpinnerModule,MatSelectModule
],
  templateUrl: './addresearchers.component.html'
})
export class AddresearchersComponent {

 @ViewChild('signUpNgForm') signUpNgForm: NgForm;

    alert: { type: FuseAlertType; message: string } = {
        type: 'success',
        message: '',
    };
    signUpForm: UntypedFormGroup;
    showAlert: boolean = false;
    role :any ='';

    genders: string[] = ['Male', 'Female', 'Other']; // List of genders
    doctorType:string[]=['Dermatologist','Neurologist','Cardiologist','Psychiatrist','Gastroenterologist','Family medicine']
    /**
     * Constructor
     */
    constructor(
        private _authService: AuthService,
        private _formBuilder: UntypedFormBuilder,
        private _router: Router,
        private Apicontroller: ApicontrollerService,private router: Router,private http: HttpClient
    ) {

      this.role=  localStorage.getItem('role')

      // console.log("my role",this.role)
    }

    private _snackBar = inject(MatSnackBar);

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void {
        // Create the form
        this.signUpForm = this._formBuilder.group({
          doctor_fname: ['', Validators.required],
          doctor_lname: ['', Validators.required],
          doctor_email: ['', [Validators.required, Validators.email]],
          doctor_phone: ['', Validators.required],
          doctor_password: ['', Validators.required],
          // doctor_type: ['', Validators.required],
          doctor_gender: ['', Validators.required],
          institution: ['', Validators.required],


            //company: [''],
            //agreements: ['', Validators.requiredTrue],
        });
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * Sign up
     */
 

    async addresearchers(){

      // console.log(this.signUpForm.value)

     const resp = await this.Apicontroller.createdoctor(this.signUpForm.value);




    
      if (resp.status === 0) {
      

        const email = this.signUpForm.value.doctor_email;
        
                // this.http
                //     .post(`${config.apiBaseURL}/common/email/login`, {
                //       email,
                //     })
                //     .subscribe({
                //         next: (res: any) => {
                //             console.log("res---",res)
                           
                         
                //         },
                //         error: (err) => {
                //             console.log("err---",err)
                            
                //         },
                //         complete: () => {
                //             console.log("rcompletees---",)
                         
                //         },
                //     });

                this.http
                    .post(`${config.apiBaseURL}/common/auth/email`, {
                      email,
                    })
                    .subscribe({
                        next: (res: any) => {
                            console.log("res---",res)
                           
                         
                        },
                        error: (err) => {
                            console.log("err---",err)
                            
                        },
                        complete: () => {
                            console.log("rcompletees---",)
                         
                        },
                    });
        
        
        
        this._snackBar.open(resp.msg, '', {
          duration: 3000, // Duration in milliseconds (3 seconds)
          verticalPosition: 'top', // Position: 'top' | 'bottom'
          horizontalPosition: 'center', // Position: 'start' | 'center' | 'end' | 'left' | 'right'
        });

        this._router.navigate(['/Viewresearchers'])


      }else{
       // this.messageService.add({ severity: 'error', summary: 'Error', detail: resp.msg });
       console.log("error ")
      } 
    }

}
