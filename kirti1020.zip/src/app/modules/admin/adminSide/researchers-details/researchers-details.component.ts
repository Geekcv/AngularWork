import { AsyncPipe, CommonModule } from '@angular/common';
import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicontrollerService } from 'app/controller/apicontroller.service';
import { AuthService } from 'app/Services/auth.service';


interface Doctor {
  doctor_email: string;
  doctor_gender: string;
  doctor_name: string;
  user_contact_number:string;
  user_password:string;
  // user_row_id:string;
}
 

@Component({
  selector: 'app-researchers-details',
  imports:[   
   // AsyncPipe,
   MatButtonModule,
    MatIconModule,
   CommonModule,
   MatTableModule,
  ],
  templateUrl: './researchers-details.component.html'
})
export class ResearchersDetailsComponent {
researchersId!: string | null; // Holds the researchersId ID from the route

  doctor: Doctor[] = [];
 
  displayedColumns: string[] = [
    // 'user_row_id',
    'doctor_name',
    'doctor_email',
    'user_contact_number',
    'doctor_gender',
    'user_password'
  ];



  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private apiController: ApicontrollerService,
    private authService: AuthService
  ) {
    
  }

  ngOnInit() {
    this.researchersId = this.route.snapshot.paramMap.get('id');
    // console.log("researchersId",this.researchersId)

    this.fetchdoctor();

  }


  async fetchdoctor(): Promise<void> {
    try {
      const response = await this.apiController.fetchSefesficdoctor(this.researchersId);
      this.doctor = response.data || []; // Ensure `data` exists in the API response
      // console.log("doctor----",this.doctor)
    } catch (error) {
      // console.error('Error fetching clients:', error);
    }
  }


  goback(){
    // console.log("click this button")
    this.router.navigate(['/Viewresearchers'])
  }


}
