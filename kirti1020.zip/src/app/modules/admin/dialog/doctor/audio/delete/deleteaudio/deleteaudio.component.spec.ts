import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteaudioComponent } from './deleteaudio.component';

describe('DeleteaudioComponent', () => {
  let component: DeleteaudioComponent;
  let fixture: ComponentFixture<DeleteaudioComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DeleteaudioComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DeleteaudioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
